package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.SparrowGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSparrowParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_DECIMAL", "RULE_URL_STRING", "RULE_MATH_SYMBOL", "RULE_ARITHMETIC_OPERATOR", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'import'", "'Contract'", "'extends'", "'{'", "'}'", "'Require'", "':'", "','", "';'", "'isTime'", "'isTrue'", "'logic'", "'check'", "'isCompleted'", "'isDone'", "'isRequest'", "'compareString'", "'timeSub'", "'SetDate'", "'transfer'", "'changeState'", "'Init'", "'s'", "'='", "'('", "')'", "'o'", "'Group'", "'RA'", "'AA'", "'CA'", "'PA'", "'ContractMessage'", "'string'", "'uint'", "'address'", "'int'", "'bytes'", "'bytes32'", "'bool'", "'fixed'", "'ufixed'", "'date'", "'duration'", "'months'", "'days'", "'hours'", "'minutes'", "'now'", "'a'", "'/'", "'Token'", "'Conditions'", "'['", "']'", "'and'", "'or'", "'Operations'", "'Rules'", "'Exclusive'", "'Parallel'", "'Additional'", "'If:'", "'!'", "'G'", "'Then'", "'Else'", "'Repeat'", "'SetDate('", "'SubRule'", "'FailResult:'", "'within'", "'after'", "'before'", "'compareString('", "'timeSub('", "'r'", "'years'", "'isTime('", "'logic('", "'isTrue('", "'isDone('", "'check('", "'getRuleTime('", "'\"'", "'f'", "'p'", "'.'", "'SetMessage('", "'new'", "'transfer('", "'assignString('", "'assign('", "'ContractState'", "'start'", "'pause'", "'restart'", "'terminate'", "'finish'", "'change('", "'CM'", "'true'", "'false'"
    };
    public static final int T__50=50;
    public static final int RULE_MATH_SYMBOL=9;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_INT=5;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=11;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_ARITHMETIC_OPERATOR=10;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__99=99;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_DECIMAL=7;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int RULE_URL_STRING=8;
    public static final int T__28=28;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=12;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=13;
    public static final int RULE_ANY_OTHER=14;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSparrowParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSparrowParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSparrowParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSparrow.g"; }



     	private SparrowGrammarAccess grammarAccess;

        public InternalSparrowParser(TokenStream input, SparrowGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected SparrowGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalSparrow.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalSparrow.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalSparrow.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSparrow.g:71:1: ruleModel returns [EObject current=null] : ( (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )* otherlv_2= 'Contract' ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )? otherlv_6= '{' ( (lv_subjects_7_0= ruleSubject ) )* ( (lv_objects_8_0= ruleObject ) )* ( (lv_group_9_0= ruleGroup ) )* ( (lv_initialize_10_0= ruleInitialize ) )? ( (lv_contractMessage_11_0= ruleContractMessage ) )? ( (lv_Conditions_12_0= ruleCondition ) )? ( (lv_operations_13_0= ruleOperation ) )? ( (lv_ruleStructures_14_0= ruleRuleStructure ) )? ( (lv_require_15_0= ruleRequire ) )? otherlv_16= '}' )? ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_packageName_1_0=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_extendName_5_0=null;
        Token otherlv_6=null;
        Token otherlv_16=null;
        EObject lv_subjects_7_0 = null;

        EObject lv_objects_8_0 = null;

        EObject lv_group_9_0 = null;

        EObject lv_initialize_10_0 = null;

        EObject lv_contractMessage_11_0 = null;

        EObject lv_Conditions_12_0 = null;

        EObject lv_operations_13_0 = null;

        EObject lv_ruleStructures_14_0 = null;

        EObject lv_require_15_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:77:2: ( ( (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )* otherlv_2= 'Contract' ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )? otherlv_6= '{' ( (lv_subjects_7_0= ruleSubject ) )* ( (lv_objects_8_0= ruleObject ) )* ( (lv_group_9_0= ruleGroup ) )* ( (lv_initialize_10_0= ruleInitialize ) )? ( (lv_contractMessage_11_0= ruleContractMessage ) )? ( (lv_Conditions_12_0= ruleCondition ) )? ( (lv_operations_13_0= ruleOperation ) )? ( (lv_ruleStructures_14_0= ruleRuleStructure ) )? ( (lv_require_15_0= ruleRequire ) )? otherlv_16= '}' )? )
            // InternalSparrow.g:78:2: ( (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )* otherlv_2= 'Contract' ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )? otherlv_6= '{' ( (lv_subjects_7_0= ruleSubject ) )* ( (lv_objects_8_0= ruleObject ) )* ( (lv_group_9_0= ruleGroup ) )* ( (lv_initialize_10_0= ruleInitialize ) )? ( (lv_contractMessage_11_0= ruleContractMessage ) )? ( (lv_Conditions_12_0= ruleCondition ) )? ( (lv_operations_13_0= ruleOperation ) )? ( (lv_ruleStructures_14_0= ruleRuleStructure ) )? ( (lv_require_15_0= ruleRequire ) )? otherlv_16= '}' )?
            {
            // InternalSparrow.g:78:2: ( (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )* otherlv_2= 'Contract' ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )? otherlv_6= '{' ( (lv_subjects_7_0= ruleSubject ) )* ( (lv_objects_8_0= ruleObject ) )* ( (lv_group_9_0= ruleGroup ) )* ( (lv_initialize_10_0= ruleInitialize ) )? ( (lv_contractMessage_11_0= ruleContractMessage ) )? ( (lv_Conditions_12_0= ruleCondition ) )? ( (lv_operations_13_0= ruleOperation ) )? ( (lv_ruleStructures_14_0= ruleRuleStructure ) )? ( (lv_require_15_0= ruleRequire ) )? otherlv_16= '}' )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=15 && LA12_0<=16)) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSparrow.g:79:3: (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )* otherlv_2= 'Contract' ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )? otherlv_6= '{' ( (lv_subjects_7_0= ruleSubject ) )* ( (lv_objects_8_0= ruleObject ) )* ( (lv_group_9_0= ruleGroup ) )* ( (lv_initialize_10_0= ruleInitialize ) )? ( (lv_contractMessage_11_0= ruleContractMessage ) )? ( (lv_Conditions_12_0= ruleCondition ) )? ( (lv_operations_13_0= ruleOperation ) )? ( (lv_ruleStructures_14_0= ruleRuleStructure ) )? ( (lv_require_15_0= ruleRequire ) )? otherlv_16= '}'
                    {
                    // InternalSparrow.g:79:3: (otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==15) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalSparrow.g:80:4: otherlv_0= 'import' ( (lv_packageName_1_0= RULE_ID ) )
                    	    {
                    	    otherlv_0=(Token)match(input,15,FOLLOW_3); 

                    	    				newLeafNode(otherlv_0, grammarAccess.getModelAccess().getImportKeyword_0_0());
                    	    			
                    	    // InternalSparrow.g:84:4: ( (lv_packageName_1_0= RULE_ID ) )
                    	    // InternalSparrow.g:85:5: (lv_packageName_1_0= RULE_ID )
                    	    {
                    	    // InternalSparrow.g:85:5: (lv_packageName_1_0= RULE_ID )
                    	    // InternalSparrow.g:86:6: lv_packageName_1_0= RULE_ID
                    	    {
                    	    lv_packageName_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

                    	    						newLeafNode(lv_packageName_1_0, grammarAccess.getModelAccess().getPackageNameIDTerminalRuleCall_0_1_0());
                    	    					

                    	    						if (current==null) {
                    	    							current = createModelElement(grammarAccess.getModelRule());
                    	    						}
                    	    						addWithLastConsumed(
                    	    							current,
                    	    							"packageName",
                    	    							lv_packageName_1_0,
                    	    							"org.eclipse.xtext.common.Terminals.ID");
                    	    					

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_2=(Token)match(input,16,FOLLOW_3); 

                    			newLeafNode(otherlv_2, grammarAccess.getModelAccess().getContractKeyword_1());
                    		
                    // InternalSparrow.g:107:3: ( (lv_name_3_0= RULE_ID ) )
                    // InternalSparrow.g:108:4: (lv_name_3_0= RULE_ID )
                    {
                    // InternalSparrow.g:108:4: (lv_name_3_0= RULE_ID )
                    // InternalSparrow.g:109:5: lv_name_3_0= RULE_ID
                    {
                    lv_name_3_0=(Token)match(input,RULE_ID,FOLLOW_5); 

                    					newLeafNode(lv_name_3_0, grammarAccess.getModelAccess().getNameIDTerminalRuleCall_2_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getModelRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"name",
                    						lv_name_3_0,
                    						"org.eclipse.xtext.common.Terminals.ID");
                    				

                    }


                    }

                    // InternalSparrow.g:125:3: (otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) ) )?
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==17) ) {
                        alt2=1;
                    }
                    switch (alt2) {
                        case 1 :
                            // InternalSparrow.g:126:4: otherlv_4= 'extends' ( (lv_extendName_5_0= RULE_ID ) )
                            {
                            otherlv_4=(Token)match(input,17,FOLLOW_3); 

                            				newLeafNode(otherlv_4, grammarAccess.getModelAccess().getExtendsKeyword_3_0());
                            			
                            // InternalSparrow.g:130:4: ( (lv_extendName_5_0= RULE_ID ) )
                            // InternalSparrow.g:131:5: (lv_extendName_5_0= RULE_ID )
                            {
                            // InternalSparrow.g:131:5: (lv_extendName_5_0= RULE_ID )
                            // InternalSparrow.g:132:6: lv_extendName_5_0= RULE_ID
                            {
                            lv_extendName_5_0=(Token)match(input,RULE_ID,FOLLOW_6); 

                            						newLeafNode(lv_extendName_5_0, grammarAccess.getModelAccess().getExtendNameIDTerminalRuleCall_3_1_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getModelRule());
                            						}
                            						setWithLastConsumed(
                            							current,
                            							"extendName",
                            							lv_extendName_5_0,
                            							"org.eclipse.xtext.common.Terminals.ID");
                            					

                            }


                            }


                            }
                            break;

                    }

                    otherlv_6=(Token)match(input,18,FOLLOW_7); 

                    			newLeafNode(otherlv_6, grammarAccess.getModelAccess().getLeftCurlyBracketKeyword_4());
                    		
                    // InternalSparrow.g:153:3: ( (lv_subjects_7_0= ruleSubject ) )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0>=43 && LA3_0<=46)) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalSparrow.g:154:4: (lv_subjects_7_0= ruleSubject )
                    	    {
                    	    // InternalSparrow.g:154:4: (lv_subjects_7_0= ruleSubject )
                    	    // InternalSparrow.g:155:5: lv_subjects_7_0= ruleSubject
                    	    {

                    	    					newCompositeNode(grammarAccess.getModelAccess().getSubjectsSubjectParserRuleCall_5_0());
                    	    				
                    	    pushFollow(FOLLOW_7);
                    	    lv_subjects_7_0=ruleSubject();

                    	    state._fsp--;


                    	    					if (current==null) {
                    	    						current = createModelElementForParent(grammarAccess.getModelRule());
                    	    					}
                    	    					add(
                    	    						current,
                    	    						"subjects",
                    	    						lv_subjects_7_0,
                    	    						"org.xtext.example.mydsl.Sparrow.Subject");
                    	    					afterParserOrEnumRuleCall();
                    	    				

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    // InternalSparrow.g:172:3: ( (lv_objects_8_0= ruleObject ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==66) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalSparrow.g:173:4: (lv_objects_8_0= ruleObject )
                    	    {
                    	    // InternalSparrow.g:173:4: (lv_objects_8_0= ruleObject )
                    	    // InternalSparrow.g:174:5: lv_objects_8_0= ruleObject
                    	    {

                    	    					newCompositeNode(grammarAccess.getModelAccess().getObjectsObjectParserRuleCall_6_0());
                    	    				
                    	    pushFollow(FOLLOW_8);
                    	    lv_objects_8_0=ruleObject();

                    	    state._fsp--;


                    	    					if (current==null) {
                    	    						current = createModelElementForParent(grammarAccess.getModelRule());
                    	    					}
                    	    					add(
                    	    						current,
                    	    						"objects",
                    	    						lv_objects_8_0,
                    	    						"org.xtext.example.mydsl.Sparrow.Object");
                    	    					afterParserOrEnumRuleCall();
                    	    				

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    // InternalSparrow.g:191:3: ( (lv_group_9_0= ruleGroup ) )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==42) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalSparrow.g:192:4: (lv_group_9_0= ruleGroup )
                    	    {
                    	    // InternalSparrow.g:192:4: (lv_group_9_0= ruleGroup )
                    	    // InternalSparrow.g:193:5: lv_group_9_0= ruleGroup
                    	    {

                    	    					newCompositeNode(grammarAccess.getModelAccess().getGroupGroupParserRuleCall_7_0());
                    	    				
                    	    pushFollow(FOLLOW_9);
                    	    lv_group_9_0=ruleGroup();

                    	    state._fsp--;


                    	    					if (current==null) {
                    	    						current = createModelElementForParent(grammarAccess.getModelRule());
                    	    					}
                    	    					add(
                    	    						current,
                    	    						"group",
                    	    						lv_group_9_0,
                    	    						"org.xtext.example.mydsl.Sparrow.Group");
                    	    					afterParserOrEnumRuleCall();
                    	    				

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);

                    // InternalSparrow.g:210:3: ( (lv_initialize_10_0= ruleInitialize ) )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==36) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalSparrow.g:211:4: (lv_initialize_10_0= ruleInitialize )
                            {
                            // InternalSparrow.g:211:4: (lv_initialize_10_0= ruleInitialize )
                            // InternalSparrow.g:212:5: lv_initialize_10_0= ruleInitialize
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getInitializeInitializeParserRuleCall_8_0());
                            				
                            pushFollow(FOLLOW_10);
                            lv_initialize_10_0=ruleInitialize();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"initialize",
                            						lv_initialize_10_0,
                            						"org.xtext.example.mydsl.Sparrow.Initialize");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    // InternalSparrow.g:229:3: ( (lv_contractMessage_11_0= ruleContractMessage ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==47) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalSparrow.g:230:4: (lv_contractMessage_11_0= ruleContractMessage )
                            {
                            // InternalSparrow.g:230:4: (lv_contractMessage_11_0= ruleContractMessage )
                            // InternalSparrow.g:231:5: lv_contractMessage_11_0= ruleContractMessage
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getContractMessageContractMessageParserRuleCall_9_0());
                            				
                            pushFollow(FOLLOW_11);
                            lv_contractMessage_11_0=ruleContractMessage();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"contractMessage",
                            						lv_contractMessage_11_0,
                            						"org.xtext.example.mydsl.Sparrow.ContractMessage");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    // InternalSparrow.g:248:3: ( (lv_Conditions_12_0= ruleCondition ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==67) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalSparrow.g:249:4: (lv_Conditions_12_0= ruleCondition )
                            {
                            // InternalSparrow.g:249:4: (lv_Conditions_12_0= ruleCondition )
                            // InternalSparrow.g:250:5: lv_Conditions_12_0= ruleCondition
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getConditionsConditionParserRuleCall_10_0());
                            				
                            pushFollow(FOLLOW_12);
                            lv_Conditions_12_0=ruleCondition();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"Conditions",
                            						lv_Conditions_12_0,
                            						"org.xtext.example.mydsl.Sparrow.Condition");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    // InternalSparrow.g:267:3: ( (lv_operations_13_0= ruleOperation ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==72) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalSparrow.g:268:4: (lv_operations_13_0= ruleOperation )
                            {
                            // InternalSparrow.g:268:4: (lv_operations_13_0= ruleOperation )
                            // InternalSparrow.g:269:5: lv_operations_13_0= ruleOperation
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getOperationsOperationParserRuleCall_11_0());
                            				
                            pushFollow(FOLLOW_13);
                            lv_operations_13_0=ruleOperation();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"operations",
                            						lv_operations_13_0,
                            						"org.xtext.example.mydsl.Sparrow.Operation");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    // InternalSparrow.g:286:3: ( (lv_ruleStructures_14_0= ruleRuleStructure ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==73) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalSparrow.g:287:4: (lv_ruleStructures_14_0= ruleRuleStructure )
                            {
                            // InternalSparrow.g:287:4: (lv_ruleStructures_14_0= ruleRuleStructure )
                            // InternalSparrow.g:288:5: lv_ruleStructures_14_0= ruleRuleStructure
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getRuleStructuresRuleStructureParserRuleCall_12_0());
                            				
                            pushFollow(FOLLOW_14);
                            lv_ruleStructures_14_0=ruleRuleStructure();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"ruleStructures",
                            						lv_ruleStructures_14_0,
                            						"org.xtext.example.mydsl.Sparrow.RuleStructure");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    // InternalSparrow.g:305:3: ( (lv_require_15_0= ruleRequire ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==20) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // InternalSparrow.g:306:4: (lv_require_15_0= ruleRequire )
                            {
                            // InternalSparrow.g:306:4: (lv_require_15_0= ruleRequire )
                            // InternalSparrow.g:307:5: lv_require_15_0= ruleRequire
                            {

                            					newCompositeNode(grammarAccess.getModelAccess().getRequireRequireParserRuleCall_13_0());
                            				
                            pushFollow(FOLLOW_15);
                            lv_require_15_0=ruleRequire();

                            state._fsp--;


                            					if (current==null) {
                            						current = createModelElementForParent(grammarAccess.getModelRule());
                            					}
                            					set(
                            						current,
                            						"require",
                            						lv_require_15_0,
                            						"org.xtext.example.mydsl.Sparrow.Require");
                            					afterParserOrEnumRuleCall();
                            				

                            }


                            }
                            break;

                    }

                    otherlv_16=(Token)match(input,19,FOLLOW_2); 

                    			newLeafNode(otherlv_16, grammarAccess.getModelAccess().getRightCurlyBracketKeyword_14());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleRequire"
    // InternalSparrow.g:332:1: entryRuleRequire returns [EObject current=null] : iv_ruleRequire= ruleRequire EOF ;
    public final EObject entryRuleRequire() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRequire = null;


        try {
            // InternalSparrow.g:332:48: (iv_ruleRequire= ruleRequire EOF )
            // InternalSparrow.g:333:2: iv_ruleRequire= ruleRequire EOF
            {
             newCompositeNode(grammarAccess.getRequireRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRequire=ruleRequire();

            state._fsp--;

             current =iv_ruleRequire; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRequire"


    // $ANTLR start "ruleRequire"
    // InternalSparrow.g:339:1: ruleRequire returns [EObject current=null] : (otherlv_0= 'Require' otherlv_1= ':' ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) ) (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )* otherlv_5= ';' ) ;
    public final EObject ruleRequire() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_value_2_1 = null;

        AntlrDatatypeRuleToken lv_value_2_2 = null;

        AntlrDatatypeRuleToken lv_value_4_1 = null;

        AntlrDatatypeRuleToken lv_value_4_2 = null;



        	enterRule();

        try {
            // InternalSparrow.g:345:2: ( (otherlv_0= 'Require' otherlv_1= ':' ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) ) (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )* otherlv_5= ';' ) )
            // InternalSparrow.g:346:2: (otherlv_0= 'Require' otherlv_1= ':' ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) ) (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )* otherlv_5= ';' )
            {
            // InternalSparrow.g:346:2: (otherlv_0= 'Require' otherlv_1= ':' ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) ) (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )* otherlv_5= ';' )
            // InternalSparrow.g:347:3: otherlv_0= 'Require' otherlv_1= ':' ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) ) (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )* otherlv_5= ';'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_16); 

            			newLeafNode(otherlv_0, grammarAccess.getRequireAccess().getRequireKeyword_0());
            		
            otherlv_1=(Token)match(input,21,FOLLOW_17); 

            			newLeafNode(otherlv_1, grammarAccess.getRequireAccess().getColonKeyword_1());
            		
            // InternalSparrow.g:355:3: ( ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) ) )
            // InternalSparrow.g:356:4: ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) )
            {
            // InternalSparrow.g:356:4: ( (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype ) )
            // InternalSparrow.g:357:5: (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype )
            {
            // InternalSparrow.g:357:5: (lv_value_2_1= ruleconditiontype | lv_value_2_2= ruleactiontype )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=24 && LA13_0<=33)) ) {
                alt13=1;
            }
            else if ( ((LA13_0>=34 && LA13_0<=35)) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalSparrow.g:358:6: lv_value_2_1= ruleconditiontype
                    {

                    						newCompositeNode(grammarAccess.getRequireAccess().getValueConditiontypeParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_value_2_1=ruleconditiontype();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRequireRule());
                    						}
                    						add(
                    							current,
                    							"value",
                    							lv_value_2_1,
                    							"org.xtext.example.mydsl.Sparrow.conditiontype");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:374:6: lv_value_2_2= ruleactiontype
                    {

                    						newCompositeNode(grammarAccess.getRequireAccess().getValueActiontypeParserRuleCall_2_0_1());
                    					
                    pushFollow(FOLLOW_18);
                    lv_value_2_2=ruleactiontype();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRequireRule());
                    						}
                    						add(
                    							current,
                    							"value",
                    							lv_value_2_2,
                    							"org.xtext.example.mydsl.Sparrow.actiontype");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            // InternalSparrow.g:392:3: (otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==22) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSparrow.g:393:4: otherlv_3= ',' ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) )
            	    {
            	    otherlv_3=(Token)match(input,22,FOLLOW_17); 

            	    				newLeafNode(otherlv_3, grammarAccess.getRequireAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalSparrow.g:397:4: ( ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) ) )
            	    // InternalSparrow.g:398:5: ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) )
            	    {
            	    // InternalSparrow.g:398:5: ( (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype ) )
            	    // InternalSparrow.g:399:6: (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype )
            	    {
            	    // InternalSparrow.g:399:6: (lv_value_4_1= ruleconditiontype | lv_value_4_2= ruleactiontype )
            	    int alt14=2;
            	    int LA14_0 = input.LA(1);

            	    if ( ((LA14_0>=24 && LA14_0<=33)) ) {
            	        alt14=1;
            	    }
            	    else if ( ((LA14_0>=34 && LA14_0<=35)) ) {
            	        alt14=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 14, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt14) {
            	        case 1 :
            	            // InternalSparrow.g:400:7: lv_value_4_1= ruleconditiontype
            	            {

            	            							newCompositeNode(grammarAccess.getRequireAccess().getValueConditiontypeParserRuleCall_3_1_0_0());
            	            						
            	            pushFollow(FOLLOW_18);
            	            lv_value_4_1=ruleconditiontype();

            	            state._fsp--;


            	            							if (current==null) {
            	            								current = createModelElementForParent(grammarAccess.getRequireRule());
            	            							}
            	            							add(
            	            								current,
            	            								"value",
            	            								lv_value_4_1,
            	            								"org.xtext.example.mydsl.Sparrow.conditiontype");
            	            							afterParserOrEnumRuleCall();
            	            						

            	            }
            	            break;
            	        case 2 :
            	            // InternalSparrow.g:416:7: lv_value_4_2= ruleactiontype
            	            {

            	            							newCompositeNode(grammarAccess.getRequireAccess().getValueActiontypeParserRuleCall_3_1_0_1());
            	            						
            	            pushFollow(FOLLOW_18);
            	            lv_value_4_2=ruleactiontype();

            	            state._fsp--;


            	            							if (current==null) {
            	            								current = createModelElementForParent(grammarAccess.getRequireRule());
            	            							}
            	            							add(
            	            								current,
            	            								"value",
            	            								lv_value_4_2,
            	            								"org.xtext.example.mydsl.Sparrow.actiontype");
            	            							afterParserOrEnumRuleCall();
            	            						

            	            }
            	            break;

            	    }


            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            otherlv_5=(Token)match(input,23,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getRequireAccess().getSemicolonKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRequire"


    // $ANTLR start "entryRuleconditiontype"
    // InternalSparrow.g:443:1: entryRuleconditiontype returns [String current=null] : iv_ruleconditiontype= ruleconditiontype EOF ;
    public final String entryRuleconditiontype() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleconditiontype = null;


        try {
            // InternalSparrow.g:443:53: (iv_ruleconditiontype= ruleconditiontype EOF )
            // InternalSparrow.g:444:2: iv_ruleconditiontype= ruleconditiontype EOF
            {
             newCompositeNode(grammarAccess.getConditiontypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleconditiontype=ruleconditiontype();

            state._fsp--;

             current =iv_ruleconditiontype.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleconditiontype"


    // $ANTLR start "ruleconditiontype"
    // InternalSparrow.g:450:1: ruleconditiontype returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'isTime' | kw= 'isTrue' | kw= 'logic' | kw= 'check' | kw= 'isCompleted' | kw= 'isDone' | kw= 'isRequest' | kw= 'compareString' | kw= 'timeSub' | kw= 'SetDate' ) ;
    public final AntlrDatatypeRuleToken ruleconditiontype() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:456:2: ( (kw= 'isTime' | kw= 'isTrue' | kw= 'logic' | kw= 'check' | kw= 'isCompleted' | kw= 'isDone' | kw= 'isRequest' | kw= 'compareString' | kw= 'timeSub' | kw= 'SetDate' ) )
            // InternalSparrow.g:457:2: (kw= 'isTime' | kw= 'isTrue' | kw= 'logic' | kw= 'check' | kw= 'isCompleted' | kw= 'isDone' | kw= 'isRequest' | kw= 'compareString' | kw= 'timeSub' | kw= 'SetDate' )
            {
            // InternalSparrow.g:457:2: (kw= 'isTime' | kw= 'isTrue' | kw= 'logic' | kw= 'check' | kw= 'isCompleted' | kw= 'isDone' | kw= 'isRequest' | kw= 'compareString' | kw= 'timeSub' | kw= 'SetDate' )
            int alt16=10;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt16=1;
                }
                break;
            case 25:
                {
                alt16=2;
                }
                break;
            case 26:
                {
                alt16=3;
                }
                break;
            case 27:
                {
                alt16=4;
                }
                break;
            case 28:
                {
                alt16=5;
                }
                break;
            case 29:
                {
                alt16=6;
                }
                break;
            case 30:
                {
                alt16=7;
                }
                break;
            case 31:
                {
                alt16=8;
                }
                break;
            case 32:
                {
                alt16=9;
                }
                break;
            case 33:
                {
                alt16=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalSparrow.g:458:3: kw= 'isTime'
                    {
                    kw=(Token)match(input,24,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getIsTimeKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:464:3: kw= 'isTrue'
                    {
                    kw=(Token)match(input,25,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getIsTrueKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:470:3: kw= 'logic'
                    {
                    kw=(Token)match(input,26,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getLogicKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:476:3: kw= 'check'
                    {
                    kw=(Token)match(input,27,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getCheckKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:482:3: kw= 'isCompleted'
                    {
                    kw=(Token)match(input,28,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getIsCompletedKeyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSparrow.g:488:3: kw= 'isDone'
                    {
                    kw=(Token)match(input,29,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getIsDoneKeyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSparrow.g:494:3: kw= 'isRequest'
                    {
                    kw=(Token)match(input,30,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getIsRequestKeyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSparrow.g:500:3: kw= 'compareString'
                    {
                    kw=(Token)match(input,31,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getCompareStringKeyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSparrow.g:506:3: kw= 'timeSub'
                    {
                    kw=(Token)match(input,32,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getTimeSubKeyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSparrow.g:512:3: kw= 'SetDate'
                    {
                    kw=(Token)match(input,33,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getConditiontypeAccess().getSetDateKeyword_9());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleconditiontype"


    // $ANTLR start "entryRuleactiontype"
    // InternalSparrow.g:521:1: entryRuleactiontype returns [String current=null] : iv_ruleactiontype= ruleactiontype EOF ;
    public final String entryRuleactiontype() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleactiontype = null;


        try {
            // InternalSparrow.g:521:50: (iv_ruleactiontype= ruleactiontype EOF )
            // InternalSparrow.g:522:2: iv_ruleactiontype= ruleactiontype EOF
            {
             newCompositeNode(grammarAccess.getActiontypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleactiontype=ruleactiontype();

            state._fsp--;

             current =iv_ruleactiontype.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleactiontype"


    // $ANTLR start "ruleactiontype"
    // InternalSparrow.g:528:1: ruleactiontype returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'transfer' | kw= 'changeState' ) ;
    public final AntlrDatatypeRuleToken ruleactiontype() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:534:2: ( (kw= 'transfer' | kw= 'changeState' ) )
            // InternalSparrow.g:535:2: (kw= 'transfer' | kw= 'changeState' )
            {
            // InternalSparrow.g:535:2: (kw= 'transfer' | kw= 'changeState' )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==34) ) {
                alt17=1;
            }
            else if ( (LA17_0==35) ) {
                alt17=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalSparrow.g:536:3: kw= 'transfer'
                    {
                    kw=(Token)match(input,34,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getActiontypeAccess().getTransferKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:542:3: kw= 'changeState'
                    {
                    kw=(Token)match(input,35,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getActiontypeAccess().getChangeStateKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleactiontype"


    // $ANTLR start "entryRuleInitialize"
    // InternalSparrow.g:551:1: entryRuleInitialize returns [EObject current=null] : iv_ruleInitialize= ruleInitialize EOF ;
    public final EObject entryRuleInitialize() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInitialize = null;


        try {
            // InternalSparrow.g:551:51: (iv_ruleInitialize= ruleInitialize EOF )
            // InternalSparrow.g:552:2: iv_ruleInitialize= ruleInitialize EOF
            {
             newCompositeNode(grammarAccess.getInitializeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInitialize=ruleInitialize();

            state._fsp--;

             current =iv_ruleInitialize; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInitialize"


    // $ANTLR start "ruleInitialize"
    // InternalSparrow.g:558:1: ruleInitialize returns [EObject current=null] : ( () otherlv_1= 'Init' otherlv_2= '{' ( (lv_inits_3_0= ruleinitExpressions ) )* ( (lv_inito_4_0= ruleinitExpressiono ) )* otherlv_5= '}' ) ;
    public final EObject ruleInitialize() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_5=null;
        EObject lv_inits_3_0 = null;

        EObject lv_inito_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:564:2: ( ( () otherlv_1= 'Init' otherlv_2= '{' ( (lv_inits_3_0= ruleinitExpressions ) )* ( (lv_inito_4_0= ruleinitExpressiono ) )* otherlv_5= '}' ) )
            // InternalSparrow.g:565:2: ( () otherlv_1= 'Init' otherlv_2= '{' ( (lv_inits_3_0= ruleinitExpressions ) )* ( (lv_inito_4_0= ruleinitExpressiono ) )* otherlv_5= '}' )
            {
            // InternalSparrow.g:565:2: ( () otherlv_1= 'Init' otherlv_2= '{' ( (lv_inits_3_0= ruleinitExpressions ) )* ( (lv_inito_4_0= ruleinitExpressiono ) )* otherlv_5= '}' )
            // InternalSparrow.g:566:3: () otherlv_1= 'Init' otherlv_2= '{' ( (lv_inits_3_0= ruleinitExpressions ) )* ( (lv_inito_4_0= ruleinitExpressiono ) )* otherlv_5= '}'
            {
            // InternalSparrow.g:566:3: ()
            // InternalSparrow.g:567:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInitializeAccess().getInitializeAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,36,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getInitializeAccess().getInitKeyword_1());
            		
            otherlv_2=(Token)match(input,18,FOLLOW_19); 

            			newLeafNode(otherlv_2, grammarAccess.getInitializeAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSparrow.g:581:3: ( (lv_inits_3_0= ruleinitExpressions ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==37) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSparrow.g:582:4: (lv_inits_3_0= ruleinitExpressions )
            	    {
            	    // InternalSparrow.g:582:4: (lv_inits_3_0= ruleinitExpressions )
            	    // InternalSparrow.g:583:5: lv_inits_3_0= ruleinitExpressions
            	    {

            	    					newCompositeNode(grammarAccess.getInitializeAccess().getInitsInitExpressionsParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_19);
            	    lv_inits_3_0=ruleinitExpressions();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getInitializeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inits",
            	    						lv_inits_3_0,
            	    						"org.xtext.example.mydsl.Sparrow.initExpressions");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            // InternalSparrow.g:600:3: ( (lv_inito_4_0= ruleinitExpressiono ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==41) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSparrow.g:601:4: (lv_inito_4_0= ruleinitExpressiono )
            	    {
            	    // InternalSparrow.g:601:4: (lv_inito_4_0= ruleinitExpressiono )
            	    // InternalSparrow.g:602:5: lv_inito_4_0= ruleinitExpressiono
            	    {

            	    					newCompositeNode(grammarAccess.getInitializeAccess().getInitoInitExpressionoParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_20);
            	    lv_inito_4_0=ruleinitExpressiono();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getInitializeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inito",
            	    						lv_inito_4_0,
            	    						"org.xtext.example.mydsl.Sparrow.initExpressiono");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            otherlv_5=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getInitializeAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInitialize"


    // $ANTLR start "entryRuleinitExpressions"
    // InternalSparrow.g:627:1: entryRuleinitExpressions returns [EObject current=null] : iv_ruleinitExpressions= ruleinitExpressions EOF ;
    public final EObject entryRuleinitExpressions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleinitExpressions = null;


        try {
            // InternalSparrow.g:627:56: (iv_ruleinitExpressions= ruleinitExpressions EOF )
            // InternalSparrow.g:628:2: iv_ruleinitExpressions= ruleinitExpressions EOF
            {
             newCompositeNode(grammarAccess.getInitExpressionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleinitExpressions=ruleinitExpressions();

            state._fsp--;

             current =iv_ruleinitExpressions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleinitExpressions"


    // $ANTLR start "ruleinitExpressions"
    // InternalSparrow.g:634:1: ruleinitExpressions returns [EObject current=null] : (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' ) ;
    public final EObject ruleinitExpressions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_value_5_0 = null;

        EObject lv_value_7_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:640:2: ( (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' ) )
            // InternalSparrow.g:641:2: (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' )
            {
            // InternalSparrow.g:641:2: (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' )
            // InternalSparrow.g:642:3: otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')'
            {
            otherlv_0=(Token)match(input,37,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getInitExpressionsAccess().getSKeyword_0());
            		
            // InternalSparrow.g:646:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:647:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:647:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:648:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInitExpressionsRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_3); 

            					newLeafNode(otherlv_1, grammarAccess.getInitExpressionsAccess().getSubtypeSubjectCrossReference_1_0());
            				

            }


            }

            // InternalSparrow.g:659:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSparrow.g:660:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSparrow.g:660:4: (lv_name_2_0= RULE_ID )
            // InternalSparrow.g:661:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_21); 

            					newLeafNode(lv_name_2_0, grammarAccess.getInitExpressionsAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInitExpressionsRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,38,FOLLOW_22); 

            			newLeafNode(otherlv_3, grammarAccess.getInitExpressionsAccess().getEqualsSignKeyword_3());
            		
            otherlv_4=(Token)match(input,39,FOLLOW_23); 

            			newLeafNode(otherlv_4, grammarAccess.getInitExpressionsAccess().getLeftParenthesisKeyword_4());
            		
            // InternalSparrow.g:685:3: ( (lv_value_5_0= ruleValue ) )
            // InternalSparrow.g:686:4: (lv_value_5_0= ruleValue )
            {
            // InternalSparrow.g:686:4: (lv_value_5_0= ruleValue )
            // InternalSparrow.g:687:5: lv_value_5_0= ruleValue
            {

            					newCompositeNode(grammarAccess.getInitExpressionsAccess().getValueValueParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_24);
            lv_value_5_0=ruleValue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInitExpressionsRule());
            					}
            					add(
            						current,
            						"value",
            						lv_value_5_0,
            						"org.xtext.example.mydsl.Sparrow.Value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:704:3: (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==22) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSparrow.g:705:4: otherlv_6= ',' ( (lv_value_7_0= ruleValue ) )
            	    {
            	    otherlv_6=(Token)match(input,22,FOLLOW_23); 

            	    				newLeafNode(otherlv_6, grammarAccess.getInitExpressionsAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalSparrow.g:709:4: ( (lv_value_7_0= ruleValue ) )
            	    // InternalSparrow.g:710:5: (lv_value_7_0= ruleValue )
            	    {
            	    // InternalSparrow.g:710:5: (lv_value_7_0= ruleValue )
            	    // InternalSparrow.g:711:6: lv_value_7_0= ruleValue
            	    {

            	    						newCompositeNode(grammarAccess.getInitExpressionsAccess().getValueValueParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_24);
            	    lv_value_7_0=ruleValue();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getInitExpressionsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"value",
            	    							lv_value_7_0,
            	    							"org.xtext.example.mydsl.Sparrow.Value");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            otherlv_8=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getInitExpressionsAccess().getRightParenthesisKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleinitExpressions"


    // $ANTLR start "entryRuleinitExpressiono"
    // InternalSparrow.g:737:1: entryRuleinitExpressiono returns [EObject current=null] : iv_ruleinitExpressiono= ruleinitExpressiono EOF ;
    public final EObject entryRuleinitExpressiono() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleinitExpressiono = null;


        try {
            // InternalSparrow.g:737:56: (iv_ruleinitExpressiono= ruleinitExpressiono EOF )
            // InternalSparrow.g:738:2: iv_ruleinitExpressiono= ruleinitExpressiono EOF
            {
             newCompositeNode(grammarAccess.getInitExpressionoRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleinitExpressiono=ruleinitExpressiono();

            state._fsp--;

             current =iv_ruleinitExpressiono; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleinitExpressiono"


    // $ANTLR start "ruleinitExpressiono"
    // InternalSparrow.g:744:1: ruleinitExpressiono returns [EObject current=null] : (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' ) ;
    public final EObject ruleinitExpressiono() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_value_5_0 = null;

        EObject lv_value_7_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:750:2: ( (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' ) )
            // InternalSparrow.g:751:2: (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' )
            {
            // InternalSparrow.g:751:2: (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')' )
            // InternalSparrow.g:752:3: otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '=' otherlv_4= '(' ( (lv_value_5_0= ruleValue ) ) (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )* otherlv_8= ')'
            {
            otherlv_0=(Token)match(input,41,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getInitExpressionoAccess().getOKeyword_0());
            		
            // InternalSparrow.g:756:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:757:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:757:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:758:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInitExpressionoRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_3); 

            					newLeafNode(otherlv_1, grammarAccess.getInitExpressionoAccess().getObtypeObjectCrossReference_1_0());
            				

            }


            }

            // InternalSparrow.g:769:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSparrow.g:770:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSparrow.g:770:4: (lv_name_2_0= RULE_ID )
            // InternalSparrow.g:771:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_21); 

            					newLeafNode(lv_name_2_0, grammarAccess.getInitExpressionoAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInitExpressionoRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,38,FOLLOW_22); 

            			newLeafNode(otherlv_3, grammarAccess.getInitExpressionoAccess().getEqualsSignKeyword_3());
            		
            otherlv_4=(Token)match(input,39,FOLLOW_23); 

            			newLeafNode(otherlv_4, grammarAccess.getInitExpressionoAccess().getLeftParenthesisKeyword_4());
            		
            // InternalSparrow.g:795:3: ( (lv_value_5_0= ruleValue ) )
            // InternalSparrow.g:796:4: (lv_value_5_0= ruleValue )
            {
            // InternalSparrow.g:796:4: (lv_value_5_0= ruleValue )
            // InternalSparrow.g:797:5: lv_value_5_0= ruleValue
            {

            					newCompositeNode(grammarAccess.getInitExpressionoAccess().getValueValueParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_24);
            lv_value_5_0=ruleValue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInitExpressionoRule());
            					}
            					add(
            						current,
            						"value",
            						lv_value_5_0,
            						"org.xtext.example.mydsl.Sparrow.Value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:814:3: (otherlv_6= ',' ( (lv_value_7_0= ruleValue ) ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==22) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSparrow.g:815:4: otherlv_6= ',' ( (lv_value_7_0= ruleValue ) )
            	    {
            	    otherlv_6=(Token)match(input,22,FOLLOW_23); 

            	    				newLeafNode(otherlv_6, grammarAccess.getInitExpressionoAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalSparrow.g:819:4: ( (lv_value_7_0= ruleValue ) )
            	    // InternalSparrow.g:820:5: (lv_value_7_0= ruleValue )
            	    {
            	    // InternalSparrow.g:820:5: (lv_value_7_0= ruleValue )
            	    // InternalSparrow.g:821:6: lv_value_7_0= ruleValue
            	    {

            	    						newCompositeNode(grammarAccess.getInitExpressionoAccess().getValueValueParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_24);
            	    lv_value_7_0=ruleValue();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getInitExpressionoRule());
            	    						}
            	    						add(
            	    							current,
            	    							"value",
            	    							lv_value_7_0,
            	    							"org.xtext.example.mydsl.Sparrow.Value");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            otherlv_8=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getInitExpressionoAccess().getRightParenthesisKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleinitExpressiono"


    // $ANTLR start "entryRuleGroup"
    // InternalSparrow.g:847:1: entryRuleGroup returns [EObject current=null] : iv_ruleGroup= ruleGroup EOF ;
    public final EObject entryRuleGroup() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGroup = null;


        try {
            // InternalSparrow.g:847:46: (iv_ruleGroup= ruleGroup EOF )
            // InternalSparrow.g:848:2: iv_ruleGroup= ruleGroup EOF
            {
             newCompositeNode(grammarAccess.getGroupRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGroup=ruleGroup();

            state._fsp--;

             current =iv_ruleGroup; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGroup"


    // $ANTLR start "ruleGroup"
    // InternalSparrow.g:854:1: ruleGroup returns [EObject current=null] : (otherlv_0= 'Group' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= '}' ) ;
    public final EObject ruleGroup() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalSparrow.g:860:2: ( (otherlv_0= 'Group' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= '}' ) )
            // InternalSparrow.g:861:2: (otherlv_0= 'Group' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= '}' )
            {
            // InternalSparrow.g:861:2: (otherlv_0= 'Group' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= '}' )
            // InternalSparrow.g:862:3: otherlv_0= 'Group' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= '}'
            {
            otherlv_0=(Token)match(input,42,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getGroupAccess().getGroupKeyword_0());
            		
            // InternalSparrow.g:866:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:867:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:867:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:868:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGroupRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_3); 

            					newLeafNode(otherlv_1, grammarAccess.getGroupAccess().getSubtypeSubjectCrossReference_1_0());
            				

            }


            }

            // InternalSparrow.g:879:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSparrow.g:880:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSparrow.g:880:4: (lv_name_2_0= RULE_ID )
            // InternalSparrow.g:881:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            					newLeafNode(lv_name_2_0, grammarAccess.getGroupAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_3, grammarAccess.getGroupAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalSparrow.g:901:3: ( (otherlv_4= RULE_ID ) )
            // InternalSparrow.g:902:4: (otherlv_4= RULE_ID )
            {
            // InternalSparrow.g:902:4: (otherlv_4= RULE_ID )
            // InternalSparrow.g:903:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGroupRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_25); 

            					newLeafNode(otherlv_4, grammarAccess.getGroupAccess().getValueInitExpressionsCrossReference_4_0());
            				

            }


            }

            // InternalSparrow.g:914:3: (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==22) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalSparrow.g:915:4: otherlv_5= ',' ( (otherlv_6= RULE_ID ) )
            	    {
            	    otherlv_5=(Token)match(input,22,FOLLOW_3); 

            	    				newLeafNode(otherlv_5, grammarAccess.getGroupAccess().getCommaKeyword_5_0());
            	    			
            	    // InternalSparrow.g:919:4: ( (otherlv_6= RULE_ID ) )
            	    // InternalSparrow.g:920:5: (otherlv_6= RULE_ID )
            	    {
            	    // InternalSparrow.g:920:5: (otherlv_6= RULE_ID )
            	    // InternalSparrow.g:921:6: otherlv_6= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getGroupRule());
            	    						}
            	    					
            	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_25); 

            	    						newLeafNode(otherlv_6, grammarAccess.getGroupAccess().getValueInitExpressionsCrossReference_5_1_0());
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            otherlv_7=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getGroupAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGroup"


    // $ANTLR start "entryRuleSubject"
    // InternalSparrow.g:941:1: entryRuleSubject returns [EObject current=null] : iv_ruleSubject= ruleSubject EOF ;
    public final EObject entryRuleSubject() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubject = null;


        try {
            // InternalSparrow.g:941:48: (iv_ruleSubject= ruleSubject EOF )
            // InternalSparrow.g:942:2: iv_ruleSubject= ruleSubject EOF
            {
             newCompositeNode(grammarAccess.getSubjectRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubject=ruleSubject();

            state._fsp--;

             current =iv_ruleSubject; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubject"


    // $ANTLR start "ruleSubject"
    // InternalSparrow.g:948:1: ruleSubject returns [EObject current=null] : ( ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )? ) ;
    public final EObject ruleSubject() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_name_1_0=null;
        EObject lv_subjectExpression_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:954:2: ( ( ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )? ) )
            // InternalSparrow.g:955:2: ( ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )? )
            {
            // InternalSparrow.g:955:2: ( ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )? )
            // InternalSparrow.g:956:3: ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )?
            {
            // InternalSparrow.g:956:3: ( ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) ) )
            // InternalSparrow.g:957:4: ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) )
            {
            // InternalSparrow.g:957:4: ( (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' ) )
            // InternalSparrow.g:958:5: (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' )
            {
            // InternalSparrow.g:958:5: (lv_type_0_1= 'RA' | lv_type_0_2= 'AA' | lv_type_0_3= 'CA' | lv_type_0_4= 'PA' )
            int alt23=4;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt23=1;
                }
                break;
            case 44:
                {
                alt23=2;
                }
                break;
            case 45:
                {
                alt23=3;
                }
                break;
            case 46:
                {
                alt23=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalSparrow.g:959:6: lv_type_0_1= 'RA'
                    {
                    lv_type_0_1=(Token)match(input,43,FOLLOW_3); 

                    						newLeafNode(lv_type_0_1, grammarAccess.getSubjectAccess().getTypeRAKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSubjectRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:970:6: lv_type_0_2= 'AA'
                    {
                    lv_type_0_2=(Token)match(input,44,FOLLOW_3); 

                    						newLeafNode(lv_type_0_2, grammarAccess.getSubjectAccess().getTypeAAKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSubjectRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:981:6: lv_type_0_3= 'CA'
                    {
                    lv_type_0_3=(Token)match(input,45,FOLLOW_3); 

                    						newLeafNode(lv_type_0_3, grammarAccess.getSubjectAccess().getTypeCAKeyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSubjectRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:992:6: lv_type_0_4= 'PA'
                    {
                    lv_type_0_4=(Token)match(input,46,FOLLOW_3); 

                    						newLeafNode(lv_type_0_4, grammarAccess.getSubjectAccess().getTypePAKeyword_0_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSubjectRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_4, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSparrow.g:1005:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSparrow.g:1006:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSparrow.g:1006:4: (lv_name_1_0= RULE_ID )
            // InternalSparrow.g:1007:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_26); 

            					newLeafNode(lv_name_1_0, grammarAccess.getSubjectAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSubjectRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSparrow.g:1023:3: ( (lv_subjectExpression_2_0= ruleSubjectExpression ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==18) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalSparrow.g:1024:4: (lv_subjectExpression_2_0= ruleSubjectExpression )
                    {
                    // InternalSparrow.g:1024:4: (lv_subjectExpression_2_0= ruleSubjectExpression )
                    // InternalSparrow.g:1025:5: lv_subjectExpression_2_0= ruleSubjectExpression
                    {

                    					newCompositeNode(grammarAccess.getSubjectAccess().getSubjectExpressionSubjectExpressionParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_subjectExpression_2_0=ruleSubjectExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getSubjectRule());
                    					}
                    					set(
                    						current,
                    						"subjectExpression",
                    						lv_subjectExpression_2_0,
                    						"org.xtext.example.mydsl.Sparrow.SubjectExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubject"


    // $ANTLR start "entryRuleSubjectExpression"
    // InternalSparrow.g:1046:1: entryRuleSubjectExpression returns [EObject current=null] : iv_ruleSubjectExpression= ruleSubjectExpression EOF ;
    public final EObject entryRuleSubjectExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubjectExpression = null;


        try {
            // InternalSparrow.g:1046:58: (iv_ruleSubjectExpression= ruleSubjectExpression EOF )
            // InternalSparrow.g:1047:2: iv_ruleSubjectExpression= ruleSubjectExpression EOF
            {
             newCompositeNode(grammarAccess.getSubjectExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubjectExpression=ruleSubjectExpression();

            state._fsp--;

             current =iv_ruleSubjectExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubjectExpression"


    // $ANTLR start "ruleSubjectExpression"
    // InternalSparrow.g:1053:1: ruleSubjectExpression returns [EObject current=null] : (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' ) ;
    public final EObject ruleSubjectExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_keyValue_1_0 = null;

        EObject lv_keyValue_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1059:2: ( (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' ) )
            // InternalSparrow.g:1060:2: (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' )
            {
            // InternalSparrow.g:1060:2: (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' )
            // InternalSparrow.g:1061:3: otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_27); 

            			newLeafNode(otherlv_0, grammarAccess.getSubjectExpressionAccess().getLeftCurlyBracketKeyword_0());
            		
            // InternalSparrow.g:1065:3: ( (lv_keyValue_1_0= rulekeyvalue ) )
            // InternalSparrow.g:1066:4: (lv_keyValue_1_0= rulekeyvalue )
            {
            // InternalSparrow.g:1066:4: (lv_keyValue_1_0= rulekeyvalue )
            // InternalSparrow.g:1067:5: lv_keyValue_1_0= rulekeyvalue
            {

            					newCompositeNode(grammarAccess.getSubjectExpressionAccess().getKeyValueKeyvalueParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_25);
            lv_keyValue_1_0=rulekeyvalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSubjectExpressionRule());
            					}
            					add(
            						current,
            						"keyValue",
            						lv_keyValue_1_0,
            						"org.xtext.example.mydsl.Sparrow.keyvalue");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:1084:3: (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==22) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSparrow.g:1085:4: otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) )
            	    {
            	    otherlv_2=(Token)match(input,22,FOLLOW_27); 

            	    				newLeafNode(otherlv_2, grammarAccess.getSubjectExpressionAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalSparrow.g:1089:4: ( (lv_keyValue_3_0= rulekeyvalue ) )
            	    // InternalSparrow.g:1090:5: (lv_keyValue_3_0= rulekeyvalue )
            	    {
            	    // InternalSparrow.g:1090:5: (lv_keyValue_3_0= rulekeyvalue )
            	    // InternalSparrow.g:1091:6: lv_keyValue_3_0= rulekeyvalue
            	    {

            	    						newCompositeNode(grammarAccess.getSubjectExpressionAccess().getKeyValueKeyvalueParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    lv_keyValue_3_0=rulekeyvalue();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getSubjectExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"keyValue",
            	    							lv_keyValue_3_0,
            	    							"org.xtext.example.mydsl.Sparrow.keyvalue");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            otherlv_4=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getSubjectExpressionAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubjectExpression"


    // $ANTLR start "entryRuleContractMessage"
    // InternalSparrow.g:1117:1: entryRuleContractMessage returns [EObject current=null] : iv_ruleContractMessage= ruleContractMessage EOF ;
    public final EObject entryRuleContractMessage() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContractMessage = null;


        try {
            // InternalSparrow.g:1117:56: (iv_ruleContractMessage= ruleContractMessage EOF )
            // InternalSparrow.g:1118:2: iv_ruleContractMessage= ruleContractMessage EOF
            {
             newCompositeNode(grammarAccess.getContractMessageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContractMessage=ruleContractMessage();

            state._fsp--;

             current =iv_ruleContractMessage; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContractMessage"


    // $ANTLR start "ruleContractMessage"
    // InternalSparrow.g:1124:1: ruleContractMessage returns [EObject current=null] : (otherlv_0= 'ContractMessage' otherlv_1= '{' ( (lv_message_2_0= ruleMessage ) ) (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )* otherlv_5= '}' ) ;
    public final EObject ruleContractMessage() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_message_2_0 = null;

        EObject lv_message_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1130:2: ( (otherlv_0= 'ContractMessage' otherlv_1= '{' ( (lv_message_2_0= ruleMessage ) ) (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )* otherlv_5= '}' ) )
            // InternalSparrow.g:1131:2: (otherlv_0= 'ContractMessage' otherlv_1= '{' ( (lv_message_2_0= ruleMessage ) ) (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )* otherlv_5= '}' )
            {
            // InternalSparrow.g:1131:2: (otherlv_0= 'ContractMessage' otherlv_1= '{' ( (lv_message_2_0= ruleMessage ) ) (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )* otherlv_5= '}' )
            // InternalSparrow.g:1132:3: otherlv_0= 'ContractMessage' otherlv_1= '{' ( (lv_message_2_0= ruleMessage ) ) (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,47,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getContractMessageAccess().getContractMessageKeyword_0());
            		
            otherlv_1=(Token)match(input,18,FOLLOW_27); 

            			newLeafNode(otherlv_1, grammarAccess.getContractMessageAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalSparrow.g:1140:3: ( (lv_message_2_0= ruleMessage ) )
            // InternalSparrow.g:1141:4: (lv_message_2_0= ruleMessage )
            {
            // InternalSparrow.g:1141:4: (lv_message_2_0= ruleMessage )
            // InternalSparrow.g:1142:5: lv_message_2_0= ruleMessage
            {

            					newCompositeNode(grammarAccess.getContractMessageAccess().getMessageMessageParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_25);
            lv_message_2_0=ruleMessage();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContractMessageRule());
            					}
            					add(
            						current,
            						"message",
            						lv_message_2_0,
            						"org.xtext.example.mydsl.Sparrow.Message");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:1159:3: (otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==22) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSparrow.g:1160:4: otherlv_3= ',' ( (lv_message_4_0= ruleMessage ) )
            	    {
            	    otherlv_3=(Token)match(input,22,FOLLOW_27); 

            	    				newLeafNode(otherlv_3, grammarAccess.getContractMessageAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalSparrow.g:1164:4: ( (lv_message_4_0= ruleMessage ) )
            	    // InternalSparrow.g:1165:5: (lv_message_4_0= ruleMessage )
            	    {
            	    // InternalSparrow.g:1165:5: (lv_message_4_0= ruleMessage )
            	    // InternalSparrow.g:1166:6: lv_message_4_0= ruleMessage
            	    {

            	    						newCompositeNode(grammarAccess.getContractMessageAccess().getMessageMessageParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    lv_message_4_0=ruleMessage();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getContractMessageRule());
            	    						}
            	    						add(
            	    							current,
            	    							"message",
            	    							lv_message_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.Message");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            otherlv_5=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getContractMessageAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContractMessage"


    // $ANTLR start "entryRuleMessage"
    // InternalSparrow.g:1192:1: entryRuleMessage returns [EObject current=null] : iv_ruleMessage= ruleMessage EOF ;
    public final EObject entryRuleMessage() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMessage = null;


        try {
            // InternalSparrow.g:1192:48: (iv_ruleMessage= ruleMessage EOF )
            // InternalSparrow.g:1193:2: iv_ruleMessage= ruleMessage EOF
            {
             newCompositeNode(grammarAccess.getMessageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMessage=ruleMessage();

            state._fsp--;

             current =iv_ruleMessage; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMessage"


    // $ANTLR start "ruleMessage"
    // InternalSparrow.g:1199:1: ruleMessage returns [EObject current=null] : ( ( (lv_type_0_0= rulekeyvalue ) ) otherlv_1= '=' ( (lv_value_2_0= ruleValue ) ) ) ;
    public final EObject ruleMessage() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_type_0_0 = null;

        EObject lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1205:2: ( ( ( (lv_type_0_0= rulekeyvalue ) ) otherlv_1= '=' ( (lv_value_2_0= ruleValue ) ) ) )
            // InternalSparrow.g:1206:2: ( ( (lv_type_0_0= rulekeyvalue ) ) otherlv_1= '=' ( (lv_value_2_0= ruleValue ) ) )
            {
            // InternalSparrow.g:1206:2: ( ( (lv_type_0_0= rulekeyvalue ) ) otherlv_1= '=' ( (lv_value_2_0= ruleValue ) ) )
            // InternalSparrow.g:1207:3: ( (lv_type_0_0= rulekeyvalue ) ) otherlv_1= '=' ( (lv_value_2_0= ruleValue ) )
            {
            // InternalSparrow.g:1207:3: ( (lv_type_0_0= rulekeyvalue ) )
            // InternalSparrow.g:1208:4: (lv_type_0_0= rulekeyvalue )
            {
            // InternalSparrow.g:1208:4: (lv_type_0_0= rulekeyvalue )
            // InternalSparrow.g:1209:5: lv_type_0_0= rulekeyvalue
            {

            					newCompositeNode(grammarAccess.getMessageAccess().getTypeKeyvalueParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_21);
            lv_type_0_0=rulekeyvalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMessageRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.example.mydsl.Sparrow.keyvalue");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_1=(Token)match(input,38,FOLLOW_23); 

            			newLeafNode(otherlv_1, grammarAccess.getMessageAccess().getEqualsSignKeyword_1());
            		
            // InternalSparrow.g:1230:3: ( (lv_value_2_0= ruleValue ) )
            // InternalSparrow.g:1231:4: (lv_value_2_0= ruleValue )
            {
            // InternalSparrow.g:1231:4: (lv_value_2_0= ruleValue )
            // InternalSparrow.g:1232:5: lv_value_2_0= ruleValue
            {

            					newCompositeNode(grammarAccess.getMessageAccess().getValueValueParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_2_0=ruleValue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMessageRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"org.xtext.example.mydsl.Sparrow.Value");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMessage"


    // $ANTLR start "entryRulekeyvalue"
    // InternalSparrow.g:1253:1: entryRulekeyvalue returns [EObject current=null] : iv_rulekeyvalue= rulekeyvalue EOF ;
    public final EObject entryRulekeyvalue() throws RecognitionException {
        EObject current = null;

        EObject iv_rulekeyvalue = null;


        try {
            // InternalSparrow.g:1253:49: (iv_rulekeyvalue= rulekeyvalue EOF )
            // InternalSparrow.g:1254:2: iv_rulekeyvalue= rulekeyvalue EOF
            {
             newCompositeNode(grammarAccess.getKeyvalueRule()); 
            pushFollow(FOLLOW_1);
            iv_rulekeyvalue=rulekeyvalue();

            state._fsp--;

             current =iv_rulekeyvalue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulekeyvalue"


    // $ANTLR start "rulekeyvalue"
    // InternalSparrow.g:1260:1: rulekeyvalue returns [EObject current=null] : ( ( (lv_type_0_0= ruletype ) ) ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject rulekeyvalue() throws RecognitionException {
        EObject current = null;

        Token lv_name_1_0=null;
        AntlrDatatypeRuleToken lv_type_0_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1266:2: ( ( ( (lv_type_0_0= ruletype ) ) ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalSparrow.g:1267:2: ( ( (lv_type_0_0= ruletype ) ) ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalSparrow.g:1267:2: ( ( (lv_type_0_0= ruletype ) ) ( (lv_name_1_0= RULE_ID ) ) )
            // InternalSparrow.g:1268:3: ( (lv_type_0_0= ruletype ) ) ( (lv_name_1_0= RULE_ID ) )
            {
            // InternalSparrow.g:1268:3: ( (lv_type_0_0= ruletype ) )
            // InternalSparrow.g:1269:4: (lv_type_0_0= ruletype )
            {
            // InternalSparrow.g:1269:4: (lv_type_0_0= ruletype )
            // InternalSparrow.g:1270:5: lv_type_0_0= ruletype
            {

            					newCompositeNode(grammarAccess.getKeyvalueAccess().getTypeTypeParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_type_0_0=ruletype();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getKeyvalueRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.example.mydsl.Sparrow.type");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:1287:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSparrow.g:1288:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSparrow.g:1288:4: (lv_name_1_0= RULE_ID )
            // InternalSparrow.g:1289:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_1_0, grammarAccess.getKeyvalueAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getKeyvalueRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulekeyvalue"


    // $ANTLR start "entryRuletype"
    // InternalSparrow.g:1309:1: entryRuletype returns [String current=null] : iv_ruletype= ruletype EOF ;
    public final String entryRuletype() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruletype = null;


        try {
            // InternalSparrow.g:1309:44: (iv_ruletype= ruletype EOF )
            // InternalSparrow.g:1310:2: iv_ruletype= ruletype EOF
            {
             newCompositeNode(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruletype=ruletype();

            state._fsp--;

             current =iv_ruletype.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuletype"


    // $ANTLR start "ruletype"
    // InternalSparrow.g:1316:1: ruletype returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'string' | kw= 'uint' | kw= 'address' | kw= 'int' | kw= 'bytes' | kw= 'bytes32' | kw= 'bool' | kw= 'fixed' | kw= 'ufixed' | kw= 'date' | kw= 'duration' ) ;
    public final AntlrDatatypeRuleToken ruletype() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:1322:2: ( (kw= 'string' | kw= 'uint' | kw= 'address' | kw= 'int' | kw= 'bytes' | kw= 'bytes32' | kw= 'bool' | kw= 'fixed' | kw= 'ufixed' | kw= 'date' | kw= 'duration' ) )
            // InternalSparrow.g:1323:2: (kw= 'string' | kw= 'uint' | kw= 'address' | kw= 'int' | kw= 'bytes' | kw= 'bytes32' | kw= 'bool' | kw= 'fixed' | kw= 'ufixed' | kw= 'date' | kw= 'duration' )
            {
            // InternalSparrow.g:1323:2: (kw= 'string' | kw= 'uint' | kw= 'address' | kw= 'int' | kw= 'bytes' | kw= 'bytes32' | kw= 'bool' | kw= 'fixed' | kw= 'ufixed' | kw= 'date' | kw= 'duration' )
            int alt27=11;
            switch ( input.LA(1) ) {
            case 48:
                {
                alt27=1;
                }
                break;
            case 49:
                {
                alt27=2;
                }
                break;
            case 50:
                {
                alt27=3;
                }
                break;
            case 51:
                {
                alt27=4;
                }
                break;
            case 52:
                {
                alt27=5;
                }
                break;
            case 53:
                {
                alt27=6;
                }
                break;
            case 54:
                {
                alt27=7;
                }
                break;
            case 55:
                {
                alt27=8;
                }
                break;
            case 56:
                {
                alt27=9;
                }
                break;
            case 57:
                {
                alt27=10;
                }
                break;
            case 58:
                {
                alt27=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }

            switch (alt27) {
                case 1 :
                    // InternalSparrow.g:1324:3: kw= 'string'
                    {
                    kw=(Token)match(input,48,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getStringKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:1330:3: kw= 'uint'
                    {
                    kw=(Token)match(input,49,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getUintKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:1336:3: kw= 'address'
                    {
                    kw=(Token)match(input,50,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getAddressKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:1342:3: kw= 'int'
                    {
                    kw=(Token)match(input,51,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getIntKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:1348:3: kw= 'bytes'
                    {
                    kw=(Token)match(input,52,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getBytesKeyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSparrow.g:1354:3: kw= 'bytes32'
                    {
                    kw=(Token)match(input,53,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getBytes32Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSparrow.g:1360:3: kw= 'bool'
                    {
                    kw=(Token)match(input,54,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getBoolKeyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSparrow.g:1366:3: kw= 'fixed'
                    {
                    kw=(Token)match(input,55,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getFixedKeyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSparrow.g:1372:3: kw= 'ufixed'
                    {
                    kw=(Token)match(input,56,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getUfixedKeyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSparrow.g:1378:3: kw= 'date'
                    {
                    kw=(Token)match(input,57,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getDateKeyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSparrow.g:1384:3: kw= 'duration'
                    {
                    kw=(Token)match(input,58,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAccess().getDurationKeyword_10());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruletype"


    // $ANTLR start "entryRuleValue"
    // InternalSparrow.g:1393:1: entryRuleValue returns [EObject current=null] : iv_ruleValue= ruleValue EOF ;
    public final EObject entryRuleValue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValue = null;


        try {
            // InternalSparrow.g:1393:46: (iv_ruleValue= ruleValue EOF )
            // InternalSparrow.g:1394:2: iv_ruleValue= ruleValue EOF
            {
             newCompositeNode(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValue=ruleValue();

            state._fsp--;

             current =iv_ruleValue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValue"


    // $ANTLR start "ruleValue"
    // InternalSparrow.g:1400:1: ruleValue returns [EObject current=null] : (this_AllNumber_0= ruleAllNumber | this_Right_1= ruleRight | this_ThisDate_2= ruleThisDate | this_ThisBoolean_3= ruleThisBoolean | this_url_4= ruleurl | this_ThisDecimal_5= ruleThisDecimal | this_Address_6= ruleAddress | this_ThisString_7= ruleThisString | this_Duration_8= ruleDuration | this_Now_9= ruleNow ) ;
    public final EObject ruleValue() throws RecognitionException {
        EObject current = null;

        EObject this_AllNumber_0 = null;

        EObject this_Right_1 = null;

        EObject this_ThisDate_2 = null;

        EObject this_ThisBoolean_3 = null;

        EObject this_url_4 = null;

        EObject this_ThisDecimal_5 = null;

        EObject this_Address_6 = null;

        EObject this_ThisString_7 = null;

        EObject this_Duration_8 = null;

        EObject this_Now_9 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1406:2: ( (this_AllNumber_0= ruleAllNumber | this_Right_1= ruleRight | this_ThisDate_2= ruleThisDate | this_ThisBoolean_3= ruleThisBoolean | this_url_4= ruleurl | this_ThisDecimal_5= ruleThisDecimal | this_Address_6= ruleAddress | this_ThisString_7= ruleThisString | this_Duration_8= ruleDuration | this_Now_9= ruleNow ) )
            // InternalSparrow.g:1407:2: (this_AllNumber_0= ruleAllNumber | this_Right_1= ruleRight | this_ThisDate_2= ruleThisDate | this_ThisBoolean_3= ruleThisBoolean | this_url_4= ruleurl | this_ThisDecimal_5= ruleThisDecimal | this_Address_6= ruleAddress | this_ThisString_7= ruleThisString | this_Duration_8= ruleDuration | this_Now_9= ruleNow )
            {
            // InternalSparrow.g:1407:2: (this_AllNumber_0= ruleAllNumber | this_Right_1= ruleRight | this_ThisDate_2= ruleThisDate | this_ThisBoolean_3= ruleThisBoolean | this_url_4= ruleurl | this_ThisDecimal_5= ruleThisDecimal | this_Address_6= ruleAddress | this_ThisString_7= ruleThisString | this_Duration_8= ruleDuration | this_Now_9= ruleNow )
            int alt28=10;
            alt28 = dfa28.predict(input);
            switch (alt28) {
                case 1 :
                    // InternalSparrow.g:1408:3: this_AllNumber_0= ruleAllNumber
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getAllNumberParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_AllNumber_0=ruleAllNumber();

                    state._fsp--;


                    			current = this_AllNumber_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:1417:3: this_Right_1= ruleRight
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getRightParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Right_1=ruleRight();

                    state._fsp--;


                    			current = this_Right_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:1426:3: this_ThisDate_2= ruleThisDate
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getThisDateParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisDate_2=ruleThisDate();

                    state._fsp--;


                    			current = this_ThisDate_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:1435:3: this_ThisBoolean_3= ruleThisBoolean
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getThisBooleanParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisBoolean_3=ruleThisBoolean();

                    state._fsp--;


                    			current = this_ThisBoolean_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:1444:3: this_url_4= ruleurl
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getUrlParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_url_4=ruleurl();

                    state._fsp--;


                    			current = this_url_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSparrow.g:1453:3: this_ThisDecimal_5= ruleThisDecimal
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getThisDecimalParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisDecimal_5=ruleThisDecimal();

                    state._fsp--;


                    			current = this_ThisDecimal_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSparrow.g:1462:3: this_Address_6= ruleAddress
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getAddressParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_Address_6=ruleAddress();

                    state._fsp--;


                    			current = this_Address_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSparrow.g:1471:3: this_ThisString_7= ruleThisString
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getThisStringParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisString_7=ruleThisString();

                    state._fsp--;


                    			current = this_ThisString_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 9 :
                    // InternalSparrow.g:1480:3: this_Duration_8= ruleDuration
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getDurationParserRuleCall_8());
                    		
                    pushFollow(FOLLOW_2);
                    this_Duration_8=ruleDuration();

                    state._fsp--;


                    			current = this_Duration_8;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 10 :
                    // InternalSparrow.g:1489:3: this_Now_9= ruleNow
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getNowParserRuleCall_9());
                    		
                    pushFollow(FOLLOW_2);
                    this_Now_9=ruleNow();

                    state._fsp--;


                    			current = this_Now_9;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValue"


    // $ANTLR start "entryRuleDuration"
    // InternalSparrow.g:1501:1: entryRuleDuration returns [EObject current=null] : iv_ruleDuration= ruleDuration EOF ;
    public final EObject entryRuleDuration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDuration = null;


        try {
            // InternalSparrow.g:1501:49: (iv_ruleDuration= ruleDuration EOF )
            // InternalSparrow.g:1502:2: iv_ruleDuration= ruleDuration EOF
            {
             newCompositeNode(grammarAccess.getDurationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDuration=ruleDuration();

            state._fsp--;

             current =iv_ruleDuration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDuration"


    // $ANTLR start "ruleDuration"
    // InternalSparrow.g:1508:1: ruleDuration returns [EObject current=null] : ( ( (lv_value_0_0= RULE_INT ) ) ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) ) ) ;
    public final EObject ruleDuration() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;
        Token lv_symbol_1_1=null;
        Token lv_symbol_1_2=null;
        Token lv_symbol_1_3=null;
        Token lv_symbol_1_4=null;


        	enterRule();

        try {
            // InternalSparrow.g:1514:2: ( ( ( (lv_value_0_0= RULE_INT ) ) ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) ) ) )
            // InternalSparrow.g:1515:2: ( ( (lv_value_0_0= RULE_INT ) ) ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) ) )
            {
            // InternalSparrow.g:1515:2: ( ( (lv_value_0_0= RULE_INT ) ) ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) ) )
            // InternalSparrow.g:1516:3: ( (lv_value_0_0= RULE_INT ) ) ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) )
            {
            // InternalSparrow.g:1516:3: ( (lv_value_0_0= RULE_INT ) )
            // InternalSparrow.g:1517:4: (lv_value_0_0= RULE_INT )
            {
            // InternalSparrow.g:1517:4: (lv_value_0_0= RULE_INT )
            // InternalSparrow.g:1518:5: lv_value_0_0= RULE_INT
            {
            lv_value_0_0=(Token)match(input,RULE_INT,FOLLOW_28); 

            					newLeafNode(lv_value_0_0, grammarAccess.getDurationAccess().getValueINTTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_0_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSparrow.g:1534:3: ( ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) ) )
            // InternalSparrow.g:1535:4: ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) )
            {
            // InternalSparrow.g:1535:4: ( (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' ) )
            // InternalSparrow.g:1536:5: (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' )
            {
            // InternalSparrow.g:1536:5: (lv_symbol_1_1= 'months' | lv_symbol_1_2= 'days' | lv_symbol_1_3= 'hours' | lv_symbol_1_4= 'minutes' )
            int alt29=4;
            switch ( input.LA(1) ) {
            case 59:
                {
                alt29=1;
                }
                break;
            case 60:
                {
                alt29=2;
                }
                break;
            case 61:
                {
                alt29=3;
                }
                break;
            case 62:
                {
                alt29=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }

            switch (alt29) {
                case 1 :
                    // InternalSparrow.g:1537:6: lv_symbol_1_1= 'months'
                    {
                    lv_symbol_1_1=(Token)match(input,59,FOLLOW_2); 

                    						newLeafNode(lv_symbol_1_1, grammarAccess.getDurationAccess().getSymbolMonthsKeyword_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDurationRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_1_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:1548:6: lv_symbol_1_2= 'days'
                    {
                    lv_symbol_1_2=(Token)match(input,60,FOLLOW_2); 

                    						newLeafNode(lv_symbol_1_2, grammarAccess.getDurationAccess().getSymbolDaysKeyword_1_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDurationRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_1_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:1559:6: lv_symbol_1_3= 'hours'
                    {
                    lv_symbol_1_3=(Token)match(input,61,FOLLOW_2); 

                    						newLeafNode(lv_symbol_1_3, grammarAccess.getDurationAccess().getSymbolHoursKeyword_1_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDurationRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_1_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:1570:6: lv_symbol_1_4= 'minutes'
                    {
                    lv_symbol_1_4=(Token)match(input,62,FOLLOW_2); 

                    						newLeafNode(lv_symbol_1_4, grammarAccess.getDurationAccess().getSymbolMinutesKeyword_1_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDurationRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_1_4, null);
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDuration"


    // $ANTLR start "entryRuleNow"
    // InternalSparrow.g:1587:1: entryRuleNow returns [EObject current=null] : iv_ruleNow= ruleNow EOF ;
    public final EObject entryRuleNow() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNow = null;


        try {
            // InternalSparrow.g:1587:44: (iv_ruleNow= ruleNow EOF )
            // InternalSparrow.g:1588:2: iv_ruleNow= ruleNow EOF
            {
             newCompositeNode(grammarAccess.getNowRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNow=ruleNow();

            state._fsp--;

             current =iv_ruleNow; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNow"


    // $ANTLR start "ruleNow"
    // InternalSparrow.g:1594:1: ruleNow returns [EObject current=null] : ( (lv_value_0_0= 'now' ) ) ;
    public final EObject ruleNow() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1600:2: ( ( (lv_value_0_0= 'now' ) ) )
            // InternalSparrow.g:1601:2: ( (lv_value_0_0= 'now' ) )
            {
            // InternalSparrow.g:1601:2: ( (lv_value_0_0= 'now' ) )
            // InternalSparrow.g:1602:3: (lv_value_0_0= 'now' )
            {
            // InternalSparrow.g:1602:3: (lv_value_0_0= 'now' )
            // InternalSparrow.g:1603:4: lv_value_0_0= 'now'
            {
            lv_value_0_0=(Token)match(input,63,FOLLOW_2); 

            				newLeafNode(lv_value_0_0, grammarAccess.getNowAccess().getValueNowKeyword_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getNowRule());
            				}
            				setWithLastConsumed(current, "value", lv_value_0_0, "now");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNow"


    // $ANTLR start "entryRuleThisString"
    // InternalSparrow.g:1618:1: entryRuleThisString returns [EObject current=null] : iv_ruleThisString= ruleThisString EOF ;
    public final EObject entryRuleThisString() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisString = null;


        try {
            // InternalSparrow.g:1618:51: (iv_ruleThisString= ruleThisString EOF )
            // InternalSparrow.g:1619:2: iv_ruleThisString= ruleThisString EOF
            {
             newCompositeNode(grammarAccess.getThisStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisString=ruleThisString();

            state._fsp--;

             current =iv_ruleThisString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisString"


    // $ANTLR start "ruleThisString"
    // InternalSparrow.g:1625:1: ruleThisString returns [EObject current=null] : ( (lv_value_0_0= RULE_STRING ) ) ;
    public final EObject ruleThisString() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1631:2: ( ( (lv_value_0_0= RULE_STRING ) ) )
            // InternalSparrow.g:1632:2: ( (lv_value_0_0= RULE_STRING ) )
            {
            // InternalSparrow.g:1632:2: ( (lv_value_0_0= RULE_STRING ) )
            // InternalSparrow.g:1633:3: (lv_value_0_0= RULE_STRING )
            {
            // InternalSparrow.g:1633:3: (lv_value_0_0= RULE_STRING )
            // InternalSparrow.g:1634:4: lv_value_0_0= RULE_STRING
            {
            lv_value_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            				newLeafNode(lv_value_0_0, grammarAccess.getThisStringAccess().getValueSTRINGTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getThisStringRule());
            				}
            				setWithLastConsumed(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.eclipse.xtext.common.Terminals.STRING");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisString"


    // $ANTLR start "entryRuleAddress"
    // InternalSparrow.g:1653:1: entryRuleAddress returns [EObject current=null] : iv_ruleAddress= ruleAddress EOF ;
    public final EObject entryRuleAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAddress = null;


        try {
            // InternalSparrow.g:1653:48: (iv_ruleAddress= ruleAddress EOF )
            // InternalSparrow.g:1654:2: iv_ruleAddress= ruleAddress EOF
            {
             newCompositeNode(grammarAccess.getAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAddress=ruleAddress();

            state._fsp--;

             current =iv_ruleAddress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAddress"


    // $ANTLR start "ruleAddress"
    // InternalSparrow.g:1660:1: ruleAddress returns [EObject current=null] : (otherlv_0= 'a' ( (lv_value_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleAddress() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_value_1_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1666:2: ( (otherlv_0= 'a' ( (lv_value_1_0= RULE_STRING ) ) ) )
            // InternalSparrow.g:1667:2: (otherlv_0= 'a' ( (lv_value_1_0= RULE_STRING ) ) )
            {
            // InternalSparrow.g:1667:2: (otherlv_0= 'a' ( (lv_value_1_0= RULE_STRING ) ) )
            // InternalSparrow.g:1668:3: otherlv_0= 'a' ( (lv_value_1_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,64,FOLLOW_29); 

            			newLeafNode(otherlv_0, grammarAccess.getAddressAccess().getAKeyword_0());
            		
            // InternalSparrow.g:1672:3: ( (lv_value_1_0= RULE_STRING ) )
            // InternalSparrow.g:1673:4: (lv_value_1_0= RULE_STRING )
            {
            // InternalSparrow.g:1673:4: (lv_value_1_0= RULE_STRING )
            // InternalSparrow.g:1674:5: lv_value_1_0= RULE_STRING
            {
            lv_value_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_value_1_0, grammarAccess.getAddressAccess().getValueSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAddressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAddress"


    // $ANTLR start "entryRuleAllNumber"
    // InternalSparrow.g:1694:1: entryRuleAllNumber returns [EObject current=null] : iv_ruleAllNumber= ruleAllNumber EOF ;
    public final EObject entryRuleAllNumber() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAllNumber = null;


        try {
            // InternalSparrow.g:1694:50: (iv_ruleAllNumber= ruleAllNumber EOF )
            // InternalSparrow.g:1695:2: iv_ruleAllNumber= ruleAllNumber EOF
            {
             newCompositeNode(grammarAccess.getAllNumberRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAllNumber=ruleAllNumber();

            state._fsp--;

             current =iv_ruleAllNumber; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAllNumber"


    // $ANTLR start "ruleAllNumber"
    // InternalSparrow.g:1701:1: ruleAllNumber returns [EObject current=null] : ( (lv_number_0_0= RULE_INT ) ) ;
    public final EObject ruleAllNumber() throws RecognitionException {
        EObject current = null;

        Token lv_number_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1707:2: ( ( (lv_number_0_0= RULE_INT ) ) )
            // InternalSparrow.g:1708:2: ( (lv_number_0_0= RULE_INT ) )
            {
            // InternalSparrow.g:1708:2: ( (lv_number_0_0= RULE_INT ) )
            // InternalSparrow.g:1709:3: (lv_number_0_0= RULE_INT )
            {
            // InternalSparrow.g:1709:3: (lv_number_0_0= RULE_INT )
            // InternalSparrow.g:1710:4: lv_number_0_0= RULE_INT
            {
            lv_number_0_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            				newLeafNode(lv_number_0_0, grammarAccess.getAllNumberAccess().getNumberINTTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getAllNumberRule());
            				}
            				setWithLastConsumed(
            					current,
            					"number",
            					lv_number_0_0,
            					"org.eclipse.xtext.common.Terminals.INT");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAllNumber"


    // $ANTLR start "entryRuleThisDecimal"
    // InternalSparrow.g:1729:1: entryRuleThisDecimal returns [EObject current=null] : iv_ruleThisDecimal= ruleThisDecimal EOF ;
    public final EObject entryRuleThisDecimal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisDecimal = null;


        try {
            // InternalSparrow.g:1729:52: (iv_ruleThisDecimal= ruleThisDecimal EOF )
            // InternalSparrow.g:1730:2: iv_ruleThisDecimal= ruleThisDecimal EOF
            {
             newCompositeNode(grammarAccess.getThisDecimalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisDecimal=ruleThisDecimal();

            state._fsp--;

             current =iv_ruleThisDecimal; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisDecimal"


    // $ANTLR start "ruleThisDecimal"
    // InternalSparrow.g:1736:1: ruleThisDecimal returns [EObject current=null] : ( (lv_value_0_0= RULE_DECIMAL ) ) ;
    public final EObject ruleThisDecimal() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1742:2: ( ( (lv_value_0_0= RULE_DECIMAL ) ) )
            // InternalSparrow.g:1743:2: ( (lv_value_0_0= RULE_DECIMAL ) )
            {
            // InternalSparrow.g:1743:2: ( (lv_value_0_0= RULE_DECIMAL ) )
            // InternalSparrow.g:1744:3: (lv_value_0_0= RULE_DECIMAL )
            {
            // InternalSparrow.g:1744:3: (lv_value_0_0= RULE_DECIMAL )
            // InternalSparrow.g:1745:4: lv_value_0_0= RULE_DECIMAL
            {
            lv_value_0_0=(Token)match(input,RULE_DECIMAL,FOLLOW_2); 

            				newLeafNode(lv_value_0_0, grammarAccess.getThisDecimalAccess().getValueDECIMALTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getThisDecimalRule());
            				}
            				setWithLastConsumed(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.xtext.example.mydsl.Sparrow.DECIMAL");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisDecimal"


    // $ANTLR start "entryRuleurl"
    // InternalSparrow.g:1764:1: entryRuleurl returns [EObject current=null] : iv_ruleurl= ruleurl EOF ;
    public final EObject entryRuleurl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleurl = null;


        try {
            // InternalSparrow.g:1764:44: (iv_ruleurl= ruleurl EOF )
            // InternalSparrow.g:1765:2: iv_ruleurl= ruleurl EOF
            {
             newCompositeNode(grammarAccess.getUrlRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleurl=ruleurl();

            state._fsp--;

             current =iv_ruleurl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleurl"


    // $ANTLR start "ruleurl"
    // InternalSparrow.g:1771:1: ruleurl returns [EObject current=null] : ( (lv_value_0_0= RULE_URL_STRING ) ) ;
    public final EObject ruleurl() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1777:2: ( ( (lv_value_0_0= RULE_URL_STRING ) ) )
            // InternalSparrow.g:1778:2: ( (lv_value_0_0= RULE_URL_STRING ) )
            {
            // InternalSparrow.g:1778:2: ( (lv_value_0_0= RULE_URL_STRING ) )
            // InternalSparrow.g:1779:3: (lv_value_0_0= RULE_URL_STRING )
            {
            // InternalSparrow.g:1779:3: (lv_value_0_0= RULE_URL_STRING )
            // InternalSparrow.g:1780:4: lv_value_0_0= RULE_URL_STRING
            {
            lv_value_0_0=(Token)match(input,RULE_URL_STRING,FOLLOW_2); 

            				newLeafNode(lv_value_0_0, grammarAccess.getUrlAccess().getValueURL_STRINGTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getUrlRule());
            				}
            				setWithLastConsumed(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.xtext.example.mydsl.Sparrow.URL_STRING");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleurl"


    // $ANTLR start "entryRuleThisBoolean"
    // InternalSparrow.g:1799:1: entryRuleThisBoolean returns [EObject current=null] : iv_ruleThisBoolean= ruleThisBoolean EOF ;
    public final EObject entryRuleThisBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisBoolean = null;


        try {
            // InternalSparrow.g:1799:52: (iv_ruleThisBoolean= ruleThisBoolean EOF )
            // InternalSparrow.g:1800:2: iv_ruleThisBoolean= ruleThisBoolean EOF
            {
             newCompositeNode(grammarAccess.getThisBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisBoolean=ruleThisBoolean();

            state._fsp--;

             current =iv_ruleThisBoolean; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisBoolean"


    // $ANTLR start "ruleThisBoolean"
    // InternalSparrow.g:1806:1: ruleThisBoolean returns [EObject current=null] : ( (lv_value_0_0= ruleBOOLEAN ) ) ;
    public final EObject ruleThisBoolean() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_value_0_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1812:2: ( ( (lv_value_0_0= ruleBOOLEAN ) ) )
            // InternalSparrow.g:1813:2: ( (lv_value_0_0= ruleBOOLEAN ) )
            {
            // InternalSparrow.g:1813:2: ( (lv_value_0_0= ruleBOOLEAN ) )
            // InternalSparrow.g:1814:3: (lv_value_0_0= ruleBOOLEAN )
            {
            // InternalSparrow.g:1814:3: (lv_value_0_0= ruleBOOLEAN )
            // InternalSparrow.g:1815:4: lv_value_0_0= ruleBOOLEAN
            {

            				newCompositeNode(grammarAccess.getThisBooleanAccess().getValueBOOLEANParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_value_0_0=ruleBOOLEAN();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getThisBooleanRule());
            				}
            				set(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.xtext.example.mydsl.Sparrow.BOOLEAN");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisBoolean"


    // $ANTLR start "entryRuleThisDate"
    // InternalSparrow.g:1835:1: entryRuleThisDate returns [EObject current=null] : iv_ruleThisDate= ruleThisDate EOF ;
    public final EObject entryRuleThisDate() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisDate = null;


        try {
            // InternalSparrow.g:1835:49: (iv_ruleThisDate= ruleThisDate EOF )
            // InternalSparrow.g:1836:2: iv_ruleThisDate= ruleThisDate EOF
            {
             newCompositeNode(grammarAccess.getThisDateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisDate=ruleThisDate();

            state._fsp--;

             current =iv_ruleThisDate; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisDate"


    // $ANTLR start "ruleThisDate"
    // InternalSparrow.g:1842:1: ruleThisDate returns [EObject current=null] : ( (lv_value_0_0= ruleDATE ) ) ;
    public final EObject ruleThisDate() throws RecognitionException {
        EObject current = null;

        EObject lv_value_0_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:1848:2: ( ( (lv_value_0_0= ruleDATE ) ) )
            // InternalSparrow.g:1849:2: ( (lv_value_0_0= ruleDATE ) )
            {
            // InternalSparrow.g:1849:2: ( (lv_value_0_0= ruleDATE ) )
            // InternalSparrow.g:1850:3: (lv_value_0_0= ruleDATE )
            {
            // InternalSparrow.g:1850:3: (lv_value_0_0= ruleDATE )
            // InternalSparrow.g:1851:4: lv_value_0_0= ruleDATE
            {

            				newCompositeNode(grammarAccess.getThisDateAccess().getValueDATEParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_value_0_0=ruleDATE();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getThisDateRule());
            				}
            				set(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.xtext.example.mydsl.Sparrow.DATE");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisDate"


    // $ANTLR start "entryRuleRight"
    // InternalSparrow.g:1871:1: entryRuleRight returns [EObject current=null] : iv_ruleRight= ruleRight EOF ;
    public final EObject entryRuleRight() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRight = null;


        try {
            // InternalSparrow.g:1871:46: (iv_ruleRight= ruleRight EOF )
            // InternalSparrow.g:1872:2: iv_ruleRight= ruleRight EOF
            {
             newCompositeNode(grammarAccess.getRightRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRight=ruleRight();

            state._fsp--;

             current =iv_ruleRight; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRight"


    // $ANTLR start "ruleRight"
    // InternalSparrow.g:1878:1: ruleRight returns [EObject current=null] : ( (otherlv_0= RULE_ID ) ) ;
    public final EObject ruleRight() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1884:2: ( ( (otherlv_0= RULE_ID ) ) )
            // InternalSparrow.g:1885:2: ( (otherlv_0= RULE_ID ) )
            {
            // InternalSparrow.g:1885:2: ( (otherlv_0= RULE_ID ) )
            // InternalSparrow.g:1886:3: (otherlv_0= RULE_ID )
            {
            // InternalSparrow.g:1886:3: (otherlv_0= RULE_ID )
            // InternalSparrow.g:1887:4: otherlv_0= RULE_ID
            {

            				if (current==null) {
            					current = createModelElement(grammarAccess.getRightRule());
            				}
            			
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            				newLeafNode(otherlv_0, grammarAccess.getRightAccess().getRightInitExpressionsCrossReference_0());
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRight"


    // $ANTLR start "entryRuleDATE"
    // InternalSparrow.g:1901:1: entryRuleDATE returns [EObject current=null] : iv_ruleDATE= ruleDATE EOF ;
    public final EObject entryRuleDATE() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDATE = null;


        try {
            // InternalSparrow.g:1901:45: (iv_ruleDATE= ruleDATE EOF )
            // InternalSparrow.g:1902:2: iv_ruleDATE= ruleDATE EOF
            {
             newCompositeNode(grammarAccess.getDATERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDATE=ruleDATE();

            state._fsp--;

             current =iv_ruleDATE; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDATE"


    // $ANTLR start "ruleDATE"
    // InternalSparrow.g:1908:1: ruleDATE returns [EObject current=null] : ( ( (lv_year_0_0= RULE_INT ) ) otherlv_1= '/' ( (lv_month_2_0= RULE_INT ) ) otherlv_3= '/' ( (lv_day_4_0= RULE_INT ) ) otherlv_5= ',' ( (lv_hour_6_0= RULE_INT ) ) otherlv_7= ':' ( (lv_min_8_0= RULE_INT ) ) ) ;
    public final EObject ruleDATE() throws RecognitionException {
        EObject current = null;

        Token lv_year_0_0=null;
        Token otherlv_1=null;
        Token lv_month_2_0=null;
        Token otherlv_3=null;
        Token lv_day_4_0=null;
        Token otherlv_5=null;
        Token lv_hour_6_0=null;
        Token otherlv_7=null;
        Token lv_min_8_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:1914:2: ( ( ( (lv_year_0_0= RULE_INT ) ) otherlv_1= '/' ( (lv_month_2_0= RULE_INT ) ) otherlv_3= '/' ( (lv_day_4_0= RULE_INT ) ) otherlv_5= ',' ( (lv_hour_6_0= RULE_INT ) ) otherlv_7= ':' ( (lv_min_8_0= RULE_INT ) ) ) )
            // InternalSparrow.g:1915:2: ( ( (lv_year_0_0= RULE_INT ) ) otherlv_1= '/' ( (lv_month_2_0= RULE_INT ) ) otherlv_3= '/' ( (lv_day_4_0= RULE_INT ) ) otherlv_5= ',' ( (lv_hour_6_0= RULE_INT ) ) otherlv_7= ':' ( (lv_min_8_0= RULE_INT ) ) )
            {
            // InternalSparrow.g:1915:2: ( ( (lv_year_0_0= RULE_INT ) ) otherlv_1= '/' ( (lv_month_2_0= RULE_INT ) ) otherlv_3= '/' ( (lv_day_4_0= RULE_INT ) ) otherlv_5= ',' ( (lv_hour_6_0= RULE_INT ) ) otherlv_7= ':' ( (lv_min_8_0= RULE_INT ) ) )
            // InternalSparrow.g:1916:3: ( (lv_year_0_0= RULE_INT ) ) otherlv_1= '/' ( (lv_month_2_0= RULE_INT ) ) otherlv_3= '/' ( (lv_day_4_0= RULE_INT ) ) otherlv_5= ',' ( (lv_hour_6_0= RULE_INT ) ) otherlv_7= ':' ( (lv_min_8_0= RULE_INT ) )
            {
            // InternalSparrow.g:1916:3: ( (lv_year_0_0= RULE_INT ) )
            // InternalSparrow.g:1917:4: (lv_year_0_0= RULE_INT )
            {
            // InternalSparrow.g:1917:4: (lv_year_0_0= RULE_INT )
            // InternalSparrow.g:1918:5: lv_year_0_0= RULE_INT
            {
            lv_year_0_0=(Token)match(input,RULE_INT,FOLLOW_30); 

            					newLeafNode(lv_year_0_0, grammarAccess.getDATEAccess().getYearINTTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDATERule());
            					}
            					setWithLastConsumed(
            						current,
            						"year",
            						lv_year_0_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_1=(Token)match(input,65,FOLLOW_31); 

            			newLeafNode(otherlv_1, grammarAccess.getDATEAccess().getSolidusKeyword_1());
            		
            // InternalSparrow.g:1938:3: ( (lv_month_2_0= RULE_INT ) )
            // InternalSparrow.g:1939:4: (lv_month_2_0= RULE_INT )
            {
            // InternalSparrow.g:1939:4: (lv_month_2_0= RULE_INT )
            // InternalSparrow.g:1940:5: lv_month_2_0= RULE_INT
            {
            lv_month_2_0=(Token)match(input,RULE_INT,FOLLOW_30); 

            					newLeafNode(lv_month_2_0, grammarAccess.getDATEAccess().getMonthINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDATERule());
            					}
            					setWithLastConsumed(
            						current,
            						"month",
            						lv_month_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,65,FOLLOW_31); 

            			newLeafNode(otherlv_3, grammarAccess.getDATEAccess().getSolidusKeyword_3());
            		
            // InternalSparrow.g:1960:3: ( (lv_day_4_0= RULE_INT ) )
            // InternalSparrow.g:1961:4: (lv_day_4_0= RULE_INT )
            {
            // InternalSparrow.g:1961:4: (lv_day_4_0= RULE_INT )
            // InternalSparrow.g:1962:5: lv_day_4_0= RULE_INT
            {
            lv_day_4_0=(Token)match(input,RULE_INT,FOLLOW_32); 

            					newLeafNode(lv_day_4_0, grammarAccess.getDATEAccess().getDayINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDATERule());
            					}
            					setWithLastConsumed(
            						current,
            						"day",
            						lv_day_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_5=(Token)match(input,22,FOLLOW_31); 

            			newLeafNode(otherlv_5, grammarAccess.getDATEAccess().getCommaKeyword_5());
            		
            // InternalSparrow.g:1982:3: ( (lv_hour_6_0= RULE_INT ) )
            // InternalSparrow.g:1983:4: (lv_hour_6_0= RULE_INT )
            {
            // InternalSparrow.g:1983:4: (lv_hour_6_0= RULE_INT )
            // InternalSparrow.g:1984:5: lv_hour_6_0= RULE_INT
            {
            lv_hour_6_0=(Token)match(input,RULE_INT,FOLLOW_16); 

            					newLeafNode(lv_hour_6_0, grammarAccess.getDATEAccess().getHourINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDATERule());
            					}
            					setWithLastConsumed(
            						current,
            						"hour",
            						lv_hour_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_7=(Token)match(input,21,FOLLOW_31); 

            			newLeafNode(otherlv_7, grammarAccess.getDATEAccess().getColonKeyword_7());
            		
            // InternalSparrow.g:2004:3: ( (lv_min_8_0= RULE_INT ) )
            // InternalSparrow.g:2005:4: (lv_min_8_0= RULE_INT )
            {
            // InternalSparrow.g:2005:4: (lv_min_8_0= RULE_INT )
            // InternalSparrow.g:2006:5: lv_min_8_0= RULE_INT
            {
            lv_min_8_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_min_8_0, grammarAccess.getDATEAccess().getMinINTTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDATERule());
            					}
            					setWithLastConsumed(
            						current,
            						"min",
            						lv_min_8_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDATE"


    // $ANTLR start "entryRuleObject"
    // InternalSparrow.g:2026:1: entryRuleObject returns [EObject current=null] : iv_ruleObject= ruleObject EOF ;
    public final EObject entryRuleObject() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObject = null;


        try {
            // InternalSparrow.g:2026:47: (iv_ruleObject= ruleObject EOF )
            // InternalSparrow.g:2027:2: iv_ruleObject= ruleObject EOF
            {
             newCompositeNode(grammarAccess.getObjectRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObject=ruleObject();

            state._fsp--;

             current =iv_ruleObject; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObject"


    // $ANTLR start "ruleObject"
    // InternalSparrow.g:2033:1: ruleObject returns [EObject current=null] : (otherlv_0= 'Token' ( (lv_name_1_0= RULE_ID ) ) ( (lv_objectExpression_2_0= ruleObjectExpression ) ) ) ;
    public final EObject ruleObject() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_objectExpression_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2039:2: ( (otherlv_0= 'Token' ( (lv_name_1_0= RULE_ID ) ) ( (lv_objectExpression_2_0= ruleObjectExpression ) ) ) )
            // InternalSparrow.g:2040:2: (otherlv_0= 'Token' ( (lv_name_1_0= RULE_ID ) ) ( (lv_objectExpression_2_0= ruleObjectExpression ) ) )
            {
            // InternalSparrow.g:2040:2: (otherlv_0= 'Token' ( (lv_name_1_0= RULE_ID ) ) ( (lv_objectExpression_2_0= ruleObjectExpression ) ) )
            // InternalSparrow.g:2041:3: otherlv_0= 'Token' ( (lv_name_1_0= RULE_ID ) ) ( (lv_objectExpression_2_0= ruleObjectExpression ) )
            {
            otherlv_0=(Token)match(input,66,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getObjectAccess().getTokenKeyword_0());
            		
            // InternalSparrow.g:2045:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSparrow.g:2046:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSparrow.g:2046:4: (lv_name_1_0= RULE_ID )
            // InternalSparrow.g:2047:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            					newLeafNode(lv_name_1_0, grammarAccess.getObjectAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getObjectRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSparrow.g:2063:3: ( (lv_objectExpression_2_0= ruleObjectExpression ) )
            // InternalSparrow.g:2064:4: (lv_objectExpression_2_0= ruleObjectExpression )
            {
            // InternalSparrow.g:2064:4: (lv_objectExpression_2_0= ruleObjectExpression )
            // InternalSparrow.g:2065:5: lv_objectExpression_2_0= ruleObjectExpression
            {

            					newCompositeNode(grammarAccess.getObjectAccess().getObjectExpressionObjectExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_objectExpression_2_0=ruleObjectExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getObjectRule());
            					}
            					set(
            						current,
            						"objectExpression",
            						lv_objectExpression_2_0,
            						"org.xtext.example.mydsl.Sparrow.ObjectExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObject"


    // $ANTLR start "entryRuleObjectExpression"
    // InternalSparrow.g:2086:1: entryRuleObjectExpression returns [EObject current=null] : iv_ruleObjectExpression= ruleObjectExpression EOF ;
    public final EObject entryRuleObjectExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObjectExpression = null;


        try {
            // InternalSparrow.g:2086:57: (iv_ruleObjectExpression= ruleObjectExpression EOF )
            // InternalSparrow.g:2087:2: iv_ruleObjectExpression= ruleObjectExpression EOF
            {
             newCompositeNode(grammarAccess.getObjectExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObjectExpression=ruleObjectExpression();

            state._fsp--;

             current =iv_ruleObjectExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObjectExpression"


    // $ANTLR start "ruleObjectExpression"
    // InternalSparrow.g:2093:1: ruleObjectExpression returns [EObject current=null] : (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' ) ;
    public final EObject ruleObjectExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_keyValue_1_0 = null;

        EObject lv_keyValue_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2099:2: ( (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' ) )
            // InternalSparrow.g:2100:2: (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' )
            {
            // InternalSparrow.g:2100:2: (otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}' )
            // InternalSparrow.g:2101:3: otherlv_0= '{' ( (lv_keyValue_1_0= rulekeyvalue ) ) (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_27); 

            			newLeafNode(otherlv_0, grammarAccess.getObjectExpressionAccess().getLeftCurlyBracketKeyword_0());
            		
            // InternalSparrow.g:2105:3: ( (lv_keyValue_1_0= rulekeyvalue ) )
            // InternalSparrow.g:2106:4: (lv_keyValue_1_0= rulekeyvalue )
            {
            // InternalSparrow.g:2106:4: (lv_keyValue_1_0= rulekeyvalue )
            // InternalSparrow.g:2107:5: lv_keyValue_1_0= rulekeyvalue
            {

            					newCompositeNode(grammarAccess.getObjectExpressionAccess().getKeyValueKeyvalueParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_25);
            lv_keyValue_1_0=rulekeyvalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getObjectExpressionRule());
            					}
            					add(
            						current,
            						"keyValue",
            						lv_keyValue_1_0,
            						"org.xtext.example.mydsl.Sparrow.keyvalue");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2124:3: (otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) ) )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==22) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalSparrow.g:2125:4: otherlv_2= ',' ( (lv_keyValue_3_0= rulekeyvalue ) )
            	    {
            	    otherlv_2=(Token)match(input,22,FOLLOW_27); 

            	    				newLeafNode(otherlv_2, grammarAccess.getObjectExpressionAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalSparrow.g:2129:4: ( (lv_keyValue_3_0= rulekeyvalue ) )
            	    // InternalSparrow.g:2130:5: (lv_keyValue_3_0= rulekeyvalue )
            	    {
            	    // InternalSparrow.g:2130:5: (lv_keyValue_3_0= rulekeyvalue )
            	    // InternalSparrow.g:2131:6: lv_keyValue_3_0= rulekeyvalue
            	    {

            	    						newCompositeNode(grammarAccess.getObjectExpressionAccess().getKeyValueKeyvalueParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    lv_keyValue_3_0=rulekeyvalue();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getObjectExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"keyValue",
            	    							lv_keyValue_3_0,
            	    							"org.xtext.example.mydsl.Sparrow.keyvalue");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

            otherlv_4=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getObjectExpressionAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectExpression"


    // $ANTLR start "entryRuleCondition"
    // InternalSparrow.g:2157:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalSparrow.g:2157:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalSparrow.g:2158:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalSparrow.g:2164:1: ruleCondition returns [EObject current=null] : (otherlv_0= 'Conditions' otherlv_1= '[' ( (lv_conditions_2_0= ruleConditionLink ) ) (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )* otherlv_5= ']' ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_conditions_2_0 = null;

        EObject lv_conditions_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2170:2: ( (otherlv_0= 'Conditions' otherlv_1= '[' ( (lv_conditions_2_0= ruleConditionLink ) ) (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )* otherlv_5= ']' ) )
            // InternalSparrow.g:2171:2: (otherlv_0= 'Conditions' otherlv_1= '[' ( (lv_conditions_2_0= ruleConditionLink ) ) (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )* otherlv_5= ']' )
            {
            // InternalSparrow.g:2171:2: (otherlv_0= 'Conditions' otherlv_1= '[' ( (lv_conditions_2_0= ruleConditionLink ) ) (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )* otherlv_5= ']' )
            // InternalSparrow.g:2172:3: otherlv_0= 'Conditions' otherlv_1= '[' ( (lv_conditions_2_0= ruleConditionLink ) ) (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )* otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,67,FOLLOW_33); 

            			newLeafNode(otherlv_0, grammarAccess.getConditionAccess().getConditionsKeyword_0());
            		
            otherlv_1=(Token)match(input,68,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalSparrow.g:2180:3: ( (lv_conditions_2_0= ruleConditionLink ) )
            // InternalSparrow.g:2181:4: (lv_conditions_2_0= ruleConditionLink )
            {
            // InternalSparrow.g:2181:4: (lv_conditions_2_0= ruleConditionLink )
            // InternalSparrow.g:2182:5: lv_conditions_2_0= ruleConditionLink
            {

            					newCompositeNode(grammarAccess.getConditionAccess().getConditionsConditionLinkParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_34);
            lv_conditions_2_0=ruleConditionLink();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConditionRule());
            					}
            					add(
            						current,
            						"conditions",
            						lv_conditions_2_0,
            						"org.xtext.example.mydsl.Sparrow.ConditionLink");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2199:3: (otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) ) )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==22) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalSparrow.g:2200:4: otherlv_3= ',' ( (lv_conditions_4_0= ruleConditionLink ) )
            	    {
            	    otherlv_3=(Token)match(input,22,FOLLOW_3); 

            	    				newLeafNode(otherlv_3, grammarAccess.getConditionAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalSparrow.g:2204:4: ( (lv_conditions_4_0= ruleConditionLink ) )
            	    // InternalSparrow.g:2205:5: (lv_conditions_4_0= ruleConditionLink )
            	    {
            	    // InternalSparrow.g:2205:5: (lv_conditions_4_0= ruleConditionLink )
            	    // InternalSparrow.g:2206:6: lv_conditions_4_0= ruleConditionLink
            	    {

            	    						newCompositeNode(grammarAccess.getConditionAccess().getConditionsConditionLinkParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_34);
            	    lv_conditions_4_0=ruleConditionLink();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getConditionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"conditions",
            	    							lv_conditions_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.ConditionLink");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

            otherlv_5=(Token)match(input,69,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getConditionAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleConditionLink"
    // InternalSparrow.g:2232:1: entryRuleConditionLink returns [EObject current=null] : iv_ruleConditionLink= ruleConditionLink EOF ;
    public final EObject entryRuleConditionLink() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditionLink = null;


        try {
            // InternalSparrow.g:2232:54: (iv_ruleConditionLink= ruleConditionLink EOF )
            // InternalSparrow.g:2233:2: iv_ruleConditionLink= ruleConditionLink EOF
            {
             newCompositeNode(grammarAccess.getConditionLinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConditionLink=ruleConditionLink();

            state._fsp--;

             current =iv_ruleConditionLink; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditionLink"


    // $ANTLR start "ruleConditionLink"
    // InternalSparrow.g:2239:1: ruleConditionLink returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )? ( (lv_andOrLink_4_0= ruleAndOrCondition ) )* ) ;
    public final EObject ruleConditionLink() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        EObject lv_conditionExpression_2_0 = null;

        EObject lv_linkCondition_3_0 = null;

        EObject lv_andOrLink_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2245:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )? ( (lv_andOrLink_4_0= ruleAndOrCondition ) )* ) )
            // InternalSparrow.g:2246:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )? ( (lv_andOrLink_4_0= ruleAndOrCondition ) )* )
            {
            // InternalSparrow.g:2246:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )? ( (lv_andOrLink_4_0= ruleAndOrCondition ) )* )
            // InternalSparrow.g:2247:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )? ( (lv_andOrLink_4_0= ruleAndOrCondition ) )*
            {
            // InternalSparrow.g:2247:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalSparrow.g:2248:4: (lv_name_0_0= RULE_ID )
            {
            // InternalSparrow.g:2248:4: (lv_name_0_0= RULE_ID )
            // InternalSparrow.g:2249:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_name_0_0, grammarAccess.getConditionLinkAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConditionLinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_35); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionLinkAccess().getColonKeyword_1());
            		
            // InternalSparrow.g:2269:3: ( ( (lv_conditionExpression_2_0= ruleSingleCondition ) ) | ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) ) )?
            int alt32=3;
            switch ( input.LA(1) ) {
                case 78:
                    {
                    int LA32_1 = input.LA(2);

                    if ( (LA32_1==86||(LA32_1>=88 && LA32_1<=90)||(LA32_1>=93 && LA32_1<=97)) ) {
                        alt32=1;
                    }
                    else if ( (LA32_1==RULE_ID) ) {
                        alt32=2;
                    }
                    }
                    break;
                case 86:
                case 88:
                case 89:
                case 90:
                case 93:
                case 94:
                case 95:
                case 96:
                case 97:
                    {
                    alt32=1;
                    }
                    break;
                case RULE_ID:
                    {
                    alt32=2;
                    }
                    break;
            }

            switch (alt32) {
                case 1 :
                    // InternalSparrow.g:2270:4: ( (lv_conditionExpression_2_0= ruleSingleCondition ) )
                    {
                    // InternalSparrow.g:2270:4: ( (lv_conditionExpression_2_0= ruleSingleCondition ) )
                    // InternalSparrow.g:2271:5: (lv_conditionExpression_2_0= ruleSingleCondition )
                    {
                    // InternalSparrow.g:2271:5: (lv_conditionExpression_2_0= ruleSingleCondition )
                    // InternalSparrow.g:2272:6: lv_conditionExpression_2_0= ruleSingleCondition
                    {

                    						newCompositeNode(grammarAccess.getConditionLinkAccess().getConditionExpressionSingleConditionParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_36);
                    lv_conditionExpression_2_0=ruleSingleCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionLinkRule());
                    						}
                    						set(
                    							current,
                    							"conditionExpression",
                    							lv_conditionExpression_2_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:2290:4: ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) )
                    {
                    // InternalSparrow.g:2290:4: ( (lv_linkCondition_3_0= ruleSingleLinkCondition ) )
                    // InternalSparrow.g:2291:5: (lv_linkCondition_3_0= ruleSingleLinkCondition )
                    {
                    // InternalSparrow.g:2291:5: (lv_linkCondition_3_0= ruleSingleLinkCondition )
                    // InternalSparrow.g:2292:6: lv_linkCondition_3_0= ruleSingleLinkCondition
                    {

                    						newCompositeNode(grammarAccess.getConditionLinkAccess().getLinkConditionSingleLinkConditionParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_36);
                    lv_linkCondition_3_0=ruleSingleLinkCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionLinkRule());
                    						}
                    						set(
                    							current,
                    							"linkCondition",
                    							lv_linkCondition_3_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleLinkCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:2310:3: ( (lv_andOrLink_4_0= ruleAndOrCondition ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( ((LA33_0>=70 && LA33_0<=71)) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalSparrow.g:2311:4: (lv_andOrLink_4_0= ruleAndOrCondition )
            	    {
            	    // InternalSparrow.g:2311:4: (lv_andOrLink_4_0= ruleAndOrCondition )
            	    // InternalSparrow.g:2312:5: lv_andOrLink_4_0= ruleAndOrCondition
            	    {

            	    					newCompositeNode(grammarAccess.getConditionLinkAccess().getAndOrLinkAndOrConditionParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_36);
            	    lv_andOrLink_4_0=ruleAndOrCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConditionLinkRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andOrLink",
            	    						lv_andOrLink_4_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditionLink"


    // $ANTLR start "entryRuleAndOrCondition"
    // InternalSparrow.g:2333:1: entryRuleAndOrCondition returns [EObject current=null] : iv_ruleAndOrCondition= ruleAndOrCondition EOF ;
    public final EObject entryRuleAndOrCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAndOrCondition = null;


        try {
            // InternalSparrow.g:2333:55: (iv_ruleAndOrCondition= ruleAndOrCondition EOF )
            // InternalSparrow.g:2334:2: iv_ruleAndOrCondition= ruleAndOrCondition EOF
            {
             newCompositeNode(grammarAccess.getAndOrConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAndOrCondition=ruleAndOrCondition();

            state._fsp--;

             current =iv_ruleAndOrCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAndOrCondition"


    // $ANTLR start "ruleAndOrCondition"
    // InternalSparrow.g:2340:1: ruleAndOrCondition returns [EObject current=null] : ( ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) ) ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ) ;
    public final EObject ruleAndOrCondition() throws RecognitionException {
        EObject current = null;

        Token lv_link_0_1=null;
        Token lv_link_0_2=null;
        EObject lv_condition_1_0 = null;

        EObject lv_linkCondition_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2346:2: ( ( ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) ) ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ) )
            // InternalSparrow.g:2347:2: ( ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) ) ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) )
            {
            // InternalSparrow.g:2347:2: ( ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) ) ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) )
            // InternalSparrow.g:2348:3: ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) ) ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) )
            {
            // InternalSparrow.g:2348:3: ( ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) ) )
            // InternalSparrow.g:2349:4: ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) )
            {
            // InternalSparrow.g:2349:4: ( (lv_link_0_1= 'and' | lv_link_0_2= 'or' ) )
            // InternalSparrow.g:2350:5: (lv_link_0_1= 'and' | lv_link_0_2= 'or' )
            {
            // InternalSparrow.g:2350:5: (lv_link_0_1= 'and' | lv_link_0_2= 'or' )
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==70) ) {
                alt34=1;
            }
            else if ( (LA34_0==71) ) {
                alt34=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }
            switch (alt34) {
                case 1 :
                    // InternalSparrow.g:2351:6: lv_link_0_1= 'and'
                    {
                    lv_link_0_1=(Token)match(input,70,FOLLOW_37); 

                    						newLeafNode(lv_link_0_1, grammarAccess.getAndOrConditionAccess().getLinkAndKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getAndOrConditionRule());
                    						}
                    						setWithLastConsumed(current, "link", lv_link_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:2362:6: lv_link_0_2= 'or'
                    {
                    lv_link_0_2=(Token)match(input,71,FOLLOW_37); 

                    						newLeafNode(lv_link_0_2, grammarAccess.getAndOrConditionAccess().getLinkOrKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getAndOrConditionRule());
                    						}
                    						setWithLastConsumed(current, "link", lv_link_0_2, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSparrow.g:2375:3: ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) )
            int alt35=2;
            switch ( input.LA(1) ) {
            case 78:
                {
                int LA35_1 = input.LA(2);

                if ( (LA35_1==RULE_ID) ) {
                    alt35=2;
                }
                else if ( (LA35_1==86||(LA35_1>=88 && LA35_1<=90)||(LA35_1>=93 && LA35_1<=97)) ) {
                    alt35=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 35, 1, input);

                    throw nvae;
                }
                }
                break;
            case 86:
            case 88:
            case 89:
            case 90:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
                {
                alt35=1;
                }
                break;
            case RULE_ID:
                {
                alt35=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }

            switch (alt35) {
                case 1 :
                    // InternalSparrow.g:2376:4: ( (lv_condition_1_0= ruleSingleCondition ) )
                    {
                    // InternalSparrow.g:2376:4: ( (lv_condition_1_0= ruleSingleCondition ) )
                    // InternalSparrow.g:2377:5: (lv_condition_1_0= ruleSingleCondition )
                    {
                    // InternalSparrow.g:2377:5: (lv_condition_1_0= ruleSingleCondition )
                    // InternalSparrow.g:2378:6: lv_condition_1_0= ruleSingleCondition
                    {

                    						newCompositeNode(grammarAccess.getAndOrConditionAccess().getConditionSingleConditionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_condition_1_0=ruleSingleCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAndOrConditionRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_1_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:2396:4: ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) )
                    {
                    // InternalSparrow.g:2396:4: ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) )
                    // InternalSparrow.g:2397:5: (lv_linkCondition_2_0= ruleSingleLinkCondition )
                    {
                    // InternalSparrow.g:2397:5: (lv_linkCondition_2_0= ruleSingleLinkCondition )
                    // InternalSparrow.g:2398:6: lv_linkCondition_2_0= ruleSingleLinkCondition
                    {

                    						newCompositeNode(grammarAccess.getAndOrConditionAccess().getLinkConditionSingleLinkConditionParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_linkCondition_2_0=ruleSingleLinkCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAndOrConditionRule());
                    						}
                    						set(
                    							current,
                    							"linkCondition",
                    							lv_linkCondition_2_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleLinkCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAndOrCondition"


    // $ANTLR start "entryRuleOperation"
    // InternalSparrow.g:2420:1: entryRuleOperation returns [EObject current=null] : iv_ruleOperation= ruleOperation EOF ;
    public final EObject entryRuleOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperation = null;


        try {
            // InternalSparrow.g:2420:50: (iv_ruleOperation= ruleOperation EOF )
            // InternalSparrow.g:2421:2: iv_ruleOperation= ruleOperation EOF
            {
             newCompositeNode(grammarAccess.getOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOperation=ruleOperation();

            state._fsp--;

             current =iv_ruleOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperation"


    // $ANTLR start "ruleOperation"
    // InternalSparrow.g:2427:1: ruleOperation returns [EObject current=null] : (otherlv_0= 'Operations' otherlv_1= '[' ( (lv_operates_2_0= ruleOperateLink ) ) (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )* otherlv_5= ']' ) ;
    public final EObject ruleOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_operates_2_0 = null;

        EObject lv_operates_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2433:2: ( (otherlv_0= 'Operations' otherlv_1= '[' ( (lv_operates_2_0= ruleOperateLink ) ) (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )* otherlv_5= ']' ) )
            // InternalSparrow.g:2434:2: (otherlv_0= 'Operations' otherlv_1= '[' ( (lv_operates_2_0= ruleOperateLink ) ) (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )* otherlv_5= ']' )
            {
            // InternalSparrow.g:2434:2: (otherlv_0= 'Operations' otherlv_1= '[' ( (lv_operates_2_0= ruleOperateLink ) ) (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )* otherlv_5= ']' )
            // InternalSparrow.g:2435:3: otherlv_0= 'Operations' otherlv_1= '[' ( (lv_operates_2_0= ruleOperateLink ) ) (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )* otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,72,FOLLOW_33); 

            			newLeafNode(otherlv_0, grammarAccess.getOperationAccess().getOperationsKeyword_0());
            		
            otherlv_1=(Token)match(input,68,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getOperationAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalSparrow.g:2443:3: ( (lv_operates_2_0= ruleOperateLink ) )
            // InternalSparrow.g:2444:4: (lv_operates_2_0= ruleOperateLink )
            {
            // InternalSparrow.g:2444:4: (lv_operates_2_0= ruleOperateLink )
            // InternalSparrow.g:2445:5: lv_operates_2_0= ruleOperateLink
            {

            					newCompositeNode(grammarAccess.getOperationAccess().getOperatesOperateLinkParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_34);
            lv_operates_2_0=ruleOperateLink();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOperationRule());
            					}
            					add(
            						current,
            						"operates",
            						lv_operates_2_0,
            						"org.xtext.example.mydsl.Sparrow.OperateLink");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2462:3: (otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) ) )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==22) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalSparrow.g:2463:4: otherlv_3= ',' ( (lv_operates_4_0= ruleOperateLink ) )
            	    {
            	    otherlv_3=(Token)match(input,22,FOLLOW_3); 

            	    				newLeafNode(otherlv_3, grammarAccess.getOperationAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalSparrow.g:2467:4: ( (lv_operates_4_0= ruleOperateLink ) )
            	    // InternalSparrow.g:2468:5: (lv_operates_4_0= ruleOperateLink )
            	    {
            	    // InternalSparrow.g:2468:5: (lv_operates_4_0= ruleOperateLink )
            	    // InternalSparrow.g:2469:6: lv_operates_4_0= ruleOperateLink
            	    {

            	    						newCompositeNode(grammarAccess.getOperationAccess().getOperatesOperateLinkParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_34);
            	    lv_operates_4_0=ruleOperateLink();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getOperationRule());
            	    						}
            	    						add(
            	    							current,
            	    							"operates",
            	    							lv_operates_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.OperateLink");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

            otherlv_5=(Token)match(input,69,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getOperationAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperation"


    // $ANTLR start "entryRuleOperateLink"
    // InternalSparrow.g:2495:1: entryRuleOperateLink returns [EObject current=null] : iv_ruleOperateLink= ruleOperateLink EOF ;
    public final EObject entryRuleOperateLink() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperateLink = null;


        try {
            // InternalSparrow.g:2495:52: (iv_ruleOperateLink= ruleOperateLink EOF )
            // InternalSparrow.g:2496:2: iv_ruleOperateLink= ruleOperateLink EOF
            {
             newCompositeNode(grammarAccess.getOperateLinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOperateLink=ruleOperateLink();

            state._fsp--;

             current =iv_ruleOperateLink; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperateLink"


    // $ANTLR start "ruleOperateLink"
    // InternalSparrow.g:2502:1: ruleOperateLink returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) ) ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )* ) ;
    public final EObject ruleOperateLink() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_firstOperation_2_0 = null;

        EObject lv_andOrLink_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2508:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) ) ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )* ) )
            // InternalSparrow.g:2509:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) ) ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )* )
            {
            // InternalSparrow.g:2509:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) ) ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )* )
            // InternalSparrow.g:2510:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) ) ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )*
            {
            // InternalSparrow.g:2510:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalSparrow.g:2511:4: (lv_name_0_0= RULE_ID )
            {
            // InternalSparrow.g:2511:4: (lv_name_0_0= RULE_ID )
            // InternalSparrow.g:2512:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_name_0_0, grammarAccess.getOperateLinkAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOperateLinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_38); 

            			newLeafNode(otherlv_1, grammarAccess.getOperateLinkAccess().getColonKeyword_1());
            		
            // InternalSparrow.g:2532:3: ( ( (lv_firstOperation_2_0= ruletrueOperation ) ) | ( (otherlv_3= RULE_ID ) ) )
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( ((LA37_0>=105 && LA37_0<=107)||LA37_0==114) ) {
                alt37=1;
            }
            else if ( (LA37_0==RULE_ID) ) {
                alt37=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 37, 0, input);

                throw nvae;
            }
            switch (alt37) {
                case 1 :
                    // InternalSparrow.g:2533:4: ( (lv_firstOperation_2_0= ruletrueOperation ) )
                    {
                    // InternalSparrow.g:2533:4: ( (lv_firstOperation_2_0= ruletrueOperation ) )
                    // InternalSparrow.g:2534:5: (lv_firstOperation_2_0= ruletrueOperation )
                    {
                    // InternalSparrow.g:2534:5: (lv_firstOperation_2_0= ruletrueOperation )
                    // InternalSparrow.g:2535:6: lv_firstOperation_2_0= ruletrueOperation
                    {

                    						newCompositeNode(grammarAccess.getOperateLinkAccess().getFirstOperationTrueOperationParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_39);
                    lv_firstOperation_2_0=ruletrueOperation();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getOperateLinkRule());
                    						}
                    						set(
                    							current,
                    							"firstOperation",
                    							lv_firstOperation_2_0,
                    							"org.xtext.example.mydsl.Sparrow.trueOperation");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:2553:4: ( (otherlv_3= RULE_ID ) )
                    {
                    // InternalSparrow.g:2553:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSparrow.g:2554:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSparrow.g:2554:5: (otherlv_3= RULE_ID )
                    // InternalSparrow.g:2555:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getOperateLinkRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_39); 

                    						newLeafNode(otherlv_3, grammarAccess.getOperateLinkAccess().getLinkOperationOperateLinkCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:2567:3: ( (lv_andOrLink_4_0= ruleAndOrOperationLink ) )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==70) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // InternalSparrow.g:2568:4: (lv_andOrLink_4_0= ruleAndOrOperationLink )
            	    {
            	    // InternalSparrow.g:2568:4: (lv_andOrLink_4_0= ruleAndOrOperationLink )
            	    // InternalSparrow.g:2569:5: lv_andOrLink_4_0= ruleAndOrOperationLink
            	    {

            	    					newCompositeNode(grammarAccess.getOperateLinkAccess().getAndOrLinkAndOrOperationLinkParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_39);
            	    lv_andOrLink_4_0=ruleAndOrOperationLink();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getOperateLinkRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andOrLink",
            	    						lv_andOrLink_4_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrOperationLink");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperateLink"


    // $ANTLR start "entryRuleRuleStructure"
    // InternalSparrow.g:2590:1: entryRuleRuleStructure returns [EObject current=null] : iv_ruleRuleStructure= ruleRuleStructure EOF ;
    public final EObject entryRuleRuleStructure() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRuleStructure = null;


        try {
            // InternalSparrow.g:2590:54: (iv_ruleRuleStructure= ruleRuleStructure EOF )
            // InternalSparrow.g:2591:2: iv_ruleRuleStructure= ruleRuleStructure EOF
            {
             newCompositeNode(grammarAccess.getRuleStructureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRuleStructure=ruleRuleStructure();

            state._fsp--;

             current =iv_ruleRuleStructure; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRuleStructure"


    // $ANTLR start "ruleRuleStructure"
    // InternalSparrow.g:2597:1: ruleRuleStructure returns [EObject current=null] : (otherlv_0= 'Rules' otherlv_1= '{' ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+ otherlv_3= '}' ) ;
    public final EObject ruleRuleStructure() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_manyRuleExpression_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2603:2: ( (otherlv_0= 'Rules' otherlv_1= '{' ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+ otherlv_3= '}' ) )
            // InternalSparrow.g:2604:2: (otherlv_0= 'Rules' otherlv_1= '{' ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+ otherlv_3= '}' )
            {
            // InternalSparrow.g:2604:2: (otherlv_0= 'Rules' otherlv_1= '{' ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+ otherlv_3= '}' )
            // InternalSparrow.g:2605:3: otherlv_0= 'Rules' otherlv_1= '{' ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+ otherlv_3= '}'
            {
            otherlv_0=(Token)match(input,73,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getRuleStructureAccess().getRulesKeyword_0());
            		
            otherlv_1=(Token)match(input,18,FOLLOW_40); 

            			newLeafNode(otherlv_1, grammarAccess.getRuleStructureAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalSparrow.g:2613:3: ( (lv_manyRuleExpression_2_0= ruleManyRuleExpression ) )+
            int cnt39=0;
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==RULE_ID||(LA39_0>=74 && LA39_0<=76)||LA39_0==82) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // InternalSparrow.g:2614:4: (lv_manyRuleExpression_2_0= ruleManyRuleExpression )
            	    {
            	    // InternalSparrow.g:2614:4: (lv_manyRuleExpression_2_0= ruleManyRuleExpression )
            	    // InternalSparrow.g:2615:5: lv_manyRuleExpression_2_0= ruleManyRuleExpression
            	    {

            	    					newCompositeNode(grammarAccess.getRuleStructureAccess().getManyRuleExpressionManyRuleExpressionParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_41);
            	    lv_manyRuleExpression_2_0=ruleManyRuleExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRuleStructureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"manyRuleExpression",
            	    						lv_manyRuleExpression_2_0,
            	    						"org.xtext.example.mydsl.Sparrow.ManyRuleExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt39 >= 1 ) break loop39;
                        EarlyExitException eee =
                            new EarlyExitException(39, input);
                        throw eee;
                }
                cnt39++;
            } while (true);

            otherlv_3=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getRuleStructureAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRuleStructure"


    // $ANTLR start "entryRuleManyRuleExpression"
    // InternalSparrow.g:2640:1: entryRuleManyRuleExpression returns [EObject current=null] : iv_ruleManyRuleExpression= ruleManyRuleExpression EOF ;
    public final EObject entryRuleManyRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleManyRuleExpression = null;


        try {
            // InternalSparrow.g:2640:59: (iv_ruleManyRuleExpression= ruleManyRuleExpression EOF )
            // InternalSparrow.g:2641:2: iv_ruleManyRuleExpression= ruleManyRuleExpression EOF
            {
             newCompositeNode(grammarAccess.getManyRuleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleManyRuleExpression=ruleManyRuleExpression();

            state._fsp--;

             current =iv_ruleManyRuleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleManyRuleExpression"


    // $ANTLR start "ruleManyRuleExpression"
    // InternalSparrow.g:2647:1: ruleManyRuleExpression returns [EObject current=null] : (this_ExclusiveExpression_0= ruleExclusiveExpression | this_ParallelExpression_1= ruleParallelExpression | this_RegularRuleExpression_2= ruleRegularRuleExpression | this_AdditionExpression_3= ruleAdditionExpression ) ;
    public final EObject ruleManyRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ExclusiveExpression_0 = null;

        EObject this_ParallelExpression_1 = null;

        EObject this_RegularRuleExpression_2 = null;

        EObject this_AdditionExpression_3 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2653:2: ( (this_ExclusiveExpression_0= ruleExclusiveExpression | this_ParallelExpression_1= ruleParallelExpression | this_RegularRuleExpression_2= ruleRegularRuleExpression | this_AdditionExpression_3= ruleAdditionExpression ) )
            // InternalSparrow.g:2654:2: (this_ExclusiveExpression_0= ruleExclusiveExpression | this_ParallelExpression_1= ruleParallelExpression | this_RegularRuleExpression_2= ruleRegularRuleExpression | this_AdditionExpression_3= ruleAdditionExpression )
            {
            // InternalSparrow.g:2654:2: (this_ExclusiveExpression_0= ruleExclusiveExpression | this_ParallelExpression_1= ruleParallelExpression | this_RegularRuleExpression_2= ruleRegularRuleExpression | this_AdditionExpression_3= ruleAdditionExpression )
            int alt40=4;
            switch ( input.LA(1) ) {
            case 75:
                {
                alt40=1;
                }
                break;
            case 74:
                {
                alt40=2;
                }
                break;
            case RULE_ID:
            case 82:
                {
                alt40=3;
                }
                break;
            case 76:
                {
                alt40=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }

            switch (alt40) {
                case 1 :
                    // InternalSparrow.g:2655:3: this_ExclusiveExpression_0= ruleExclusiveExpression
                    {

                    			newCompositeNode(grammarAccess.getManyRuleExpressionAccess().getExclusiveExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ExclusiveExpression_0=ruleExclusiveExpression();

                    state._fsp--;


                    			current = this_ExclusiveExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:2664:3: this_ParallelExpression_1= ruleParallelExpression
                    {

                    			newCompositeNode(grammarAccess.getManyRuleExpressionAccess().getParallelExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ParallelExpression_1=ruleParallelExpression();

                    state._fsp--;


                    			current = this_ParallelExpression_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:2673:3: this_RegularRuleExpression_2= ruleRegularRuleExpression
                    {

                    			newCompositeNode(grammarAccess.getManyRuleExpressionAccess().getRegularRuleExpressionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_RegularRuleExpression_2=ruleRegularRuleExpression();

                    state._fsp--;


                    			current = this_RegularRuleExpression_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:2682:3: this_AdditionExpression_3= ruleAdditionExpression
                    {

                    			newCompositeNode(grammarAccess.getManyRuleExpressionAccess().getAdditionExpressionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_AdditionExpression_3=ruleAdditionExpression();

                    state._fsp--;


                    			current = this_AdditionExpression_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleManyRuleExpression"


    // $ANTLR start "entryRuleParallelExpression"
    // InternalSparrow.g:2694:1: entryRuleParallelExpression returns [EObject current=null] : iv_ruleParallelExpression= ruleParallelExpression EOF ;
    public final EObject entryRuleParallelExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParallelExpression = null;


        try {
            // InternalSparrow.g:2694:59: (iv_ruleParallelExpression= ruleParallelExpression EOF )
            // InternalSparrow.g:2695:2: iv_ruleParallelExpression= ruleParallelExpression EOF
            {
             newCompositeNode(grammarAccess.getParallelExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParallelExpression=ruleParallelExpression();

            state._fsp--;

             current =iv_ruleParallelExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParallelExpression"


    // $ANTLR start "ruleParallelExpression"
    // InternalSparrow.g:2701:1: ruleParallelExpression returns [EObject current=null] : (otherlv_0= 'Exclusive' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) ;
    public final EObject ruleParallelExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_ruleExpression_2_0 = null;

        EObject lv_ruleExpression_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2707:2: ( (otherlv_0= 'Exclusive' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) )
            // InternalSparrow.g:2708:2: (otherlv_0= 'Exclusive' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            {
            // InternalSparrow.g:2708:2: (otherlv_0= 'Exclusive' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            // InternalSparrow.g:2709:3: otherlv_0= 'Exclusive' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,74,FOLLOW_33); 

            			newLeafNode(otherlv_0, grammarAccess.getParallelExpressionAccess().getExclusiveKeyword_0());
            		
            otherlv_1=(Token)match(input,68,FOLLOW_42); 

            			newLeafNode(otherlv_1, grammarAccess.getParallelExpressionAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalSparrow.g:2717:3: ( (lv_ruleExpression_2_0= ruleRuleExpression ) )
            // InternalSparrow.g:2718:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            {
            // InternalSparrow.g:2718:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            // InternalSparrow.g:2719:5: lv_ruleExpression_2_0= ruleRuleExpression
            {

            					newCompositeNode(grammarAccess.getParallelExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_43);
            lv_ruleExpression_2_0=ruleRuleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParallelExpressionRule());
            					}
            					add(
            						current,
            						"ruleExpression",
            						lv_ruleExpression_2_0,
            						"org.xtext.example.mydsl.Sparrow.RuleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2736:3: (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==23) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalSparrow.g:2737:4: otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    {
            	    otherlv_3=(Token)match(input,23,FOLLOW_42); 

            	    				newLeafNode(otherlv_3, grammarAccess.getParallelExpressionAccess().getSemicolonKeyword_3_0());
            	    			
            	    // InternalSparrow.g:2741:4: ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    // InternalSparrow.g:2742:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    {
            	    // InternalSparrow.g:2742:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    // InternalSparrow.g:2743:6: lv_ruleExpression_4_0= ruleRuleExpression
            	    {

            	    						newCompositeNode(grammarAccess.getParallelExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_43);
            	    lv_ruleExpression_4_0=ruleRuleExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getParallelExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ruleExpression",
            	    							lv_ruleExpression_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.RuleExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);

            otherlv_5=(Token)match(input,69,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getParallelExpressionAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParallelExpression"


    // $ANTLR start "entryRuleExclusiveExpression"
    // InternalSparrow.g:2769:1: entryRuleExclusiveExpression returns [EObject current=null] : iv_ruleExclusiveExpression= ruleExclusiveExpression EOF ;
    public final EObject entryRuleExclusiveExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExclusiveExpression = null;


        try {
            // InternalSparrow.g:2769:60: (iv_ruleExclusiveExpression= ruleExclusiveExpression EOF )
            // InternalSparrow.g:2770:2: iv_ruleExclusiveExpression= ruleExclusiveExpression EOF
            {
             newCompositeNode(grammarAccess.getExclusiveExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExclusiveExpression=ruleExclusiveExpression();

            state._fsp--;

             current =iv_ruleExclusiveExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExclusiveExpression"


    // $ANTLR start "ruleExclusiveExpression"
    // InternalSparrow.g:2776:1: ruleExclusiveExpression returns [EObject current=null] : (otherlv_0= 'Parallel' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) ;
    public final EObject ruleExclusiveExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_ruleExpression_2_0 = null;

        EObject lv_ruleExpression_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2782:2: ( (otherlv_0= 'Parallel' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) )
            // InternalSparrow.g:2783:2: (otherlv_0= 'Parallel' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            {
            // InternalSparrow.g:2783:2: (otherlv_0= 'Parallel' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            // InternalSparrow.g:2784:3: otherlv_0= 'Parallel' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,75,FOLLOW_33); 

            			newLeafNode(otherlv_0, grammarAccess.getExclusiveExpressionAccess().getParallelKeyword_0());
            		
            otherlv_1=(Token)match(input,68,FOLLOW_42); 

            			newLeafNode(otherlv_1, grammarAccess.getExclusiveExpressionAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalSparrow.g:2792:3: ( (lv_ruleExpression_2_0= ruleRuleExpression ) )
            // InternalSparrow.g:2793:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            {
            // InternalSparrow.g:2793:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            // InternalSparrow.g:2794:5: lv_ruleExpression_2_0= ruleRuleExpression
            {

            					newCompositeNode(grammarAccess.getExclusiveExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_43);
            lv_ruleExpression_2_0=ruleRuleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExclusiveExpressionRule());
            					}
            					add(
            						current,
            						"ruleExpression",
            						lv_ruleExpression_2_0,
            						"org.xtext.example.mydsl.Sparrow.RuleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2811:3: (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )*
            loop42:
            do {
                int alt42=2;
                int LA42_0 = input.LA(1);

                if ( (LA42_0==23) ) {
                    alt42=1;
                }


                switch (alt42) {
            	case 1 :
            	    // InternalSparrow.g:2812:4: otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    {
            	    otherlv_3=(Token)match(input,23,FOLLOW_42); 

            	    				newLeafNode(otherlv_3, grammarAccess.getExclusiveExpressionAccess().getSemicolonKeyword_3_0());
            	    			
            	    // InternalSparrow.g:2816:4: ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    // InternalSparrow.g:2817:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    {
            	    // InternalSparrow.g:2817:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    // InternalSparrow.g:2818:6: lv_ruleExpression_4_0= ruleRuleExpression
            	    {

            	    						newCompositeNode(grammarAccess.getExclusiveExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_43);
            	    lv_ruleExpression_4_0=ruleRuleExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getExclusiveExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ruleExpression",
            	    							lv_ruleExpression_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.RuleExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop42;
                }
            } while (true);

            otherlv_5=(Token)match(input,69,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getExclusiveExpressionAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExclusiveExpression"


    // $ANTLR start "entryRuleRegularRuleExpression"
    // InternalSparrow.g:2844:1: entryRuleRegularRuleExpression returns [EObject current=null] : iv_ruleRegularRuleExpression= ruleRegularRuleExpression EOF ;
    public final EObject entryRuleRegularRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRegularRuleExpression = null;


        try {
            // InternalSparrow.g:2844:62: (iv_ruleRegularRuleExpression= ruleRegularRuleExpression EOF )
            // InternalSparrow.g:2845:2: iv_ruleRegularRuleExpression= ruleRegularRuleExpression EOF
            {
             newCompositeNode(grammarAccess.getRegularRuleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRegularRuleExpression=ruleRegularRuleExpression();

            state._fsp--;

             current =iv_ruleRegularRuleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRegularRuleExpression"


    // $ANTLR start "ruleRegularRuleExpression"
    // InternalSparrow.g:2851:1: ruleRegularRuleExpression returns [EObject current=null] : ( ( (lv_ruleExpression_0_0= ruleRuleExpression ) ) (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )* ) ;
    public final EObject ruleRegularRuleExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_ruleExpression_0_0 = null;

        EObject lv_ruleExpression_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2857:2: ( ( ( (lv_ruleExpression_0_0= ruleRuleExpression ) ) (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )* ) )
            // InternalSparrow.g:2858:2: ( ( (lv_ruleExpression_0_0= ruleRuleExpression ) ) (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )* )
            {
            // InternalSparrow.g:2858:2: ( ( (lv_ruleExpression_0_0= ruleRuleExpression ) ) (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )* )
            // InternalSparrow.g:2859:3: ( (lv_ruleExpression_0_0= ruleRuleExpression ) ) (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )*
            {
            // InternalSparrow.g:2859:3: ( (lv_ruleExpression_0_0= ruleRuleExpression ) )
            // InternalSparrow.g:2860:4: (lv_ruleExpression_0_0= ruleRuleExpression )
            {
            // InternalSparrow.g:2860:4: (lv_ruleExpression_0_0= ruleRuleExpression )
            // InternalSparrow.g:2861:5: lv_ruleExpression_0_0= ruleRuleExpression
            {

            					newCompositeNode(grammarAccess.getRegularRuleExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_44);
            lv_ruleExpression_0_0=ruleRuleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRegularRuleExpressionRule());
            					}
            					add(
            						current,
            						"ruleExpression",
            						lv_ruleExpression_0_0,
            						"org.xtext.example.mydsl.Sparrow.RuleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2878:3: (otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) )*
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==23) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalSparrow.g:2879:4: otherlv_1= ';' ( (lv_ruleExpression_2_0= ruleRuleExpression ) )
            	    {
            	    otherlv_1=(Token)match(input,23,FOLLOW_42); 

            	    				newLeafNode(otherlv_1, grammarAccess.getRegularRuleExpressionAccess().getSemicolonKeyword_1_0());
            	    			
            	    // InternalSparrow.g:2883:4: ( (lv_ruleExpression_2_0= ruleRuleExpression ) )
            	    // InternalSparrow.g:2884:5: (lv_ruleExpression_2_0= ruleRuleExpression )
            	    {
            	    // InternalSparrow.g:2884:5: (lv_ruleExpression_2_0= ruleRuleExpression )
            	    // InternalSparrow.g:2885:6: lv_ruleExpression_2_0= ruleRuleExpression
            	    {

            	    						newCompositeNode(grammarAccess.getRegularRuleExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_44);
            	    lv_ruleExpression_2_0=ruleRuleExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getRegularRuleExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ruleExpression",
            	    							lv_ruleExpression_2_0,
            	    							"org.xtext.example.mydsl.Sparrow.RuleExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRegularRuleExpression"


    // $ANTLR start "entryRuleAdditionExpression"
    // InternalSparrow.g:2907:1: entryRuleAdditionExpression returns [EObject current=null] : iv_ruleAdditionExpression= ruleAdditionExpression EOF ;
    public final EObject entryRuleAdditionExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionExpression = null;


        try {
            // InternalSparrow.g:2907:59: (iv_ruleAdditionExpression= ruleAdditionExpression EOF )
            // InternalSparrow.g:2908:2: iv_ruleAdditionExpression= ruleAdditionExpression EOF
            {
             newCompositeNode(grammarAccess.getAdditionExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAdditionExpression=ruleAdditionExpression();

            state._fsp--;

             current =iv_ruleAdditionExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionExpression"


    // $ANTLR start "ruleAdditionExpression"
    // InternalSparrow.g:2914:1: ruleAdditionExpression returns [EObject current=null] : (otherlv_0= 'Additional' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) ;
    public final EObject ruleAdditionExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_ruleExpression_2_0 = null;

        EObject lv_ruleExpression_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2920:2: ( (otherlv_0= 'Additional' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' ) )
            // InternalSparrow.g:2921:2: (otherlv_0= 'Additional' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            {
            // InternalSparrow.g:2921:2: (otherlv_0= 'Additional' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']' )
            // InternalSparrow.g:2922:3: otherlv_0= 'Additional' otherlv_1= '[' ( (lv_ruleExpression_2_0= ruleRuleExpression ) ) (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )* otherlv_5= ']'
            {
            otherlv_0=(Token)match(input,76,FOLLOW_33); 

            			newLeafNode(otherlv_0, grammarAccess.getAdditionExpressionAccess().getAdditionalKeyword_0());
            		
            otherlv_1=(Token)match(input,68,FOLLOW_42); 

            			newLeafNode(otherlv_1, grammarAccess.getAdditionExpressionAccess().getLeftSquareBracketKeyword_1());
            		
            // InternalSparrow.g:2930:3: ( (lv_ruleExpression_2_0= ruleRuleExpression ) )
            // InternalSparrow.g:2931:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            {
            // InternalSparrow.g:2931:4: (lv_ruleExpression_2_0= ruleRuleExpression )
            // InternalSparrow.g:2932:5: lv_ruleExpression_2_0= ruleRuleExpression
            {

            					newCompositeNode(grammarAccess.getAdditionExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_43);
            lv_ruleExpression_2_0=ruleRuleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAdditionExpressionRule());
            					}
            					add(
            						current,
            						"ruleExpression",
            						lv_ruleExpression_2_0,
            						"org.xtext.example.mydsl.Sparrow.RuleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:2949:3: (otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) ) )*
            loop44:
            do {
                int alt44=2;
                int LA44_0 = input.LA(1);

                if ( (LA44_0==23) ) {
                    alt44=1;
                }


                switch (alt44) {
            	case 1 :
            	    // InternalSparrow.g:2950:4: otherlv_3= ';' ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    {
            	    otherlv_3=(Token)match(input,23,FOLLOW_42); 

            	    				newLeafNode(otherlv_3, grammarAccess.getAdditionExpressionAccess().getSemicolonKeyword_3_0());
            	    			
            	    // InternalSparrow.g:2954:4: ( (lv_ruleExpression_4_0= ruleRuleExpression ) )
            	    // InternalSparrow.g:2955:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    {
            	    // InternalSparrow.g:2955:5: (lv_ruleExpression_4_0= ruleRuleExpression )
            	    // InternalSparrow.g:2956:6: lv_ruleExpression_4_0= ruleRuleExpression
            	    {

            	    						newCompositeNode(grammarAccess.getAdditionExpressionAccess().getRuleExpressionRuleExpressionParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_43);
            	    lv_ruleExpression_4_0=ruleRuleExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getAdditionExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ruleExpression",
            	    							lv_ruleExpression_4_0,
            	    							"org.xtext.example.mydsl.Sparrow.RuleExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop44;
                }
            } while (true);

            otherlv_5=(Token)match(input,69,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getAdditionExpressionAccess().getRightSquareBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionExpression"


    // $ANTLR start "entryRuleTotalCondition"
    // InternalSparrow.g:2982:1: entryRuleTotalCondition returns [EObject current=null] : iv_ruleTotalCondition= ruleTotalCondition EOF ;
    public final EObject entryRuleTotalCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTotalCondition = null;


        try {
            // InternalSparrow.g:2982:55: (iv_ruleTotalCondition= ruleTotalCondition EOF )
            // InternalSparrow.g:2983:2: iv_ruleTotalCondition= ruleTotalCondition EOF
            {
             newCompositeNode(grammarAccess.getTotalConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTotalCondition=ruleTotalCondition();

            state._fsp--;

             current =iv_ruleTotalCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTotalCondition"


    // $ANTLR start "ruleTotalCondition"
    // InternalSparrow.g:2989:1: ruleTotalCondition returns [EObject current=null] : (otherlv_0= 'If:' ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ( (lv_andorcondition_3_0= ruleAndOrCondition ) )* otherlv_4= ',' ) ;
    public final EObject ruleTotalCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_4=null;
        EObject lv_condition_1_0 = null;

        EObject lv_linkCondition_2_0 = null;

        EObject lv_andorcondition_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:2995:2: ( (otherlv_0= 'If:' ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ( (lv_andorcondition_3_0= ruleAndOrCondition ) )* otherlv_4= ',' ) )
            // InternalSparrow.g:2996:2: (otherlv_0= 'If:' ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ( (lv_andorcondition_3_0= ruleAndOrCondition ) )* otherlv_4= ',' )
            {
            // InternalSparrow.g:2996:2: (otherlv_0= 'If:' ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ( (lv_andorcondition_3_0= ruleAndOrCondition ) )* otherlv_4= ',' )
            // InternalSparrow.g:2997:3: otherlv_0= 'If:' ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) ) ( (lv_andorcondition_3_0= ruleAndOrCondition ) )* otherlv_4= ','
            {
            otherlv_0=(Token)match(input,77,FOLLOW_37); 

            			newLeafNode(otherlv_0, grammarAccess.getTotalConditionAccess().getIfKeyword_0());
            		
            // InternalSparrow.g:3001:3: ( ( (lv_condition_1_0= ruleSingleCondition ) ) | ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) ) )
            int alt45=2;
            switch ( input.LA(1) ) {
            case 78:
                {
                int LA45_1 = input.LA(2);

                if ( (LA45_1==RULE_ID) ) {
                    alt45=2;
                }
                else if ( (LA45_1==86||(LA45_1>=88 && LA45_1<=90)||(LA45_1>=93 && LA45_1<=97)) ) {
                    alt45=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 45, 1, input);

                    throw nvae;
                }
                }
                break;
            case 86:
            case 88:
            case 89:
            case 90:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
                {
                alt45=1;
                }
                break;
            case RULE_ID:
                {
                alt45=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 45, 0, input);

                throw nvae;
            }

            switch (alt45) {
                case 1 :
                    // InternalSparrow.g:3002:4: ( (lv_condition_1_0= ruleSingleCondition ) )
                    {
                    // InternalSparrow.g:3002:4: ( (lv_condition_1_0= ruleSingleCondition ) )
                    // InternalSparrow.g:3003:5: (lv_condition_1_0= ruleSingleCondition )
                    {
                    // InternalSparrow.g:3003:5: (lv_condition_1_0= ruleSingleCondition )
                    // InternalSparrow.g:3004:6: lv_condition_1_0= ruleSingleCondition
                    {

                    						newCompositeNode(grammarAccess.getTotalConditionAccess().getConditionSingleConditionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_45);
                    lv_condition_1_0=ruleSingleCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTotalConditionRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_1_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:3022:4: ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) )
                    {
                    // InternalSparrow.g:3022:4: ( (lv_linkCondition_2_0= ruleSingleLinkCondition ) )
                    // InternalSparrow.g:3023:5: (lv_linkCondition_2_0= ruleSingleLinkCondition )
                    {
                    // InternalSparrow.g:3023:5: (lv_linkCondition_2_0= ruleSingleLinkCondition )
                    // InternalSparrow.g:3024:6: lv_linkCondition_2_0= ruleSingleLinkCondition
                    {

                    						newCompositeNode(grammarAccess.getTotalConditionAccess().getLinkConditionSingleLinkConditionParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_45);
                    lv_linkCondition_2_0=ruleSingleLinkCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTotalConditionRule());
                    						}
                    						set(
                    							current,
                    							"linkCondition",
                    							lv_linkCondition_2_0,
                    							"org.xtext.example.mydsl.Sparrow.SingleLinkCondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:3042:3: ( (lv_andorcondition_3_0= ruleAndOrCondition ) )*
            loop46:
            do {
                int alt46=2;
                int LA46_0 = input.LA(1);

                if ( ((LA46_0>=70 && LA46_0<=71)) ) {
                    alt46=1;
                }


                switch (alt46) {
            	case 1 :
            	    // InternalSparrow.g:3043:4: (lv_andorcondition_3_0= ruleAndOrCondition )
            	    {
            	    // InternalSparrow.g:3043:4: (lv_andorcondition_3_0= ruleAndOrCondition )
            	    // InternalSparrow.g:3044:5: lv_andorcondition_3_0= ruleAndOrCondition
            	    {

            	    					newCompositeNode(grammarAccess.getTotalConditionAccess().getAndorconditionAndOrConditionParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_45);
            	    lv_andorcondition_3_0=ruleAndOrCondition();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTotalConditionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andorcondition",
            	    						lv_andorcondition_3_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrCondition");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop46;
                }
            } while (true);

            otherlv_4=(Token)match(input,22,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getTotalConditionAccess().getCommaKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTotalCondition"


    // $ANTLR start "entryRuleSingleLinkCondition"
    // InternalSparrow.g:3069:1: entryRuleSingleLinkCondition returns [EObject current=null] : iv_ruleSingleLinkCondition= ruleSingleLinkCondition EOF ;
    public final EObject entryRuleSingleLinkCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingleLinkCondition = null;


        try {
            // InternalSparrow.g:3069:60: (iv_ruleSingleLinkCondition= ruleSingleLinkCondition EOF )
            // InternalSparrow.g:3070:2: iv_ruleSingleLinkCondition= ruleSingleLinkCondition EOF
            {
             newCompositeNode(grammarAccess.getSingleLinkConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingleLinkCondition=ruleSingleLinkCondition();

            state._fsp--;

             current =iv_ruleSingleLinkCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingleLinkCondition"


    // $ANTLR start "ruleSingleLinkCondition"
    // InternalSparrow.g:3076:1: ruleSingleLinkCondition returns [EObject current=null] : ( ( (lv_no_0_0= '!' ) )? ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject ruleSingleLinkCondition() throws RecognitionException {
        EObject current = null;

        Token lv_no_0_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalSparrow.g:3082:2: ( ( ( (lv_no_0_0= '!' ) )? ( (otherlv_1= RULE_ID ) ) ) )
            // InternalSparrow.g:3083:2: ( ( (lv_no_0_0= '!' ) )? ( (otherlv_1= RULE_ID ) ) )
            {
            // InternalSparrow.g:3083:2: ( ( (lv_no_0_0= '!' ) )? ( (otherlv_1= RULE_ID ) ) )
            // InternalSparrow.g:3084:3: ( (lv_no_0_0= '!' ) )? ( (otherlv_1= RULE_ID ) )
            {
            // InternalSparrow.g:3084:3: ( (lv_no_0_0= '!' ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==78) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSparrow.g:3085:4: (lv_no_0_0= '!' )
                    {
                    // InternalSparrow.g:3085:4: (lv_no_0_0= '!' )
                    // InternalSparrow.g:3086:5: lv_no_0_0= '!'
                    {
                    lv_no_0_0=(Token)match(input,78,FOLLOW_3); 

                    					newLeafNode(lv_no_0_0, grammarAccess.getSingleLinkConditionAccess().getNoExclamationMarkKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingleLinkConditionRule());
                    					}
                    					setWithLastConsumed(current, "no", lv_no_0_0, "!");
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3098:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:3099:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:3099:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:3100:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSingleLinkConditionRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_1, grammarAccess.getSingleLinkConditionAccess().getLinkConditionConditionLinkCrossReference_1_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingleLinkCondition"


    // $ANTLR start "entryRuleTotalOperation"
    // InternalSparrow.g:3115:1: entryRuleTotalOperation returns [EObject current=null] : iv_ruleTotalOperation= ruleTotalOperation EOF ;
    public final EObject entryRuleTotalOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTotalOperation = null;


        try {
            // InternalSparrow.g:3115:55: (iv_ruleTotalOperation= ruleTotalOperation EOF )
            // InternalSparrow.g:3116:2: iv_ruleTotalOperation= ruleTotalOperation EOF
            {
             newCompositeNode(grammarAccess.getTotalOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTotalOperation=ruleTotalOperation();

            state._fsp--;

             current =iv_ruleTotalOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTotalOperation"


    // $ANTLR start "ruleTotalOperation"
    // InternalSparrow.g:3122:1: ruleTotalOperation returns [EObject current=null] : ( () ( (otherlv_1= RULE_ID ) )? (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )? ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )? ( (lv_andor_6_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_7_0= ruleTimepoint ) )? ( (lv_failresult_8_0= ruleFailResult ) )? ( (lv_thenoperation_9_0= ruleThenOperation ) )* ) ;
    public final EObject ruleTotalOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_firstOperation_4_0 = null;

        EObject lv_andor_6_0 = null;

        EObject lv_timePoint_7_0 = null;

        EObject lv_failresult_8_0 = null;

        EObject lv_thenoperation_9_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3128:2: ( ( () ( (otherlv_1= RULE_ID ) )? (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )? ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )? ( (lv_andor_6_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_7_0= ruleTimepoint ) )? ( (lv_failresult_8_0= ruleFailResult ) )? ( (lv_thenoperation_9_0= ruleThenOperation ) )* ) )
            // InternalSparrow.g:3129:2: ( () ( (otherlv_1= RULE_ID ) )? (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )? ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )? ( (lv_andor_6_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_7_0= ruleTimepoint ) )? ( (lv_failresult_8_0= ruleFailResult ) )? ( (lv_thenoperation_9_0= ruleThenOperation ) )* )
            {
            // InternalSparrow.g:3129:2: ( () ( (otherlv_1= RULE_ID ) )? (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )? ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )? ( (lv_andor_6_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_7_0= ruleTimepoint ) )? ( (lv_failresult_8_0= ruleFailResult ) )? ( (lv_thenoperation_9_0= ruleThenOperation ) )* )
            // InternalSparrow.g:3130:3: () ( (otherlv_1= RULE_ID ) )? (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )? ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )? ( (lv_andor_6_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_7_0= ruleTimepoint ) )? ( (lv_failresult_8_0= ruleFailResult ) )? ( (lv_thenoperation_9_0= ruleThenOperation ) )*
            {
            // InternalSparrow.g:3130:3: ()
            // InternalSparrow.g:3131:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTotalOperationAccess().getTotalOperationAction_0(),
            					current);
            			

            }

            // InternalSparrow.g:3137:3: ( (otherlv_1= RULE_ID ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_ID) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSparrow.g:3138:4: (otherlv_1= RULE_ID )
                    {
                    // InternalSparrow.g:3138:4: (otherlv_1= RULE_ID )
                    // InternalSparrow.g:3139:5: otherlv_1= RULE_ID
                    {

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTotalOperationRule());
                    					}
                    				
                    otherlv_1=(Token)match(input,RULE_ID,FOLLOW_46); 

                    					newLeafNode(otherlv_1, grammarAccess.getTotalOperationAccess().getPersonInitExpressionsCrossReference_1_0());
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3150:3: (otherlv_2= 'G' ( (otherlv_3= RULE_ID ) ) )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==79) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSparrow.g:3151:4: otherlv_2= 'G' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,79,FOLLOW_3); 

                    				newLeafNode(otherlv_2, grammarAccess.getTotalOperationAccess().getGKeyword_2_0());
                    			
                    // InternalSparrow.g:3155:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSparrow.g:3156:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSparrow.g:3156:5: (otherlv_3= RULE_ID )
                    // InternalSparrow.g:3157:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTotalOperationRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_47); 

                    						newLeafNode(otherlv_3, grammarAccess.getTotalOperationAccess().getPerson2GroupCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:3169:3: ( ( (lv_firstOperation_4_0= ruletrueOperation ) ) | ( (otherlv_5= RULE_ID ) ) )?
            int alt50=3;
            int LA50_0 = input.LA(1);

            if ( ((LA50_0>=105 && LA50_0<=107)||LA50_0==114) ) {
                alt50=1;
            }
            else if ( (LA50_0==RULE_ID) ) {
                int LA50_2 = input.LA(2);

                if ( (LA50_2==EOF||LA50_2==RULE_ID||LA50_2==19||LA50_2==23||(LA50_2>=69 && LA50_2<=70)||(LA50_2>=74 && LA50_2<=76)||(LA50_2>=80 && LA50_2<=82)||(LA50_2>=84 && LA50_2<=86)||LA50_2==88) ) {
                    alt50=2;
                }
            }
            switch (alt50) {
                case 1 :
                    // InternalSparrow.g:3170:4: ( (lv_firstOperation_4_0= ruletrueOperation ) )
                    {
                    // InternalSparrow.g:3170:4: ( (lv_firstOperation_4_0= ruletrueOperation ) )
                    // InternalSparrow.g:3171:5: (lv_firstOperation_4_0= ruletrueOperation )
                    {
                    // InternalSparrow.g:3171:5: (lv_firstOperation_4_0= ruletrueOperation )
                    // InternalSparrow.g:3172:6: lv_firstOperation_4_0= ruletrueOperation
                    {

                    						newCompositeNode(grammarAccess.getTotalOperationAccess().getFirstOperationTrueOperationParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_48);
                    lv_firstOperation_4_0=ruletrueOperation();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTotalOperationRule());
                    						}
                    						set(
                    							current,
                    							"firstOperation",
                    							lv_firstOperation_4_0,
                    							"org.xtext.example.mydsl.Sparrow.trueOperation");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:3190:4: ( (otherlv_5= RULE_ID ) )
                    {
                    // InternalSparrow.g:3190:4: ( (otherlv_5= RULE_ID ) )
                    // InternalSparrow.g:3191:5: (otherlv_5= RULE_ID )
                    {
                    // InternalSparrow.g:3191:5: (otherlv_5= RULE_ID )
                    // InternalSparrow.g:3192:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTotalOperationRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_48); 

                    						newLeafNode(otherlv_5, grammarAccess.getTotalOperationAccess().getLinkOperationOperateLinkCrossReference_3_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:3204:3: ( (lv_andor_6_0= ruleAndOrOperationLink ) )*
            loop51:
            do {
                int alt51=2;
                int LA51_0 = input.LA(1);

                if ( (LA51_0==70) ) {
                    alt51=1;
                }


                switch (alt51) {
            	case 1 :
            	    // InternalSparrow.g:3205:4: (lv_andor_6_0= ruleAndOrOperationLink )
            	    {
            	    // InternalSparrow.g:3205:4: (lv_andor_6_0= ruleAndOrOperationLink )
            	    // InternalSparrow.g:3206:5: lv_andor_6_0= ruleAndOrOperationLink
            	    {

            	    					newCompositeNode(grammarAccess.getTotalOperationAccess().getAndorAndOrOperationLinkParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_48);
            	    lv_andor_6_0=ruleAndOrOperationLink();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTotalOperationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andor",
            	    						lv_andor_6_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrOperationLink");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop51;
                }
            } while (true);

            // InternalSparrow.g:3223:3: ( (lv_timePoint_7_0= ruleTimepoint ) )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==86||LA52_0==88) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSparrow.g:3224:4: (lv_timePoint_7_0= ruleTimepoint )
                    {
                    // InternalSparrow.g:3224:4: (lv_timePoint_7_0= ruleTimepoint )
                    // InternalSparrow.g:3225:5: lv_timePoint_7_0= ruleTimepoint
                    {

                    					newCompositeNode(grammarAccess.getTotalOperationAccess().getTimePointTimepointParserRuleCall_5_0());
                    				
                    pushFollow(FOLLOW_49);
                    lv_timePoint_7_0=ruleTimepoint();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTotalOperationRule());
                    					}
                    					set(
                    						current,
                    						"timePoint",
                    						lv_timePoint_7_0,
                    						"org.xtext.example.mydsl.Sparrow.Timepoint");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3242:3: ( (lv_failresult_8_0= ruleFailResult ) )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==85) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSparrow.g:3243:4: (lv_failresult_8_0= ruleFailResult )
                    {
                    // InternalSparrow.g:3243:4: (lv_failresult_8_0= ruleFailResult )
                    // InternalSparrow.g:3244:5: lv_failresult_8_0= ruleFailResult
                    {

                    					newCompositeNode(grammarAccess.getTotalOperationAccess().getFailresultFailResultParserRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_50);
                    lv_failresult_8_0=ruleFailResult();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTotalOperationRule());
                    					}
                    					set(
                    						current,
                    						"failresult",
                    						lv_failresult_8_0,
                    						"org.xtext.example.mydsl.Sparrow.FailResult");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3261:3: ( (lv_thenoperation_9_0= ruleThenOperation ) )*
            loop54:
            do {
                int alt54=2;
                int LA54_0 = input.LA(1);

                if ( (LA54_0==80) ) {
                    alt54=1;
                }


                switch (alt54) {
            	case 1 :
            	    // InternalSparrow.g:3262:4: (lv_thenoperation_9_0= ruleThenOperation )
            	    {
            	    // InternalSparrow.g:3262:4: (lv_thenoperation_9_0= ruleThenOperation )
            	    // InternalSparrow.g:3263:5: lv_thenoperation_9_0= ruleThenOperation
            	    {

            	    					newCompositeNode(grammarAccess.getTotalOperationAccess().getThenoperationThenOperationParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_50);
            	    lv_thenoperation_9_0=ruleThenOperation();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTotalOperationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"thenoperation",
            	    						lv_thenoperation_9_0,
            	    						"org.xtext.example.mydsl.Sparrow.ThenOperation");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop54;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTotalOperation"


    // $ANTLR start "entryRuleAndOrOperationLink"
    // InternalSparrow.g:3284:1: entryRuleAndOrOperationLink returns [EObject current=null] : iv_ruleAndOrOperationLink= ruleAndOrOperationLink EOF ;
    public final EObject entryRuleAndOrOperationLink() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAndOrOperationLink = null;


        try {
            // InternalSparrow.g:3284:59: (iv_ruleAndOrOperationLink= ruleAndOrOperationLink EOF )
            // InternalSparrow.g:3285:2: iv_ruleAndOrOperationLink= ruleAndOrOperationLink EOF
            {
             newCompositeNode(grammarAccess.getAndOrOperationLinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAndOrOperationLink=ruleAndOrOperationLink();

            state._fsp--;

             current =iv_ruleAndOrOperationLink; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAndOrOperationLink"


    // $ANTLR start "ruleAndOrOperationLink"
    // InternalSparrow.g:3291:1: ruleAndOrOperationLink returns [EObject current=null] : ( ( (lv_link_0_0= 'and' ) ) ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ) ;
    public final EObject ruleAndOrOperationLink() throws RecognitionException {
        EObject current = null;

        Token lv_link_0_0=null;
        Token otherlv_2=null;
        EObject lv_firstOperation_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3297:2: ( ( ( (lv_link_0_0= 'and' ) ) ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ) )
            // InternalSparrow.g:3298:2: ( ( (lv_link_0_0= 'and' ) ) ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) )
            {
            // InternalSparrow.g:3298:2: ( ( (lv_link_0_0= 'and' ) ) ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) )
            // InternalSparrow.g:3299:3: ( (lv_link_0_0= 'and' ) ) ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) )
            {
            // InternalSparrow.g:3299:3: ( (lv_link_0_0= 'and' ) )
            // InternalSparrow.g:3300:4: (lv_link_0_0= 'and' )
            {
            // InternalSparrow.g:3300:4: (lv_link_0_0= 'and' )
            // InternalSparrow.g:3301:5: lv_link_0_0= 'and'
            {
            lv_link_0_0=(Token)match(input,70,FOLLOW_38); 

            					newLeafNode(lv_link_0_0, grammarAccess.getAndOrOperationLinkAccess().getLinkAndKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAndOrOperationLinkRule());
            					}
            					setWithLastConsumed(current, "link", lv_link_0_0, "and");
            				

            }


            }

            // InternalSparrow.g:3313:3: ( ( (lv_firstOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( ((LA55_0>=105 && LA55_0<=107)||LA55_0==114) ) {
                alt55=1;
            }
            else if ( (LA55_0==RULE_ID) ) {
                alt55=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // InternalSparrow.g:3314:4: ( (lv_firstOperation_1_0= ruletrueOperation ) )
                    {
                    // InternalSparrow.g:3314:4: ( (lv_firstOperation_1_0= ruletrueOperation ) )
                    // InternalSparrow.g:3315:5: (lv_firstOperation_1_0= ruletrueOperation )
                    {
                    // InternalSparrow.g:3315:5: (lv_firstOperation_1_0= ruletrueOperation )
                    // InternalSparrow.g:3316:6: lv_firstOperation_1_0= ruletrueOperation
                    {

                    						newCompositeNode(grammarAccess.getAndOrOperationLinkAccess().getFirstOperationTrueOperationParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_firstOperation_1_0=ruletrueOperation();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAndOrOperationLinkRule());
                    						}
                    						set(
                    							current,
                    							"firstOperation",
                    							lv_firstOperation_1_0,
                    							"org.xtext.example.mydsl.Sparrow.trueOperation");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:3334:4: ( (otherlv_2= RULE_ID ) )
                    {
                    // InternalSparrow.g:3334:4: ( (otherlv_2= RULE_ID ) )
                    // InternalSparrow.g:3335:5: (otherlv_2= RULE_ID )
                    {
                    // InternalSparrow.g:3335:5: (otherlv_2= RULE_ID )
                    // InternalSparrow.g:3336:6: otherlv_2= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getAndOrOperationLinkRule());
                    						}
                    					
                    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(otherlv_2, grammarAccess.getAndOrOperationLinkAccess().getLinkOperationOperateLinkCrossReference_1_1_0());
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAndOrOperationLink"


    // $ANTLR start "entryRuleThenOperation"
    // InternalSparrow.g:3352:1: entryRuleThenOperation returns [EObject current=null] : iv_ruleThenOperation= ruleThenOperation EOF ;
    public final EObject entryRuleThenOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThenOperation = null;


        try {
            // InternalSparrow.g:3352:54: (iv_ruleThenOperation= ruleThenOperation EOF )
            // InternalSparrow.g:3353:2: iv_ruleThenOperation= ruleThenOperation EOF
            {
             newCompositeNode(grammarAccess.getThenOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThenOperation=ruleThenOperation();

            state._fsp--;

             current =iv_ruleThenOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThenOperation"


    // $ANTLR start "ruleThenOperation"
    // InternalSparrow.g:3359:1: ruleThenOperation returns [EObject current=null] : (otherlv_0= 'Then' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_failresult_5_0= ruleFailResult ) )? ) ;
    public final EObject ruleThenOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_followingOperation_1_0 = null;

        EObject lv_andor_3_0 = null;

        EObject lv_timePoint_4_0 = null;

        EObject lv_failresult_5_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3365:2: ( (otherlv_0= 'Then' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_failresult_5_0= ruleFailResult ) )? ) )
            // InternalSparrow.g:3366:2: (otherlv_0= 'Then' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_failresult_5_0= ruleFailResult ) )? )
            {
            // InternalSparrow.g:3366:2: (otherlv_0= 'Then' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_failresult_5_0= ruleFailResult ) )? )
            // InternalSparrow.g:3367:3: otherlv_0= 'Then' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_failresult_5_0= ruleFailResult ) )?
            {
            otherlv_0=(Token)match(input,80,FOLLOW_38); 

            			newLeafNode(otherlv_0, grammarAccess.getThenOperationAccess().getThenKeyword_0());
            		
            // InternalSparrow.g:3371:3: ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) )
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( ((LA56_0>=105 && LA56_0<=107)||LA56_0==114) ) {
                alt56=1;
            }
            else if ( (LA56_0==RULE_ID) ) {
                alt56=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 56, 0, input);

                throw nvae;
            }
            switch (alt56) {
                case 1 :
                    // InternalSparrow.g:3372:4: ( (lv_followingOperation_1_0= ruletrueOperation ) )
                    {
                    // InternalSparrow.g:3372:4: ( (lv_followingOperation_1_0= ruletrueOperation ) )
                    // InternalSparrow.g:3373:5: (lv_followingOperation_1_0= ruletrueOperation )
                    {
                    // InternalSparrow.g:3373:5: (lv_followingOperation_1_0= ruletrueOperation )
                    // InternalSparrow.g:3374:6: lv_followingOperation_1_0= ruletrueOperation
                    {

                    						newCompositeNode(grammarAccess.getThenOperationAccess().getFollowingOperationTrueOperationParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_51);
                    lv_followingOperation_1_0=ruletrueOperation();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getThenOperationRule());
                    						}
                    						set(
                    							current,
                    							"followingOperation",
                    							lv_followingOperation_1_0,
                    							"org.xtext.example.mydsl.Sparrow.trueOperation");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:3392:4: ( (otherlv_2= RULE_ID ) )
                    {
                    // InternalSparrow.g:3392:4: ( (otherlv_2= RULE_ID ) )
                    // InternalSparrow.g:3393:5: (otherlv_2= RULE_ID )
                    {
                    // InternalSparrow.g:3393:5: (otherlv_2= RULE_ID )
                    // InternalSparrow.g:3394:6: otherlv_2= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getThenOperationRule());
                    						}
                    					
                    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_51); 

                    						newLeafNode(otherlv_2, grammarAccess.getThenOperationAccess().getLinkOperationOperateLinkCrossReference_1_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:3406:3: ( (lv_andor_3_0= ruleAndOrOperationLink ) )*
            loop57:
            do {
                int alt57=2;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==70) ) {
                    alt57=1;
                }


                switch (alt57) {
            	case 1 :
            	    // InternalSparrow.g:3407:4: (lv_andor_3_0= ruleAndOrOperationLink )
            	    {
            	    // InternalSparrow.g:3407:4: (lv_andor_3_0= ruleAndOrOperationLink )
            	    // InternalSparrow.g:3408:5: lv_andor_3_0= ruleAndOrOperationLink
            	    {

            	    					newCompositeNode(grammarAccess.getThenOperationAccess().getAndorAndOrOperationLinkParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_51);
            	    lv_andor_3_0=ruleAndOrOperationLink();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getThenOperationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andor",
            	    						lv_andor_3_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrOperationLink");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop57;
                }
            } while (true);

            // InternalSparrow.g:3425:3: ( (lv_timePoint_4_0= ruleTimepoint ) )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==86||LA58_0==88) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSparrow.g:3426:4: (lv_timePoint_4_0= ruleTimepoint )
                    {
                    // InternalSparrow.g:3426:4: (lv_timePoint_4_0= ruleTimepoint )
                    // InternalSparrow.g:3427:5: lv_timePoint_4_0= ruleTimepoint
                    {

                    					newCompositeNode(grammarAccess.getThenOperationAccess().getTimePointTimepointParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_52);
                    lv_timePoint_4_0=ruleTimepoint();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getThenOperationRule());
                    					}
                    					set(
                    						current,
                    						"timePoint",
                    						lv_timePoint_4_0,
                    						"org.xtext.example.mydsl.Sparrow.Timepoint");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3444:3: ( (lv_failresult_5_0= ruleFailResult ) )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==85) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSparrow.g:3445:4: (lv_failresult_5_0= ruleFailResult )
                    {
                    // InternalSparrow.g:3445:4: (lv_failresult_5_0= ruleFailResult )
                    // InternalSparrow.g:3446:5: lv_failresult_5_0= ruleFailResult
                    {

                    					newCompositeNode(grammarAccess.getThenOperationAccess().getFailresultFailResultParserRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_failresult_5_0=ruleFailResult();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getThenOperationRule());
                    					}
                    					set(
                    						current,
                    						"failresult",
                    						lv_failresult_5_0,
                    						"org.xtext.example.mydsl.Sparrow.FailResult");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThenOperation"


    // $ANTLR start "entryRuleTotalExpression"
    // InternalSparrow.g:3467:1: entryRuleTotalExpression returns [EObject current=null] : iv_ruleTotalExpression= ruleTotalExpression EOF ;
    public final EObject entryRuleTotalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTotalExpression = null;


        try {
            // InternalSparrow.g:3467:56: (iv_ruleTotalExpression= ruleTotalExpression EOF )
            // InternalSparrow.g:3468:2: iv_ruleTotalExpression= ruleTotalExpression EOF
            {
             newCompositeNode(grammarAccess.getTotalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTotalExpression=ruleTotalExpression();

            state._fsp--;

             current =iv_ruleTotalExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTotalExpression"


    // $ANTLR start "ruleTotalExpression"
    // InternalSparrow.g:3474:1: ruleTotalExpression returns [EObject current=null] : ( ( (lv_set_0_0= rulemessageExpression ) )? ( (lv_totalCondition_1_0= ruleTotalCondition ) )? ( (lv_totalOperation_2_0= ruleTotalOperation ) ) ( (lv_elseExpression_3_0= ruleElseExpression ) )? ) ;
    public final EObject ruleTotalExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_set_0_0 = null;

        EObject lv_totalCondition_1_0 = null;

        EObject lv_totalOperation_2_0 = null;

        EObject lv_elseExpression_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3480:2: ( ( ( (lv_set_0_0= rulemessageExpression ) )? ( (lv_totalCondition_1_0= ruleTotalCondition ) )? ( (lv_totalOperation_2_0= ruleTotalOperation ) ) ( (lv_elseExpression_3_0= ruleElseExpression ) )? ) )
            // InternalSparrow.g:3481:2: ( ( (lv_set_0_0= rulemessageExpression ) )? ( (lv_totalCondition_1_0= ruleTotalCondition ) )? ( (lv_totalOperation_2_0= ruleTotalOperation ) ) ( (lv_elseExpression_3_0= ruleElseExpression ) )? )
            {
            // InternalSparrow.g:3481:2: ( ( (lv_set_0_0= rulemessageExpression ) )? ( (lv_totalCondition_1_0= ruleTotalCondition ) )? ( (lv_totalOperation_2_0= ruleTotalOperation ) ) ( (lv_elseExpression_3_0= ruleElseExpression ) )? )
            // InternalSparrow.g:3482:3: ( (lv_set_0_0= rulemessageExpression ) )? ( (lv_totalCondition_1_0= ruleTotalCondition ) )? ( (lv_totalOperation_2_0= ruleTotalOperation ) ) ( (lv_elseExpression_3_0= ruleElseExpression ) )?
            {
            // InternalSparrow.g:3482:3: ( (lv_set_0_0= rulemessageExpression ) )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==103) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSparrow.g:3483:4: (lv_set_0_0= rulemessageExpression )
                    {
                    // InternalSparrow.g:3483:4: (lv_set_0_0= rulemessageExpression )
                    // InternalSparrow.g:3484:5: lv_set_0_0= rulemessageExpression
                    {

                    					newCompositeNode(grammarAccess.getTotalExpressionAccess().getSetMessageExpressionParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_53);
                    lv_set_0_0=rulemessageExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTotalExpressionRule());
                    					}
                    					set(
                    						current,
                    						"set",
                    						lv_set_0_0,
                    						"org.xtext.example.mydsl.Sparrow.messageExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3501:3: ( (lv_totalCondition_1_0= ruleTotalCondition ) )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==77) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSparrow.g:3502:4: (lv_totalCondition_1_0= ruleTotalCondition )
                    {
                    // InternalSparrow.g:3502:4: (lv_totalCondition_1_0= ruleTotalCondition )
                    // InternalSparrow.g:3503:5: lv_totalCondition_1_0= ruleTotalCondition
                    {

                    					newCompositeNode(grammarAccess.getTotalExpressionAccess().getTotalConditionTotalConditionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_54);
                    lv_totalCondition_1_0=ruleTotalCondition();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTotalExpressionRule());
                    					}
                    					set(
                    						current,
                    						"totalCondition",
                    						lv_totalCondition_1_0,
                    						"org.xtext.example.mydsl.Sparrow.TotalCondition");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3520:3: ( (lv_totalOperation_2_0= ruleTotalOperation ) )
            // InternalSparrow.g:3521:4: (lv_totalOperation_2_0= ruleTotalOperation )
            {
            // InternalSparrow.g:3521:4: (lv_totalOperation_2_0= ruleTotalOperation )
            // InternalSparrow.g:3522:5: lv_totalOperation_2_0= ruleTotalOperation
            {

            					newCompositeNode(grammarAccess.getTotalExpressionAccess().getTotalOperationTotalOperationParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_55);
            lv_totalOperation_2_0=ruleTotalOperation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTotalExpressionRule());
            					}
            					set(
            						current,
            						"totalOperation",
            						lv_totalOperation_2_0,
            						"org.xtext.example.mydsl.Sparrow.TotalOperation");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:3539:3: ( (lv_elseExpression_3_0= ruleElseExpression ) )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==81) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSparrow.g:3540:4: (lv_elseExpression_3_0= ruleElseExpression )
                    {
                    // InternalSparrow.g:3540:4: (lv_elseExpression_3_0= ruleElseExpression )
                    // InternalSparrow.g:3541:5: lv_elseExpression_3_0= ruleElseExpression
                    {

                    					newCompositeNode(grammarAccess.getTotalExpressionAccess().getElseExpressionElseExpressionParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_elseExpression_3_0=ruleElseExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTotalExpressionRule());
                    					}
                    					set(
                    						current,
                    						"elseExpression",
                    						lv_elseExpression_3_0,
                    						"org.xtext.example.mydsl.Sparrow.ElseExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTotalExpression"


    // $ANTLR start "entryRuleElseExpression"
    // InternalSparrow.g:3562:1: entryRuleElseExpression returns [EObject current=null] : iv_ruleElseExpression= ruleElseExpression EOF ;
    public final EObject entryRuleElseExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElseExpression = null;


        try {
            // InternalSparrow.g:3562:55: (iv_ruleElseExpression= ruleElseExpression EOF )
            // InternalSparrow.g:3563:2: iv_ruleElseExpression= ruleElseExpression EOF
            {
             newCompositeNode(grammarAccess.getElseExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElseExpression=ruleElseExpression();

            state._fsp--;

             current =iv_ruleElseExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElseExpression"


    // $ANTLR start "ruleElseExpression"
    // InternalSparrow.g:3569:1: ruleElseExpression returns [EObject current=null] : (otherlv_0= 'Else' ( (lv_set_1_0= rulemessageExpression ) )? ( (lv_totalCondition_2_0= ruleTotalCondition ) )? ( (lv_totalOperation_3_0= ruleTotalOperation ) ) ) ;
    public final EObject ruleElseExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_set_1_0 = null;

        EObject lv_totalCondition_2_0 = null;

        EObject lv_totalOperation_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3575:2: ( (otherlv_0= 'Else' ( (lv_set_1_0= rulemessageExpression ) )? ( (lv_totalCondition_2_0= ruleTotalCondition ) )? ( (lv_totalOperation_3_0= ruleTotalOperation ) ) ) )
            // InternalSparrow.g:3576:2: (otherlv_0= 'Else' ( (lv_set_1_0= rulemessageExpression ) )? ( (lv_totalCondition_2_0= ruleTotalCondition ) )? ( (lv_totalOperation_3_0= ruleTotalOperation ) ) )
            {
            // InternalSparrow.g:3576:2: (otherlv_0= 'Else' ( (lv_set_1_0= rulemessageExpression ) )? ( (lv_totalCondition_2_0= ruleTotalCondition ) )? ( (lv_totalOperation_3_0= ruleTotalOperation ) ) )
            // InternalSparrow.g:3577:3: otherlv_0= 'Else' ( (lv_set_1_0= rulemessageExpression ) )? ( (lv_totalCondition_2_0= ruleTotalCondition ) )? ( (lv_totalOperation_3_0= ruleTotalOperation ) )
            {
            otherlv_0=(Token)match(input,81,FOLLOW_56); 

            			newLeafNode(otherlv_0, grammarAccess.getElseExpressionAccess().getElseKeyword_0());
            		
            // InternalSparrow.g:3581:3: ( (lv_set_1_0= rulemessageExpression ) )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==103) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSparrow.g:3582:4: (lv_set_1_0= rulemessageExpression )
                    {
                    // InternalSparrow.g:3582:4: (lv_set_1_0= rulemessageExpression )
                    // InternalSparrow.g:3583:5: lv_set_1_0= rulemessageExpression
                    {

                    					newCompositeNode(grammarAccess.getElseExpressionAccess().getSetMessageExpressionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_57);
                    lv_set_1_0=rulemessageExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getElseExpressionRule());
                    					}
                    					set(
                    						current,
                    						"set",
                    						lv_set_1_0,
                    						"org.xtext.example.mydsl.Sparrow.messageExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3600:3: ( (lv_totalCondition_2_0= ruleTotalCondition ) )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==77) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSparrow.g:3601:4: (lv_totalCondition_2_0= ruleTotalCondition )
                    {
                    // InternalSparrow.g:3601:4: (lv_totalCondition_2_0= ruleTotalCondition )
                    // InternalSparrow.g:3602:5: lv_totalCondition_2_0= ruleTotalCondition
                    {

                    					newCompositeNode(grammarAccess.getElseExpressionAccess().getTotalConditionTotalConditionParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_58);
                    lv_totalCondition_2_0=ruleTotalCondition();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getElseExpressionRule());
                    					}
                    					set(
                    						current,
                    						"totalCondition",
                    						lv_totalCondition_2_0,
                    						"org.xtext.example.mydsl.Sparrow.TotalCondition");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3619:3: ( (lv_totalOperation_3_0= ruleTotalOperation ) )
            // InternalSparrow.g:3620:4: (lv_totalOperation_3_0= ruleTotalOperation )
            {
            // InternalSparrow.g:3620:4: (lv_totalOperation_3_0= ruleTotalOperation )
            // InternalSparrow.g:3621:5: lv_totalOperation_3_0= ruleTotalOperation
            {

            					newCompositeNode(grammarAccess.getElseExpressionAccess().getTotalOperationTotalOperationParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_totalOperation_3_0=ruleTotalOperation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getElseExpressionRule());
            					}
            					set(
            						current,
            						"totalOperation",
            						lv_totalOperation_3_0,
            						"org.xtext.example.mydsl.Sparrow.TotalOperation");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElseExpression"


    // $ANTLR start "entryRuleRuleExpression"
    // InternalSparrow.g:3642:1: entryRuleRuleExpression returns [EObject current=null] : iv_ruleRuleExpression= ruleRuleExpression EOF ;
    public final EObject entryRuleRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRuleExpression = null;


        try {
            // InternalSparrow.g:3642:55: (iv_ruleRuleExpression= ruleRuleExpression EOF )
            // InternalSparrow.g:3643:2: iv_ruleRuleExpression= ruleRuleExpression EOF
            {
             newCompositeNode(grammarAccess.getRuleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRuleExpression=ruleRuleExpression();

            state._fsp--;

             current =iv_ruleRuleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRuleExpression"


    // $ANTLR start "ruleRuleExpression"
    // InternalSparrow.g:3649:1: ruleRuleExpression returns [EObject current=null] : ( ( (lv_repeat_0_0= 'Repeat' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_set_3_0= rulemessageExpression ) )? ( (lv_setdate_4_0= rulesetDateExpression ) )? ( (lv_totalCondition_5_0= ruleTotalCondition ) )? ( (lv_totalOperation_6_0= ruleTotalOperation ) ) ( (lv_subExpression_7_0= ruleSubExpression ) )* ( (lv_elseExpression_8_0= ruleElseExpression ) )? ) ;
    public final EObject ruleRuleExpression() throws RecognitionException {
        EObject current = null;

        Token lv_repeat_0_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_set_3_0 = null;

        EObject lv_setdate_4_0 = null;

        EObject lv_totalCondition_5_0 = null;

        EObject lv_totalOperation_6_0 = null;

        EObject lv_subExpression_7_0 = null;

        EObject lv_elseExpression_8_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3655:2: ( ( ( (lv_repeat_0_0= 'Repeat' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_set_3_0= rulemessageExpression ) )? ( (lv_setdate_4_0= rulesetDateExpression ) )? ( (lv_totalCondition_5_0= ruleTotalCondition ) )? ( (lv_totalOperation_6_0= ruleTotalOperation ) ) ( (lv_subExpression_7_0= ruleSubExpression ) )* ( (lv_elseExpression_8_0= ruleElseExpression ) )? ) )
            // InternalSparrow.g:3656:2: ( ( (lv_repeat_0_0= 'Repeat' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_set_3_0= rulemessageExpression ) )? ( (lv_setdate_4_0= rulesetDateExpression ) )? ( (lv_totalCondition_5_0= ruleTotalCondition ) )? ( (lv_totalOperation_6_0= ruleTotalOperation ) ) ( (lv_subExpression_7_0= ruleSubExpression ) )* ( (lv_elseExpression_8_0= ruleElseExpression ) )? )
            {
            // InternalSparrow.g:3656:2: ( ( (lv_repeat_0_0= 'Repeat' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_set_3_0= rulemessageExpression ) )? ( (lv_setdate_4_0= rulesetDateExpression ) )? ( (lv_totalCondition_5_0= ruleTotalCondition ) )? ( (lv_totalOperation_6_0= ruleTotalOperation ) ) ( (lv_subExpression_7_0= ruleSubExpression ) )* ( (lv_elseExpression_8_0= ruleElseExpression ) )? )
            // InternalSparrow.g:3657:3: ( (lv_repeat_0_0= 'Repeat' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_set_3_0= rulemessageExpression ) )? ( (lv_setdate_4_0= rulesetDateExpression ) )? ( (lv_totalCondition_5_0= ruleTotalCondition ) )? ( (lv_totalOperation_6_0= ruleTotalOperation ) ) ( (lv_subExpression_7_0= ruleSubExpression ) )* ( (lv_elseExpression_8_0= ruleElseExpression ) )?
            {
            // InternalSparrow.g:3657:3: ( (lv_repeat_0_0= 'Repeat' ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==82) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSparrow.g:3658:4: (lv_repeat_0_0= 'Repeat' )
                    {
                    // InternalSparrow.g:3658:4: (lv_repeat_0_0= 'Repeat' )
                    // InternalSparrow.g:3659:5: lv_repeat_0_0= 'Repeat'
                    {
                    lv_repeat_0_0=(Token)match(input,82,FOLLOW_3); 

                    					newLeafNode(lv_repeat_0_0, grammarAccess.getRuleExpressionAccess().getRepeatRepeatKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getRuleExpressionRule());
                    					}
                    					setWithLastConsumed(current, "repeat", lv_repeat_0_0, "Repeat");
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3671:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSparrow.g:3672:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSparrow.g:3672:4: (lv_name_1_0= RULE_ID )
            // InternalSparrow.g:3673:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_name_1_0, grammarAccess.getRuleExpressionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRuleExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,21,FOLLOW_59); 

            			newLeafNode(otherlv_2, grammarAccess.getRuleExpressionAccess().getColonKeyword_2());
            		
            // InternalSparrow.g:3693:3: ( (lv_set_3_0= rulemessageExpression ) )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==103) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSparrow.g:3694:4: (lv_set_3_0= rulemessageExpression )
                    {
                    // InternalSparrow.g:3694:4: (lv_set_3_0= rulemessageExpression )
                    // InternalSparrow.g:3695:5: lv_set_3_0= rulemessageExpression
                    {

                    					newCompositeNode(grammarAccess.getRuleExpressionAccess().getSetMessageExpressionParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_60);
                    lv_set_3_0=rulemessageExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
                    					}
                    					set(
                    						current,
                    						"set",
                    						lv_set_3_0,
                    						"org.xtext.example.mydsl.Sparrow.messageExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3712:3: ( (lv_setdate_4_0= rulesetDateExpression ) )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==83) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSparrow.g:3713:4: (lv_setdate_4_0= rulesetDateExpression )
                    {
                    // InternalSparrow.g:3713:4: (lv_setdate_4_0= rulesetDateExpression )
                    // InternalSparrow.g:3714:5: lv_setdate_4_0= rulesetDateExpression
                    {

                    					newCompositeNode(grammarAccess.getRuleExpressionAccess().getSetdateSetDateExpressionParserRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_61);
                    lv_setdate_4_0=rulesetDateExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
                    					}
                    					set(
                    						current,
                    						"setdate",
                    						lv_setdate_4_0,
                    						"org.xtext.example.mydsl.Sparrow.setDateExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3731:3: ( (lv_totalCondition_5_0= ruleTotalCondition ) )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==77) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSparrow.g:3732:4: (lv_totalCondition_5_0= ruleTotalCondition )
                    {
                    // InternalSparrow.g:3732:4: (lv_totalCondition_5_0= ruleTotalCondition )
                    // InternalSparrow.g:3733:5: lv_totalCondition_5_0= ruleTotalCondition
                    {

                    					newCompositeNode(grammarAccess.getRuleExpressionAccess().getTotalConditionTotalConditionParserRuleCall_5_0());
                    				
                    pushFollow(FOLLOW_62);
                    lv_totalCondition_5_0=ruleTotalCondition();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
                    					}
                    					set(
                    						current,
                    						"totalCondition",
                    						lv_totalCondition_5_0,
                    						"org.xtext.example.mydsl.Sparrow.TotalCondition");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3750:3: ( (lv_totalOperation_6_0= ruleTotalOperation ) )
            // InternalSparrow.g:3751:4: (lv_totalOperation_6_0= ruleTotalOperation )
            {
            // InternalSparrow.g:3751:4: (lv_totalOperation_6_0= ruleTotalOperation )
            // InternalSparrow.g:3752:5: lv_totalOperation_6_0= ruleTotalOperation
            {

            					newCompositeNode(grammarAccess.getRuleExpressionAccess().getTotalOperationTotalOperationParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_63);
            lv_totalOperation_6_0=ruleTotalOperation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
            					}
            					set(
            						current,
            						"totalOperation",
            						lv_totalOperation_6_0,
            						"org.xtext.example.mydsl.Sparrow.TotalOperation");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:3769:3: ( (lv_subExpression_7_0= ruleSubExpression ) )*
            loop69:
            do {
                int alt69=2;
                int LA69_0 = input.LA(1);

                if ( (LA69_0==84) ) {
                    alt69=1;
                }


                switch (alt69) {
            	case 1 :
            	    // InternalSparrow.g:3770:4: (lv_subExpression_7_0= ruleSubExpression )
            	    {
            	    // InternalSparrow.g:3770:4: (lv_subExpression_7_0= ruleSubExpression )
            	    // InternalSparrow.g:3771:5: lv_subExpression_7_0= ruleSubExpression
            	    {

            	    					newCompositeNode(grammarAccess.getRuleExpressionAccess().getSubExpressionSubExpressionParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_63);
            	    lv_subExpression_7_0=ruleSubExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subExpression",
            	    						lv_subExpression_7_0,
            	    						"org.xtext.example.mydsl.Sparrow.SubExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop69;
                }
            } while (true);

            // InternalSparrow.g:3788:3: ( (lv_elseExpression_8_0= ruleElseExpression ) )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==81) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSparrow.g:3789:4: (lv_elseExpression_8_0= ruleElseExpression )
                    {
                    // InternalSparrow.g:3789:4: (lv_elseExpression_8_0= ruleElseExpression )
                    // InternalSparrow.g:3790:5: lv_elseExpression_8_0= ruleElseExpression
                    {

                    					newCompositeNode(grammarAccess.getRuleExpressionAccess().getElseExpressionElseExpressionParserRuleCall_8_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_elseExpression_8_0=ruleElseExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRuleExpressionRule());
                    					}
                    					set(
                    						current,
                    						"elseExpression",
                    						lv_elseExpression_8_0,
                    						"org.xtext.example.mydsl.Sparrow.ElseExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRuleExpression"


    // $ANTLR start "entryRulesetDateExpression"
    // InternalSparrow.g:3811:1: entryRulesetDateExpression returns [EObject current=null] : iv_rulesetDateExpression= rulesetDateExpression EOF ;
    public final EObject entryRulesetDateExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulesetDateExpression = null;


        try {
            // InternalSparrow.g:3811:58: (iv_rulesetDateExpression= rulesetDateExpression EOF )
            // InternalSparrow.g:3812:2: iv_rulesetDateExpression= rulesetDateExpression EOF
            {
             newCompositeNode(grammarAccess.getSetDateExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulesetDateExpression=rulesetDateExpression();

            state._fsp--;

             current =iv_rulesetDateExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulesetDateExpression"


    // $ANTLR start "rulesetDateExpression"
    // InternalSparrow.g:3818:1: rulesetDateExpression returns [EObject current=null] : (otherlv_0= 'SetDate(' ( (lv_message_1_0= RULE_ID ) ) otherlv_2= ')' ) ;
    public final EObject rulesetDateExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_message_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSparrow.g:3824:2: ( (otherlv_0= 'SetDate(' ( (lv_message_1_0= RULE_ID ) ) otherlv_2= ')' ) )
            // InternalSparrow.g:3825:2: (otherlv_0= 'SetDate(' ( (lv_message_1_0= RULE_ID ) ) otherlv_2= ')' )
            {
            // InternalSparrow.g:3825:2: (otherlv_0= 'SetDate(' ( (lv_message_1_0= RULE_ID ) ) otherlv_2= ')' )
            // InternalSparrow.g:3826:3: otherlv_0= 'SetDate(' ( (lv_message_1_0= RULE_ID ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,83,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getSetDateExpressionAccess().getSetDateKeyword_0());
            		
            // InternalSparrow.g:3830:3: ( (lv_message_1_0= RULE_ID ) )
            // InternalSparrow.g:3831:4: (lv_message_1_0= RULE_ID )
            {
            // InternalSparrow.g:3831:4: (lv_message_1_0= RULE_ID )
            // InternalSparrow.g:3832:5: lv_message_1_0= RULE_ID
            {
            lv_message_1_0=(Token)match(input,RULE_ID,FOLLOW_64); 

            					newLeafNode(lv_message_1_0, grammarAccess.getSetDateExpressionAccess().getMessageIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSetDateExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"message",
            						lv_message_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getSetDateExpressionAccess().getRightParenthesisKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulesetDateExpression"


    // $ANTLR start "entryRuleSubExpression"
    // InternalSparrow.g:3856:1: entryRuleSubExpression returns [EObject current=null] : iv_ruleSubExpression= ruleSubExpression EOF ;
    public final EObject entryRuleSubExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubExpression = null;


        try {
            // InternalSparrow.g:3856:54: (iv_ruleSubExpression= ruleSubExpression EOF )
            // InternalSparrow.g:3857:2: iv_ruleSubExpression= ruleSubExpression EOF
            {
             newCompositeNode(grammarAccess.getSubExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubExpression=ruleSubExpression();

            state._fsp--;

             current =iv_ruleSubExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubExpression"


    // $ANTLR start "ruleSubExpression"
    // InternalSparrow.g:3863:1: ruleSubExpression returns [EObject current=null] : (otherlv_0= 'SubRule' otherlv_1= '{' ( (lv_totalExpression_2_0= ruleTotalExpression ) ) otherlv_3= '}' ) ;
    public final EObject ruleSubExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_totalExpression_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3869:2: ( (otherlv_0= 'SubRule' otherlv_1= '{' ( (lv_totalExpression_2_0= ruleTotalExpression ) ) otherlv_3= '}' ) )
            // InternalSparrow.g:3870:2: (otherlv_0= 'SubRule' otherlv_1= '{' ( (lv_totalExpression_2_0= ruleTotalExpression ) ) otherlv_3= '}' )
            {
            // InternalSparrow.g:3870:2: (otherlv_0= 'SubRule' otherlv_1= '{' ( (lv_totalExpression_2_0= ruleTotalExpression ) ) otherlv_3= '}' )
            // InternalSparrow.g:3871:3: otherlv_0= 'SubRule' otherlv_1= '{' ( (lv_totalExpression_2_0= ruleTotalExpression ) ) otherlv_3= '}'
            {
            otherlv_0=(Token)match(input,84,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getSubExpressionAccess().getSubRuleKeyword_0());
            		
            otherlv_1=(Token)match(input,18,FOLLOW_65); 

            			newLeafNode(otherlv_1, grammarAccess.getSubExpressionAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalSparrow.g:3879:3: ( (lv_totalExpression_2_0= ruleTotalExpression ) )
            // InternalSparrow.g:3880:4: (lv_totalExpression_2_0= ruleTotalExpression )
            {
            // InternalSparrow.g:3880:4: (lv_totalExpression_2_0= ruleTotalExpression )
            // InternalSparrow.g:3881:5: lv_totalExpression_2_0= ruleTotalExpression
            {

            					newCompositeNode(grammarAccess.getSubExpressionAccess().getTotalExpressionTotalExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_15);
            lv_totalExpression_2_0=ruleTotalExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSubExpressionRule());
            					}
            					set(
            						current,
            						"totalExpression",
            						lv_totalExpression_2_0,
            						"org.xtext.example.mydsl.Sparrow.TotalExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getSubExpressionAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubExpression"


    // $ANTLR start "entryRuleFailResult"
    // InternalSparrow.g:3906:1: entryRuleFailResult returns [EObject current=null] : iv_ruleFailResult= ruleFailResult EOF ;
    public final EObject entryRuleFailResult() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFailResult = null;


        try {
            // InternalSparrow.g:3906:51: (iv_ruleFailResult= ruleFailResult EOF )
            // InternalSparrow.g:3907:2: iv_ruleFailResult= ruleFailResult EOF
            {
             newCompositeNode(grammarAccess.getFailResultRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFailResult=ruleFailResult();

            state._fsp--;

             current =iv_ruleFailResult; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFailResult"


    // $ANTLR start "ruleFailResult"
    // InternalSparrow.g:3913:1: ruleFailResult returns [EObject current=null] : (otherlv_0= 'FailResult:' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_thenoperation_5_0= ruleThenOperation ) )* ) ;
    public final EObject ruleFailResult() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_followingOperation_1_0 = null;

        EObject lv_andor_3_0 = null;

        EObject lv_timePoint_4_0 = null;

        EObject lv_thenoperation_5_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:3919:2: ( (otherlv_0= 'FailResult:' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_thenoperation_5_0= ruleThenOperation ) )* ) )
            // InternalSparrow.g:3920:2: (otherlv_0= 'FailResult:' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_thenoperation_5_0= ruleThenOperation ) )* )
            {
            // InternalSparrow.g:3920:2: (otherlv_0= 'FailResult:' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_thenoperation_5_0= ruleThenOperation ) )* )
            // InternalSparrow.g:3921:3: otherlv_0= 'FailResult:' ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) ) ( (lv_andor_3_0= ruleAndOrOperationLink ) )* ( (lv_timePoint_4_0= ruleTimepoint ) )? ( (lv_thenoperation_5_0= ruleThenOperation ) )*
            {
            otherlv_0=(Token)match(input,85,FOLLOW_38); 

            			newLeafNode(otherlv_0, grammarAccess.getFailResultAccess().getFailResultKeyword_0());
            		
            // InternalSparrow.g:3925:3: ( ( (lv_followingOperation_1_0= ruletrueOperation ) ) | ( (otherlv_2= RULE_ID ) ) )
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( ((LA71_0>=105 && LA71_0<=107)||LA71_0==114) ) {
                alt71=1;
            }
            else if ( (LA71_0==RULE_ID) ) {
                alt71=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 71, 0, input);

                throw nvae;
            }
            switch (alt71) {
                case 1 :
                    // InternalSparrow.g:3926:4: ( (lv_followingOperation_1_0= ruletrueOperation ) )
                    {
                    // InternalSparrow.g:3926:4: ( (lv_followingOperation_1_0= ruletrueOperation ) )
                    // InternalSparrow.g:3927:5: (lv_followingOperation_1_0= ruletrueOperation )
                    {
                    // InternalSparrow.g:3927:5: (lv_followingOperation_1_0= ruletrueOperation )
                    // InternalSparrow.g:3928:6: lv_followingOperation_1_0= ruletrueOperation
                    {

                    						newCompositeNode(grammarAccess.getFailResultAccess().getFollowingOperationTrueOperationParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_66);
                    lv_followingOperation_1_0=ruletrueOperation();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFailResultRule());
                    						}
                    						set(
                    							current,
                    							"followingOperation",
                    							lv_followingOperation_1_0,
                    							"org.xtext.example.mydsl.Sparrow.trueOperation");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:3946:4: ( (otherlv_2= RULE_ID ) )
                    {
                    // InternalSparrow.g:3946:4: ( (otherlv_2= RULE_ID ) )
                    // InternalSparrow.g:3947:5: (otherlv_2= RULE_ID )
                    {
                    // InternalSparrow.g:3947:5: (otherlv_2= RULE_ID )
                    // InternalSparrow.g:3948:6: otherlv_2= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFailResultRule());
                    						}
                    					
                    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_66); 

                    						newLeafNode(otherlv_2, grammarAccess.getFailResultAccess().getLinkOperationOperateLinkCrossReference_1_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:3960:3: ( (lv_andor_3_0= ruleAndOrOperationLink ) )*
            loop72:
            do {
                int alt72=2;
                int LA72_0 = input.LA(1);

                if ( (LA72_0==70) ) {
                    alt72=1;
                }


                switch (alt72) {
            	case 1 :
            	    // InternalSparrow.g:3961:4: (lv_andor_3_0= ruleAndOrOperationLink )
            	    {
            	    // InternalSparrow.g:3961:4: (lv_andor_3_0= ruleAndOrOperationLink )
            	    // InternalSparrow.g:3962:5: lv_andor_3_0= ruleAndOrOperationLink
            	    {

            	    					newCompositeNode(grammarAccess.getFailResultAccess().getAndorAndOrOperationLinkParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_66);
            	    lv_andor_3_0=ruleAndOrOperationLink();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFailResultRule());
            	    					}
            	    					add(
            	    						current,
            	    						"andor",
            	    						lv_andor_3_0,
            	    						"org.xtext.example.mydsl.Sparrow.AndOrOperationLink");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop72;
                }
            } while (true);

            // InternalSparrow.g:3979:3: ( (lv_timePoint_4_0= ruleTimepoint ) )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==86||LA73_0==88) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSparrow.g:3980:4: (lv_timePoint_4_0= ruleTimepoint )
                    {
                    // InternalSparrow.g:3980:4: (lv_timePoint_4_0= ruleTimepoint )
                    // InternalSparrow.g:3981:5: lv_timePoint_4_0= ruleTimepoint
                    {

                    					newCompositeNode(grammarAccess.getFailResultAccess().getTimePointTimepointParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_50);
                    lv_timePoint_4_0=ruleTimepoint();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getFailResultRule());
                    					}
                    					set(
                    						current,
                    						"timePoint",
                    						lv_timePoint_4_0,
                    						"org.xtext.example.mydsl.Sparrow.Timepoint");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:3998:3: ( (lv_thenoperation_5_0= ruleThenOperation ) )*
            loop74:
            do {
                int alt74=2;
                int LA74_0 = input.LA(1);

                if ( (LA74_0==80) ) {
                    alt74=1;
                }


                switch (alt74) {
            	case 1 :
            	    // InternalSparrow.g:3999:4: (lv_thenoperation_5_0= ruleThenOperation )
            	    {
            	    // InternalSparrow.g:3999:4: (lv_thenoperation_5_0= ruleThenOperation )
            	    // InternalSparrow.g:4000:5: lv_thenoperation_5_0= ruleThenOperation
            	    {

            	    					newCompositeNode(grammarAccess.getFailResultAccess().getThenoperationThenOperationParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_50);
            	    lv_thenoperation_5_0=ruleThenOperation();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFailResultRule());
            	    					}
            	    					add(
            	    						current,
            	    						"thenoperation",
            	    						lv_thenoperation_5_0,
            	    						"org.xtext.example.mydsl.Sparrow.ThenOperation");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop74;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFailResult"


    // $ANTLR start "entryRuleTimepoint"
    // InternalSparrow.g:4021:1: entryRuleTimepoint returns [EObject current=null] : iv_ruleTimepoint= ruleTimepoint EOF ;
    public final EObject entryRuleTimepoint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimepoint = null;


        try {
            // InternalSparrow.g:4021:50: (iv_ruleTimepoint= ruleTimepoint EOF )
            // InternalSparrow.g:4022:2: iv_ruleTimepoint= ruleTimepoint EOF
            {
             newCompositeNode(grammarAccess.getTimepointRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimepoint=ruleTimepoint();

            state._fsp--;

             current =iv_ruleTimepoint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimepoint"


    // $ANTLR start "ruleTimepoint"
    // InternalSparrow.g:4028:1: ruleTimepoint returns [EObject current=null] : (this_WithinPoint_0= ruleWithinPoint | this_BeforePoint_1= ruleBeforePoint ) ;
    public final EObject ruleTimepoint() throws RecognitionException {
        EObject current = null;

        EObject this_WithinPoint_0 = null;

        EObject this_BeforePoint_1 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4034:2: ( (this_WithinPoint_0= ruleWithinPoint | this_BeforePoint_1= ruleBeforePoint ) )
            // InternalSparrow.g:4035:2: (this_WithinPoint_0= ruleWithinPoint | this_BeforePoint_1= ruleBeforePoint )
            {
            // InternalSparrow.g:4035:2: (this_WithinPoint_0= ruleWithinPoint | this_BeforePoint_1= ruleBeforePoint )
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==86) ) {
                alt75=1;
            }
            else if ( (LA75_0==88) ) {
                alt75=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 75, 0, input);

                throw nvae;
            }
            switch (alt75) {
                case 1 :
                    // InternalSparrow.g:4036:3: this_WithinPoint_0= ruleWithinPoint
                    {

                    			newCompositeNode(grammarAccess.getTimepointAccess().getWithinPointParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_WithinPoint_0=ruleWithinPoint();

                    state._fsp--;


                    			current = this_WithinPoint_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:4045:3: this_BeforePoint_1= ruleBeforePoint
                    {

                    			newCompositeNode(grammarAccess.getTimepointAccess().getBeforePointParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_BeforePoint_1=ruleBeforePoint();

                    state._fsp--;


                    			current = this_BeforePoint_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimepoint"


    // $ANTLR start "entryRuleWithinPoint"
    // InternalSparrow.g:4057:1: entryRuleWithinPoint returns [EObject current=null] : iv_ruleWithinPoint= ruleWithinPoint EOF ;
    public final EObject entryRuleWithinPoint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWithinPoint = null;


        try {
            // InternalSparrow.g:4057:52: (iv_ruleWithinPoint= ruleWithinPoint EOF )
            // InternalSparrow.g:4058:2: iv_ruleWithinPoint= ruleWithinPoint EOF
            {
             newCompositeNode(grammarAccess.getWithinPointRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWithinPoint=ruleWithinPoint();

            state._fsp--;

             current =iv_ruleWithinPoint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWithinPoint"


    // $ANTLR start "ruleWithinPoint"
    // InternalSparrow.g:4064:1: ruleWithinPoint returns [EObject current=null] : (otherlv_0= 'within' ( (lv_number_1_0= RULE_INT ) ) ( (lv_time_2_0= ruleEachTime ) ) otherlv_3= 'after' ( (otherlv_4= RULE_ID ) ) ) ;
    public final EObject ruleWithinPoint() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_number_1_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_time_2_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4070:2: ( (otherlv_0= 'within' ( (lv_number_1_0= RULE_INT ) ) ( (lv_time_2_0= ruleEachTime ) ) otherlv_3= 'after' ( (otherlv_4= RULE_ID ) ) ) )
            // InternalSparrow.g:4071:2: (otherlv_0= 'within' ( (lv_number_1_0= RULE_INT ) ) ( (lv_time_2_0= ruleEachTime ) ) otherlv_3= 'after' ( (otherlv_4= RULE_ID ) ) )
            {
            // InternalSparrow.g:4071:2: (otherlv_0= 'within' ( (lv_number_1_0= RULE_INT ) ) ( (lv_time_2_0= ruleEachTime ) ) otherlv_3= 'after' ( (otherlv_4= RULE_ID ) ) )
            // InternalSparrow.g:4072:3: otherlv_0= 'within' ( (lv_number_1_0= RULE_INT ) ) ( (lv_time_2_0= ruleEachTime ) ) otherlv_3= 'after' ( (otherlv_4= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,86,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getWithinPointAccess().getWithinKeyword_0());
            		
            // InternalSparrow.g:4076:3: ( (lv_number_1_0= RULE_INT ) )
            // InternalSparrow.g:4077:4: (lv_number_1_0= RULE_INT )
            {
            // InternalSparrow.g:4077:4: (lv_number_1_0= RULE_INT )
            // InternalSparrow.g:4078:5: lv_number_1_0= RULE_INT
            {
            lv_number_1_0=(Token)match(input,RULE_INT,FOLLOW_67); 

            					newLeafNode(lv_number_1_0, grammarAccess.getWithinPointAccess().getNumberINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getWithinPointRule());
            					}
            					setWithLastConsumed(
            						current,
            						"number",
            						lv_number_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSparrow.g:4094:3: ( (lv_time_2_0= ruleEachTime ) )
            // InternalSparrow.g:4095:4: (lv_time_2_0= ruleEachTime )
            {
            // InternalSparrow.g:4095:4: (lv_time_2_0= ruleEachTime )
            // InternalSparrow.g:4096:5: lv_time_2_0= ruleEachTime
            {

            					newCompositeNode(grammarAccess.getWithinPointAccess().getTimeEachTimeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_68);
            lv_time_2_0=ruleEachTime();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWithinPointRule());
            					}
            					set(
            						current,
            						"time",
            						lv_time_2_0,
            						"org.xtext.example.mydsl.Sparrow.EachTime");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,87,FOLLOW_3); 

            			newLeafNode(otherlv_3, grammarAccess.getWithinPointAccess().getAfterKeyword_3());
            		
            // InternalSparrow.g:4117:3: ( (otherlv_4= RULE_ID ) )
            // InternalSparrow.g:4118:4: (otherlv_4= RULE_ID )
            {
            // InternalSparrow.g:4118:4: (otherlv_4= RULE_ID )
            // InternalSparrow.g:4119:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getWithinPointRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_4, grammarAccess.getWithinPointAccess().getThingRuleExpressionCrossReference_4_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWithinPoint"


    // $ANTLR start "entryRuleBeforePoint"
    // InternalSparrow.g:4134:1: entryRuleBeforePoint returns [EObject current=null] : iv_ruleBeforePoint= ruleBeforePoint EOF ;
    public final EObject entryRuleBeforePoint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBeforePoint = null;


        try {
            // InternalSparrow.g:4134:52: (iv_ruleBeforePoint= ruleBeforePoint EOF )
            // InternalSparrow.g:4135:2: iv_ruleBeforePoint= ruleBeforePoint EOF
            {
             newCompositeNode(grammarAccess.getBeforePointRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBeforePoint=ruleBeforePoint();

            state._fsp--;

             current =iv_ruleBeforePoint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBeforePoint"


    // $ANTLR start "ruleBeforePoint"
    // InternalSparrow.g:4141:1: ruleBeforePoint returns [EObject current=null] : (otherlv_0= 'before' ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) ) ) ;
    public final EObject ruleBeforePoint() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_lineTime_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4147:2: ( (otherlv_0= 'before' ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) ) ) )
            // InternalSparrow.g:4148:2: (otherlv_0= 'before' ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) ) )
            {
            // InternalSparrow.g:4148:2: (otherlv_0= 'before' ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) ) )
            // InternalSparrow.g:4149:3: otherlv_0= 'before' ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) )
            {
            otherlv_0=(Token)match(input,88,FOLLOW_69); 

            			newLeafNode(otherlv_0, grammarAccess.getBeforePointAccess().getBeforeKeyword_0());
            		
            // InternalSparrow.g:4153:3: ( ( (lv_lineTime_1_0= ruleThisDate ) ) | ( (otherlv_2= RULE_ID ) ) )
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_INT) ) {
                alt76=1;
            }
            else if ( (LA76_0==RULE_ID) ) {
                alt76=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }
            switch (alt76) {
                case 1 :
                    // InternalSparrow.g:4154:4: ( (lv_lineTime_1_0= ruleThisDate ) )
                    {
                    // InternalSparrow.g:4154:4: ( (lv_lineTime_1_0= ruleThisDate ) )
                    // InternalSparrow.g:4155:5: (lv_lineTime_1_0= ruleThisDate )
                    {
                    // InternalSparrow.g:4155:5: (lv_lineTime_1_0= ruleThisDate )
                    // InternalSparrow.g:4156:6: lv_lineTime_1_0= ruleThisDate
                    {

                    						newCompositeNode(grammarAccess.getBeforePointAccess().getLineTimeThisDateParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_lineTime_1_0=ruleThisDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBeforePointRule());
                    						}
                    						set(
                    							current,
                    							"lineTime",
                    							lv_lineTime_1_0,
                    							"org.xtext.example.mydsl.Sparrow.ThisDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSparrow.g:4174:4: ( (otherlv_2= RULE_ID ) )
                    {
                    // InternalSparrow.g:4174:4: ( (otherlv_2= RULE_ID ) )
                    // InternalSparrow.g:4175:5: (otherlv_2= RULE_ID )
                    {
                    // InternalSparrow.g:4175:5: (otherlv_2= RULE_ID )
                    // InternalSparrow.g:4176:6: otherlv_2= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getBeforePointRule());
                    						}
                    					
                    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(otherlv_2, grammarAccess.getBeforePointAccess().getValueKeyvalueCrossReference_1_1_0());
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBeforePoint"


    // $ANTLR start "entryRuleSingleCondition"
    // InternalSparrow.g:4192:1: entryRuleSingleCondition returns [EObject current=null] : iv_ruleSingleCondition= ruleSingleCondition EOF ;
    public final EObject entryRuleSingleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingleCondition = null;


        try {
            // InternalSparrow.g:4192:56: (iv_ruleSingleCondition= ruleSingleCondition EOF )
            // InternalSparrow.g:4193:2: iv_ruleSingleCondition= ruleSingleCondition EOF
            {
             newCompositeNode(grammarAccess.getSingleConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingleCondition=ruleSingleCondition();

            state._fsp--;

             current =iv_ruleSingleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingleCondition"


    // $ANTLR start "ruleSingleCondition"
    // InternalSparrow.g:4199:1: ruleSingleCondition returns [EObject current=null] : ( ( (lv_no_0_0= '!' ) )? ( (lv_condition_1_0= ruleTrueCondition ) ) ) ;
    public final EObject ruleSingleCondition() throws RecognitionException {
        EObject current = null;

        Token lv_no_0_0=null;
        EObject lv_condition_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4205:2: ( ( ( (lv_no_0_0= '!' ) )? ( (lv_condition_1_0= ruleTrueCondition ) ) ) )
            // InternalSparrow.g:4206:2: ( ( (lv_no_0_0= '!' ) )? ( (lv_condition_1_0= ruleTrueCondition ) ) )
            {
            // InternalSparrow.g:4206:2: ( ( (lv_no_0_0= '!' ) )? ( (lv_condition_1_0= ruleTrueCondition ) ) )
            // InternalSparrow.g:4207:3: ( (lv_no_0_0= '!' ) )? ( (lv_condition_1_0= ruleTrueCondition ) )
            {
            // InternalSparrow.g:4207:3: ( (lv_no_0_0= '!' ) )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==78) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalSparrow.g:4208:4: (lv_no_0_0= '!' )
                    {
                    // InternalSparrow.g:4208:4: (lv_no_0_0= '!' )
                    // InternalSparrow.g:4209:5: lv_no_0_0= '!'
                    {
                    lv_no_0_0=(Token)match(input,78,FOLLOW_70); 

                    					newLeafNode(lv_no_0_0, grammarAccess.getSingleConditionAccess().getNoExclamationMarkKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingleConditionRule());
                    					}
                    					setWithLastConsumed(current, "no", lv_no_0_0, "!");
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:4221:3: ( (lv_condition_1_0= ruleTrueCondition ) )
            // InternalSparrow.g:4222:4: (lv_condition_1_0= ruleTrueCondition )
            {
            // InternalSparrow.g:4222:4: (lv_condition_1_0= ruleTrueCondition )
            // InternalSparrow.g:4223:5: lv_condition_1_0= ruleTrueCondition
            {

            					newCompositeNode(grammarAccess.getSingleConditionAccess().getConditionTrueConditionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_condition_1_0=ruleTrueCondition();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSingleConditionRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_1_0,
            						"org.xtext.example.mydsl.Sparrow.TrueCondition");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingleCondition"


    // $ANTLR start "entryRuleTrueCondition"
    // InternalSparrow.g:4244:1: entryRuleTrueCondition returns [EObject current=null] : iv_ruleTrueCondition= ruleTrueCondition EOF ;
    public final EObject entryRuleTrueCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTrueCondition = null;


        try {
            // InternalSparrow.g:4244:54: (iv_ruleTrueCondition= ruleTrueCondition EOF )
            // InternalSparrow.g:4245:2: iv_ruleTrueCondition= ruleTrueCondition EOF
            {
             newCompositeNode(grammarAccess.getTrueConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTrueCondition=ruleTrueCondition();

            state._fsp--;

             current =iv_ruleTrueCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTrueCondition"


    // $ANTLR start "ruleTrueCondition"
    // InternalSparrow.g:4251:1: ruleTrueCondition returns [EObject current=null] : (this_isTime_0= ruleisTime | this_logic_1= rulelogic | this_isTrue_2= ruleisTrue | this_isDone_3= ruleisDone | this_checkExpression_4= rulecheckExpression | this_Timepoint_5= ruleTimepoint | this_CompareString_6= ruleCompareString | this_TimeSub_7= ruleTimeSub ) ;
    public final EObject ruleTrueCondition() throws RecognitionException {
        EObject current = null;

        EObject this_isTime_0 = null;

        EObject this_logic_1 = null;

        EObject this_isTrue_2 = null;

        EObject this_isDone_3 = null;

        EObject this_checkExpression_4 = null;

        EObject this_Timepoint_5 = null;

        EObject this_CompareString_6 = null;

        EObject this_TimeSub_7 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4257:2: ( (this_isTime_0= ruleisTime | this_logic_1= rulelogic | this_isTrue_2= ruleisTrue | this_isDone_3= ruleisDone | this_checkExpression_4= rulecheckExpression | this_Timepoint_5= ruleTimepoint | this_CompareString_6= ruleCompareString | this_TimeSub_7= ruleTimeSub ) )
            // InternalSparrow.g:4258:2: (this_isTime_0= ruleisTime | this_logic_1= rulelogic | this_isTrue_2= ruleisTrue | this_isDone_3= ruleisDone | this_checkExpression_4= rulecheckExpression | this_Timepoint_5= ruleTimepoint | this_CompareString_6= ruleCompareString | this_TimeSub_7= ruleTimeSub )
            {
            // InternalSparrow.g:4258:2: (this_isTime_0= ruleisTime | this_logic_1= rulelogic | this_isTrue_2= ruleisTrue | this_isDone_3= ruleisDone | this_checkExpression_4= rulecheckExpression | this_Timepoint_5= ruleTimepoint | this_CompareString_6= ruleCompareString | this_TimeSub_7= ruleTimeSub )
            int alt78=8;
            switch ( input.LA(1) ) {
            case 93:
                {
                alt78=1;
                }
                break;
            case 94:
                {
                alt78=2;
                }
                break;
            case 95:
                {
                alt78=3;
                }
                break;
            case 96:
                {
                alt78=4;
                }
                break;
            case 97:
                {
                alt78=5;
                }
                break;
            case 86:
            case 88:
                {
                alt78=6;
                }
                break;
            case 89:
                {
                alt78=7;
                }
                break;
            case 90:
                {
                alt78=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }

            switch (alt78) {
                case 1 :
                    // InternalSparrow.g:4259:3: this_isTime_0= ruleisTime
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getIsTimeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_isTime_0=ruleisTime();

                    state._fsp--;


                    			current = this_isTime_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:4268:3: this_logic_1= rulelogic
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getLogicParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_logic_1=rulelogic();

                    state._fsp--;


                    			current = this_logic_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:4277:3: this_isTrue_2= ruleisTrue
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getIsTrueParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_isTrue_2=ruleisTrue();

                    state._fsp--;


                    			current = this_isTrue_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:4286:3: this_isDone_3= ruleisDone
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getIsDoneParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_isDone_3=ruleisDone();

                    state._fsp--;


                    			current = this_isDone_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:4295:3: this_checkExpression_4= rulecheckExpression
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getCheckExpressionParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_checkExpression_4=rulecheckExpression();

                    state._fsp--;


                    			current = this_checkExpression_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSparrow.g:4304:3: this_Timepoint_5= ruleTimepoint
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getTimepointParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Timepoint_5=ruleTimepoint();

                    state._fsp--;


                    			current = this_Timepoint_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSparrow.g:4313:3: this_CompareString_6= ruleCompareString
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getCompareStringParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompareString_6=ruleCompareString();

                    state._fsp--;


                    			current = this_CompareString_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSparrow.g:4322:3: this_TimeSub_7= ruleTimeSub
                    {

                    			newCompositeNode(grammarAccess.getTrueConditionAccess().getTimeSubParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_TimeSub_7=ruleTimeSub();

                    state._fsp--;


                    			current = this_TimeSub_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTrueCondition"


    // $ANTLR start "entryRuleCompareString"
    // InternalSparrow.g:4334:1: entryRuleCompareString returns [EObject current=null] : iv_ruleCompareString= ruleCompareString EOF ;
    public final EObject entryRuleCompareString() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompareString = null;


        try {
            // InternalSparrow.g:4334:54: (iv_ruleCompareString= ruleCompareString EOF )
            // InternalSparrow.g:4335:2: iv_ruleCompareString= ruleCompareString EOF
            {
             newCompositeNode(grammarAccess.getCompareStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompareString=ruleCompareString();

            state._fsp--;

             current =iv_ruleCompareString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompareString"


    // $ANTLR start "ruleCompareString"
    // InternalSparrow.g:4341:1: ruleCompareString returns [EObject current=null] : (otherlv_0= 'compareString(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ')' ) ;
    public final EObject ruleCompareString() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_valueA_1_0 = null;

        EObject lv_valueB_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4347:2: ( (otherlv_0= 'compareString(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:4348:2: (otherlv_0= 'compareString(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:4348:2: (otherlv_0= 'compareString(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            // InternalSparrow.g:4349:3: otherlv_0= 'compareString(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,89,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getCompareStringAccess().getCompareStringKeyword_0());
            		
            // InternalSparrow.g:4353:3: ( (lv_valueA_1_0= ruleMixExpression ) )
            // InternalSparrow.g:4354:4: (lv_valueA_1_0= ruleMixExpression )
            {
            // InternalSparrow.g:4354:4: (lv_valueA_1_0= ruleMixExpression )
            // InternalSparrow.g:4355:5: lv_valueA_1_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getCompareStringAccess().getValueAMixExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_32);
            lv_valueA_1_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCompareStringRule());
            					}
            					set(
            						current,
            						"valueA",
            						lv_valueA_1_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_71); 

            			newLeafNode(otherlv_2, grammarAccess.getCompareStringAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:4376:3: ( (lv_valueB_3_0= ruleMixExpression ) )
            // InternalSparrow.g:4377:4: (lv_valueB_3_0= ruleMixExpression )
            {
            // InternalSparrow.g:4377:4: (lv_valueB_3_0= ruleMixExpression )
            // InternalSparrow.g:4378:5: lv_valueB_3_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getCompareStringAccess().getValueBMixExpressionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_valueB_3_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCompareStringRule());
            					}
            					set(
            						current,
            						"valueB",
            						lv_valueB_3_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCompareStringAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompareString"


    // $ANTLR start "entryRuleTimeSub"
    // InternalSparrow.g:4403:1: entryRuleTimeSub returns [EObject current=null] : iv_ruleTimeSub= ruleTimeSub EOF ;
    public final EObject entryRuleTimeSub() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeSub = null;


        try {
            // InternalSparrow.g:4403:48: (iv_ruleTimeSub= ruleTimeSub EOF )
            // InternalSparrow.g:4404:2: iv_ruleTimeSub= ruleTimeSub EOF
            {
             newCompositeNode(grammarAccess.getTimeSubRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimeSub=ruleTimeSub();

            state._fsp--;

             current =iv_ruleTimeSub; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeSub"


    // $ANTLR start "ruleTimeSub"
    // InternalSparrow.g:4410:1: ruleTimeSub returns [EObject current=null] : (otherlv_0= 'timeSub(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) )? (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )? otherlv_6= ',' ( (lv_duration_7_0= ruleDuration ) ) otherlv_8= ',' ( (lv_compare_9_0= RULE_MATH_SYMBOL ) ) otherlv_10= ')' ) ;
    public final EObject ruleTimeSub() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token lv_compare_9_0=null;
        Token otherlv_10=null;
        EObject lv_valueA_1_0 = null;

        EObject lv_valueB_3_0 = null;

        EObject lv_duration_7_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4416:2: ( (otherlv_0= 'timeSub(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) )? (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )? otherlv_6= ',' ( (lv_duration_7_0= ruleDuration ) ) otherlv_8= ',' ( (lv_compare_9_0= RULE_MATH_SYMBOL ) ) otherlv_10= ')' ) )
            // InternalSparrow.g:4417:2: (otherlv_0= 'timeSub(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) )? (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )? otherlv_6= ',' ( (lv_duration_7_0= ruleDuration ) ) otherlv_8= ',' ( (lv_compare_9_0= RULE_MATH_SYMBOL ) ) otherlv_10= ')' )
            {
            // InternalSparrow.g:4417:2: (otherlv_0= 'timeSub(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) )? (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )? otherlv_6= ',' ( (lv_duration_7_0= ruleDuration ) ) otherlv_8= ',' ( (lv_compare_9_0= RULE_MATH_SYMBOL ) ) otherlv_10= ')' )
            // InternalSparrow.g:4418:3: otherlv_0= 'timeSub(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) )? (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )? otherlv_6= ',' ( (lv_duration_7_0= ruleDuration ) ) otherlv_8= ',' ( (lv_compare_9_0= RULE_MATH_SYMBOL ) ) otherlv_10= ')'
            {
            otherlv_0=(Token)match(input,90,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getTimeSubAccess().getTimeSubKeyword_0());
            		
            // InternalSparrow.g:4422:3: ( (lv_valueA_1_0= ruleMixExpression ) )
            // InternalSparrow.g:4423:4: (lv_valueA_1_0= ruleMixExpression )
            {
            // InternalSparrow.g:4423:4: (lv_valueA_1_0= ruleMixExpression )
            // InternalSparrow.g:4424:5: lv_valueA_1_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getTimeSubAccess().getValueAMixExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_32);
            lv_valueA_1_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTimeSubRule());
            					}
            					set(
            						current,
            						"valueA",
            						lv_valueA_1_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_72); 

            			newLeafNode(otherlv_2, grammarAccess.getTimeSubAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:4445:3: ( (lv_valueB_3_0= ruleMixExpression ) )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( ((LA79_0>=RULE_ID && LA79_0<=RULE_INT)||LA79_0==RULE_DECIMAL||LA79_0==37||LA79_0==41||LA79_0==63||(LA79_0>=98 && LA79_0<=101)||(LA79_0>=116 && LA79_0<=117)) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSparrow.g:4446:4: (lv_valueB_3_0= ruleMixExpression )
                    {
                    // InternalSparrow.g:4446:4: (lv_valueB_3_0= ruleMixExpression )
                    // InternalSparrow.g:4447:5: lv_valueB_3_0= ruleMixExpression
                    {

                    					newCompositeNode(grammarAccess.getTimeSubAccess().getValueBMixExpressionParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_73);
                    lv_valueB_3_0=ruleMixExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTimeSubRule());
                    					}
                    					set(
                    						current,
                    						"valueB",
                    						lv_valueB_3_0,
                    						"org.xtext.example.mydsl.Sparrow.MixExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:4464:3: (otherlv_4= 'r' ( (otherlv_5= RULE_ID ) ) )?
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==91) ) {
                alt80=1;
            }
            switch (alt80) {
                case 1 :
                    // InternalSparrow.g:4465:4: otherlv_4= 'r' ( (otherlv_5= RULE_ID ) )
                    {
                    otherlv_4=(Token)match(input,91,FOLLOW_3); 

                    				newLeafNode(otherlv_4, grammarAccess.getTimeSubAccess().getRKeyword_4_0());
                    			
                    // InternalSparrow.g:4469:4: ( (otherlv_5= RULE_ID ) )
                    // InternalSparrow.g:4470:5: (otherlv_5= RULE_ID )
                    {
                    // InternalSparrow.g:4470:5: (otherlv_5= RULE_ID )
                    // InternalSparrow.g:4471:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTimeSubRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_32); 

                    						newLeafNode(otherlv_5, grammarAccess.getTimeSubAccess().getValueCRuleExpressionCrossReference_4_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_31); 

            			newLeafNode(otherlv_6, grammarAccess.getTimeSubAccess().getCommaKeyword_5());
            		
            // InternalSparrow.g:4487:3: ( (lv_duration_7_0= ruleDuration ) )
            // InternalSparrow.g:4488:4: (lv_duration_7_0= ruleDuration )
            {
            // InternalSparrow.g:4488:4: (lv_duration_7_0= ruleDuration )
            // InternalSparrow.g:4489:5: lv_duration_7_0= ruleDuration
            {

            					newCompositeNode(grammarAccess.getTimeSubAccess().getDurationDurationParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_32);
            lv_duration_7_0=ruleDuration();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTimeSubRule());
            					}
            					set(
            						current,
            						"duration",
            						lv_duration_7_0,
            						"org.xtext.example.mydsl.Sparrow.Duration");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,22,FOLLOW_74); 

            			newLeafNode(otherlv_8, grammarAccess.getTimeSubAccess().getCommaKeyword_7());
            		
            // InternalSparrow.g:4510:3: ( (lv_compare_9_0= RULE_MATH_SYMBOL ) )
            // InternalSparrow.g:4511:4: (lv_compare_9_0= RULE_MATH_SYMBOL )
            {
            // InternalSparrow.g:4511:4: (lv_compare_9_0= RULE_MATH_SYMBOL )
            // InternalSparrow.g:4512:5: lv_compare_9_0= RULE_MATH_SYMBOL
            {
            lv_compare_9_0=(Token)match(input,RULE_MATH_SYMBOL,FOLLOW_64); 

            					newLeafNode(lv_compare_9_0, grammarAccess.getTimeSubAccess().getCompareMATH_SYMBOLTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeSubRule());
            					}
            					setWithLastConsumed(
            						current,
            						"compare",
            						lv_compare_9_0,
            						"org.xtext.example.mydsl.Sparrow.MATH_SYMBOL");
            				

            }


            }

            otherlv_10=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getTimeSubAccess().getRightParenthesisKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeSub"


    // $ANTLR start "entryRuleEachTime"
    // InternalSparrow.g:4536:1: entryRuleEachTime returns [String current=null] : iv_ruleEachTime= ruleEachTime EOF ;
    public final String entryRuleEachTime() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEachTime = null;


        try {
            // InternalSparrow.g:4536:48: (iv_ruleEachTime= ruleEachTime EOF )
            // InternalSparrow.g:4537:2: iv_ruleEachTime= ruleEachTime EOF
            {
             newCompositeNode(grammarAccess.getEachTimeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEachTime=ruleEachTime();

            state._fsp--;

             current =iv_ruleEachTime.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEachTime"


    // $ANTLR start "ruleEachTime"
    // InternalSparrow.g:4543:1: ruleEachTime returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'months' | kw= 'days' | kw= 'hours' | kw= 'years' ) ;
    public final AntlrDatatypeRuleToken ruleEachTime() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:4549:2: ( (kw= 'months' | kw= 'days' | kw= 'hours' | kw= 'years' ) )
            // InternalSparrow.g:4550:2: (kw= 'months' | kw= 'days' | kw= 'hours' | kw= 'years' )
            {
            // InternalSparrow.g:4550:2: (kw= 'months' | kw= 'days' | kw= 'hours' | kw= 'years' )
            int alt81=4;
            switch ( input.LA(1) ) {
            case 59:
                {
                alt81=1;
                }
                break;
            case 60:
                {
                alt81=2;
                }
                break;
            case 61:
                {
                alt81=3;
                }
                break;
            case 92:
                {
                alt81=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 81, 0, input);

                throw nvae;
            }

            switch (alt81) {
                case 1 :
                    // InternalSparrow.g:4551:3: kw= 'months'
                    {
                    kw=(Token)match(input,59,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEachTimeAccess().getMonthsKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:4557:3: kw= 'days'
                    {
                    kw=(Token)match(input,60,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEachTimeAccess().getDaysKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:4563:3: kw= 'hours'
                    {
                    kw=(Token)match(input,61,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEachTimeAccess().getHoursKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:4569:3: kw= 'years'
                    {
                    kw=(Token)match(input,92,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEachTimeAccess().getYearsKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEachTime"


    // $ANTLR start "entryRuleisTime"
    // InternalSparrow.g:4578:1: entryRuleisTime returns [EObject current=null] : iv_ruleisTime= ruleisTime EOF ;
    public final EObject entryRuleisTime() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleisTime = null;


        try {
            // InternalSparrow.g:4578:47: (iv_ruleisTime= ruleisTime EOF )
            // InternalSparrow.g:4579:2: iv_ruleisTime= ruleisTime EOF
            {
             newCompositeNode(grammarAccess.getIsTimeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleisTime=ruleisTime();

            state._fsp--;

             current =iv_ruleisTime; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleisTime"


    // $ANTLR start "ruleisTime"
    // InternalSparrow.g:4585:1: ruleisTime returns [EObject current=null] : ( () otherlv_1= 'isTime(' ( (lv_expression_2_0= ruleMixExpression ) )? (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )? ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )? otherlv_7= ')' ) ;
    public final EObject ruleisTime() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token lv_symbol_5_0=null;
        Token otherlv_7=null;
        EObject lv_expression_2_0 = null;

        EObject lv_duration_6_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4591:2: ( ( () otherlv_1= 'isTime(' ( (lv_expression_2_0= ruleMixExpression ) )? (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )? ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )? otherlv_7= ')' ) )
            // InternalSparrow.g:4592:2: ( () otherlv_1= 'isTime(' ( (lv_expression_2_0= ruleMixExpression ) )? (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )? ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )? otherlv_7= ')' )
            {
            // InternalSparrow.g:4592:2: ( () otherlv_1= 'isTime(' ( (lv_expression_2_0= ruleMixExpression ) )? (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )? ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )? otherlv_7= ')' )
            // InternalSparrow.g:4593:3: () otherlv_1= 'isTime(' ( (lv_expression_2_0= ruleMixExpression ) )? (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )? ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )? otherlv_7= ')'
            {
            // InternalSparrow.g:4593:3: ()
            // InternalSparrow.g:4594:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getIsTimeAccess().getIsTimeAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,93,FOLLOW_75); 

            			newLeafNode(otherlv_1, grammarAccess.getIsTimeAccess().getIsTimeKeyword_1());
            		
            // InternalSparrow.g:4604:3: ( (lv_expression_2_0= ruleMixExpression ) )?
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( ((LA82_0>=RULE_ID && LA82_0<=RULE_INT)||LA82_0==RULE_DECIMAL||LA82_0==37||LA82_0==41||LA82_0==63||(LA82_0>=98 && LA82_0<=101)||(LA82_0>=116 && LA82_0<=117)) ) {
                alt82=1;
            }
            switch (alt82) {
                case 1 :
                    // InternalSparrow.g:4605:4: (lv_expression_2_0= ruleMixExpression )
                    {
                    // InternalSparrow.g:4605:4: (lv_expression_2_0= ruleMixExpression )
                    // InternalSparrow.g:4606:5: lv_expression_2_0= ruleMixExpression
                    {

                    					newCompositeNode(grammarAccess.getIsTimeAccess().getExpressionMixExpressionParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_76);
                    lv_expression_2_0=ruleMixExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIsTimeRule());
                    					}
                    					set(
                    						current,
                    						"expression",
                    						lv_expression_2_0,
                    						"org.xtext.example.mydsl.Sparrow.MixExpression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:4623:3: (otherlv_3= 'r' ( (otherlv_4= RULE_ID ) ) )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==91) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSparrow.g:4624:4: otherlv_3= 'r' ( (otherlv_4= RULE_ID ) )
                    {
                    otherlv_3=(Token)match(input,91,FOLLOW_3); 

                    				newLeafNode(otherlv_3, grammarAccess.getIsTimeAccess().getRKeyword_3_0());
                    			
                    // InternalSparrow.g:4628:4: ( (otherlv_4= RULE_ID ) )
                    // InternalSparrow.g:4629:5: (otherlv_4= RULE_ID )
                    {
                    // InternalSparrow.g:4629:5: (otherlv_4= RULE_ID )
                    // InternalSparrow.g:4630:6: otherlv_4= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getIsTimeRule());
                    						}
                    					
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_77); 

                    						newLeafNode(otherlv_4, grammarAccess.getIsTimeAccess().getValueRuleExpressionCrossReference_3_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSparrow.g:4642:3: ( ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) ) )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==RULE_ARITHMETIC_OPERATOR) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // InternalSparrow.g:4643:4: ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_duration_6_0= ruleDuration ) )
                    {
                    // InternalSparrow.g:4643:4: ( (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR ) )
                    // InternalSparrow.g:4644:5: (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR )
                    {
                    // InternalSparrow.g:4644:5: (lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR )
                    // InternalSparrow.g:4645:6: lv_symbol_5_0= RULE_ARITHMETIC_OPERATOR
                    {
                    lv_symbol_5_0=(Token)match(input,RULE_ARITHMETIC_OPERATOR,FOLLOW_31); 

                    						newLeafNode(lv_symbol_5_0, grammarAccess.getIsTimeAccess().getSymbolARITHMETIC_OPERATORTerminalRuleCall_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getIsTimeRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"symbol",
                    							lv_symbol_5_0,
                    							"org.xtext.example.mydsl.Sparrow.ARITHMETIC_OPERATOR");
                    					

                    }


                    }

                    // InternalSparrow.g:4661:4: ( (lv_duration_6_0= ruleDuration ) )
                    // InternalSparrow.g:4662:5: (lv_duration_6_0= ruleDuration )
                    {
                    // InternalSparrow.g:4662:5: (lv_duration_6_0= ruleDuration )
                    // InternalSparrow.g:4663:6: lv_duration_6_0= ruleDuration
                    {

                    						newCompositeNode(grammarAccess.getIsTimeAccess().getDurationDurationParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_64);
                    lv_duration_6_0=ruleDuration();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIsTimeRule());
                    						}
                    						set(
                    							current,
                    							"duration",
                    							lv_duration_6_0,
                    							"org.xtext.example.mydsl.Sparrow.Duration");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_7=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getIsTimeAccess().getRightParenthesisKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleisTime"


    // $ANTLR start "entryRulelogic"
    // InternalSparrow.g:4689:1: entryRulelogic returns [EObject current=null] : iv_rulelogic= rulelogic EOF ;
    public final EObject entryRulelogic() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelogic = null;


        try {
            // InternalSparrow.g:4689:46: (iv_rulelogic= rulelogic EOF )
            // InternalSparrow.g:4690:2: iv_rulelogic= rulelogic EOF
            {
             newCompositeNode(grammarAccess.getLogicRule()); 
            pushFollow(FOLLOW_1);
            iv_rulelogic=rulelogic();

            state._fsp--;

             current =iv_rulelogic; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelogic"


    // $ANTLR start "rulelogic"
    // InternalSparrow.g:4696:1: rulelogic returns [EObject current=null] : (otherlv_0= 'logic(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ',' ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) ) otherlv_6= ')' ) ;
    public final EObject rulelogic() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token lv_mathSymbol_5_0=null;
        Token otherlv_6=null;
        EObject lv_valueA_1_0 = null;

        EObject lv_valueB_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4702:2: ( (otherlv_0= 'logic(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ',' ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) ) otherlv_6= ')' ) )
            // InternalSparrow.g:4703:2: (otherlv_0= 'logic(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ',' ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) ) otherlv_6= ')' )
            {
            // InternalSparrow.g:4703:2: (otherlv_0= 'logic(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ',' ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) ) otherlv_6= ')' )
            // InternalSparrow.g:4704:3: otherlv_0= 'logic(' ( (lv_valueA_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_valueB_3_0= ruleMixExpression ) ) otherlv_4= ',' ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) ) otherlv_6= ')'
            {
            otherlv_0=(Token)match(input,94,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getLogicAccess().getLogicKeyword_0());
            		
            // InternalSparrow.g:4708:3: ( (lv_valueA_1_0= ruleMixExpression ) )
            // InternalSparrow.g:4709:4: (lv_valueA_1_0= ruleMixExpression )
            {
            // InternalSparrow.g:4709:4: (lv_valueA_1_0= ruleMixExpression )
            // InternalSparrow.g:4710:5: lv_valueA_1_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getLogicAccess().getValueAMixExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_32);
            lv_valueA_1_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLogicRule());
            					}
            					set(
            						current,
            						"valueA",
            						lv_valueA_1_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_71); 

            			newLeafNode(otherlv_2, grammarAccess.getLogicAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:4731:3: ( (lv_valueB_3_0= ruleMixExpression ) )
            // InternalSparrow.g:4732:4: (lv_valueB_3_0= ruleMixExpression )
            {
            // InternalSparrow.g:4732:4: (lv_valueB_3_0= ruleMixExpression )
            // InternalSparrow.g:4733:5: lv_valueB_3_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getLogicAccess().getValueBMixExpressionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_32);
            lv_valueB_3_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLogicRule());
            					}
            					set(
            						current,
            						"valueB",
            						lv_valueB_3_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,22,FOLLOW_74); 

            			newLeafNode(otherlv_4, grammarAccess.getLogicAccess().getCommaKeyword_4());
            		
            // InternalSparrow.g:4754:3: ( (lv_mathSymbol_5_0= RULE_MATH_SYMBOL ) )
            // InternalSparrow.g:4755:4: (lv_mathSymbol_5_0= RULE_MATH_SYMBOL )
            {
            // InternalSparrow.g:4755:4: (lv_mathSymbol_5_0= RULE_MATH_SYMBOL )
            // InternalSparrow.g:4756:5: lv_mathSymbol_5_0= RULE_MATH_SYMBOL
            {
            lv_mathSymbol_5_0=(Token)match(input,RULE_MATH_SYMBOL,FOLLOW_64); 

            					newLeafNode(lv_mathSymbol_5_0, grammarAccess.getLogicAccess().getMathSymbolMATH_SYMBOLTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLogicRule());
            					}
            					setWithLastConsumed(
            						current,
            						"mathSymbol",
            						lv_mathSymbol_5_0,
            						"org.xtext.example.mydsl.Sparrow.MATH_SYMBOL");
            				

            }


            }

            otherlv_6=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getLogicAccess().getRightParenthesisKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelogic"


    // $ANTLR start "entryRuleisTrue"
    // InternalSparrow.g:4780:1: entryRuleisTrue returns [EObject current=null] : iv_ruleisTrue= ruleisTrue EOF ;
    public final EObject entryRuleisTrue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleisTrue = null;


        try {
            // InternalSparrow.g:4780:47: (iv_ruleisTrue= ruleisTrue EOF )
            // InternalSparrow.g:4781:2: iv_ruleisTrue= ruleisTrue EOF
            {
             newCompositeNode(grammarAccess.getIsTrueRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleisTrue=ruleisTrue();

            state._fsp--;

             current =iv_ruleisTrue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleisTrue"


    // $ANTLR start "ruleisTrue"
    // InternalSparrow.g:4787:1: ruleisTrue returns [EObject current=null] : (otherlv_0= 'isTrue(' ( (lv_compare_1_0= ruleSingleExpression ) ) otherlv_2= ')' ) ;
    public final EObject ruleisTrue() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_compare_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4793:2: ( (otherlv_0= 'isTrue(' ( (lv_compare_1_0= ruleSingleExpression ) ) otherlv_2= ')' ) )
            // InternalSparrow.g:4794:2: (otherlv_0= 'isTrue(' ( (lv_compare_1_0= ruleSingleExpression ) ) otherlv_2= ')' )
            {
            // InternalSparrow.g:4794:2: (otherlv_0= 'isTrue(' ( (lv_compare_1_0= ruleSingleExpression ) ) otherlv_2= ')' )
            // InternalSparrow.g:4795:3: otherlv_0= 'isTrue(' ( (lv_compare_1_0= ruleSingleExpression ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,95,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getIsTrueAccess().getIsTrueKeyword_0());
            		
            // InternalSparrow.g:4799:3: ( (lv_compare_1_0= ruleSingleExpression ) )
            // InternalSparrow.g:4800:4: (lv_compare_1_0= ruleSingleExpression )
            {
            // InternalSparrow.g:4800:4: (lv_compare_1_0= ruleSingleExpression )
            // InternalSparrow.g:4801:5: lv_compare_1_0= ruleSingleExpression
            {

            					newCompositeNode(grammarAccess.getIsTrueAccess().getCompareSingleExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_64);
            lv_compare_1_0=ruleSingleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIsTrueRule());
            					}
            					set(
            						current,
            						"compare",
            						lv_compare_1_0,
            						"org.xtext.example.mydsl.Sparrow.SingleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getIsTrueAccess().getRightParenthesisKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleisTrue"


    // $ANTLR start "entryRuleisDone"
    // InternalSparrow.g:4826:1: entryRuleisDone returns [EObject current=null] : iv_ruleisDone= ruleisDone EOF ;
    public final EObject entryRuleisDone() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleisDone = null;


        try {
            // InternalSparrow.g:4826:47: (iv_ruleisDone= ruleisDone EOF )
            // InternalSparrow.g:4827:2: iv_ruleisDone= ruleisDone EOF
            {
             newCompositeNode(grammarAccess.getIsDoneRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleisDone=ruleisDone();

            state._fsp--;

             current =iv_ruleisDone; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleisDone"


    // $ANTLR start "ruleisDone"
    // InternalSparrow.g:4833:1: ruleisDone returns [EObject current=null] : (otherlv_0= 'isDone(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) ;
    public final EObject ruleisDone() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSparrow.g:4839:2: ( (otherlv_0= 'isDone(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) )
            // InternalSparrow.g:4840:2: (otherlv_0= 'isDone(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            {
            // InternalSparrow.g:4840:2: (otherlv_0= 'isDone(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            // InternalSparrow.g:4841:3: otherlv_0= 'isDone(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,96,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getIsDoneAccess().getIsDoneKeyword_0());
            		
            // InternalSparrow.g:4845:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:4846:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:4846:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:4847:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getIsDoneRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_64); 

            					newLeafNode(otherlv_1, grammarAccess.getIsDoneAccess().getNameRuleExpressionCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getIsDoneAccess().getRightParenthesisKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleisDone"


    // $ANTLR start "entryRulecheckExpression"
    // InternalSparrow.g:4866:1: entryRulecheckExpression returns [EObject current=null] : iv_rulecheckExpression= rulecheckExpression EOF ;
    public final EObject entryRulecheckExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulecheckExpression = null;


        try {
            // InternalSparrow.g:4866:56: (iv_rulecheckExpression= rulecheckExpression EOF )
            // InternalSparrow.g:4867:2: iv_rulecheckExpression= rulecheckExpression EOF
            {
             newCompositeNode(grammarAccess.getCheckExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulecheckExpression=rulecheckExpression();

            state._fsp--;

             current =iv_rulecheckExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulecheckExpression"


    // $ANTLR start "rulecheckExpression"
    // InternalSparrow.g:4873:1: rulecheckExpression returns [EObject current=null] : (otherlv_0= 'check(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) ;
    public final EObject rulecheckExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSparrow.g:4879:2: ( (otherlv_0= 'check(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) )
            // InternalSparrow.g:4880:2: (otherlv_0= 'check(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            {
            // InternalSparrow.g:4880:2: (otherlv_0= 'check(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            // InternalSparrow.g:4881:3: otherlv_0= 'check(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,97,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getCheckExpressionAccess().getCheckKeyword_0());
            		
            // InternalSparrow.g:4885:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:4886:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:4886:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:4887:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCheckExpressionRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_64); 

            					newLeafNode(otherlv_1, grammarAccess.getCheckExpressionAccess().getNameModelCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getCheckExpressionAccess().getRightParenthesisKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulecheckExpression"


    // $ANTLR start "entryRuleMixExpression"
    // InternalSparrow.g:4906:1: entryRuleMixExpression returns [EObject current=null] : iv_ruleMixExpression= ruleMixExpression EOF ;
    public final EObject entryRuleMixExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMixExpression = null;


        try {
            // InternalSparrow.g:4906:54: (iv_ruleMixExpression= ruleMixExpression EOF )
            // InternalSparrow.g:4907:2: iv_ruleMixExpression= ruleMixExpression EOF
            {
             newCompositeNode(grammarAccess.getMixExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMixExpression=ruleMixExpression();

            state._fsp--;

             current =iv_ruleMixExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMixExpression"


    // $ANTLR start "ruleMixExpression"
    // InternalSparrow.g:4913:1: ruleMixExpression returns [EObject current=null] : ( ( (lv_expression_0_0= ruleSingleExpression ) ) ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )* ) ;
    public final EObject ruleMixExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_expression_0_0 = null;

        EObject lv_otherMixExpression_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4919:2: ( ( ( (lv_expression_0_0= ruleSingleExpression ) ) ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )* ) )
            // InternalSparrow.g:4920:2: ( ( (lv_expression_0_0= ruleSingleExpression ) ) ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )* )
            {
            // InternalSparrow.g:4920:2: ( ( (lv_expression_0_0= ruleSingleExpression ) ) ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )* )
            // InternalSparrow.g:4921:3: ( (lv_expression_0_0= ruleSingleExpression ) ) ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )*
            {
            // InternalSparrow.g:4921:3: ( (lv_expression_0_0= ruleSingleExpression ) )
            // InternalSparrow.g:4922:4: (lv_expression_0_0= ruleSingleExpression )
            {
            // InternalSparrow.g:4922:4: (lv_expression_0_0= ruleSingleExpression )
            // InternalSparrow.g:4923:5: lv_expression_0_0= ruleSingleExpression
            {

            					newCompositeNode(grammarAccess.getMixExpressionAccess().getExpressionSingleExpressionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_78);
            lv_expression_0_0=ruleSingleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMixExpressionRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_0_0,
            						"org.xtext.example.mydsl.Sparrow.SingleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:4940:3: ( (lv_otherMixExpression_1_0= ruleOtherMixExpression ) )*
            loop85:
            do {
                int alt85=2;
                int LA85_0 = input.LA(1);

                if ( (LA85_0==RULE_ARITHMETIC_OPERATOR) ) {
                    int LA85_2 = input.LA(2);

                    if ( (LA85_2==RULE_INT) ) {
                        switch ( input.LA(3) ) {
                        case 59:
                            {
                            alt85=1;
                            }
                            break;
                        case 60:
                            {
                            alt85=1;
                            }
                            break;
                        case EOF:
                        case RULE_ARITHMETIC_OPERATOR:
                        case 22:
                        case 40:
                        case 61:
                        case 65:
                        case 91:
                        case 92:
                            {
                            alt85=1;
                            }
                            break;

                        }

                    }
                    else if ( (LA85_2==RULE_ID||LA85_2==RULE_DECIMAL||LA85_2==37||LA85_2==41||LA85_2==63||(LA85_2>=98 && LA85_2<=101)||(LA85_2>=116 && LA85_2<=117)) ) {
                        alt85=1;
                    }


                }


                switch (alt85) {
            	case 1 :
            	    // InternalSparrow.g:4941:4: (lv_otherMixExpression_1_0= ruleOtherMixExpression )
            	    {
            	    // InternalSparrow.g:4941:4: (lv_otherMixExpression_1_0= ruleOtherMixExpression )
            	    // InternalSparrow.g:4942:5: lv_otherMixExpression_1_0= ruleOtherMixExpression
            	    {

            	    					newCompositeNode(grammarAccess.getMixExpressionAccess().getOtherMixExpressionOtherMixExpressionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_78);
            	    lv_otherMixExpression_1_0=ruleOtherMixExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMixExpressionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"otherMixExpression",
            	    						lv_otherMixExpression_1_0,
            	    						"org.xtext.example.mydsl.Sparrow.OtherMixExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop85;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMixExpression"


    // $ANTLR start "entryRuleOtherMixExpression"
    // InternalSparrow.g:4963:1: entryRuleOtherMixExpression returns [EObject current=null] : iv_ruleOtherMixExpression= ruleOtherMixExpression EOF ;
    public final EObject entryRuleOtherMixExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOtherMixExpression = null;


        try {
            // InternalSparrow.g:4963:59: (iv_ruleOtherMixExpression= ruleOtherMixExpression EOF )
            // InternalSparrow.g:4964:2: iv_ruleOtherMixExpression= ruleOtherMixExpression EOF
            {
             newCompositeNode(grammarAccess.getOtherMixExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOtherMixExpression=ruleOtherMixExpression();

            state._fsp--;

             current =iv_ruleOtherMixExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOtherMixExpression"


    // $ANTLR start "ruleOtherMixExpression"
    // InternalSparrow.g:4970:1: ruleOtherMixExpression returns [EObject current=null] : ( ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_expression_1_0= ruleSingleExpression ) ) ) ;
    public final EObject ruleOtherMixExpression() throws RecognitionException {
        EObject current = null;

        Token lv_link_0_0=null;
        EObject lv_expression_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:4976:2: ( ( ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_expression_1_0= ruleSingleExpression ) ) ) )
            // InternalSparrow.g:4977:2: ( ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_expression_1_0= ruleSingleExpression ) ) )
            {
            // InternalSparrow.g:4977:2: ( ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_expression_1_0= ruleSingleExpression ) ) )
            // InternalSparrow.g:4978:3: ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) ) ( (lv_expression_1_0= ruleSingleExpression ) )
            {
            // InternalSparrow.g:4978:3: ( (lv_link_0_0= RULE_ARITHMETIC_OPERATOR ) )
            // InternalSparrow.g:4979:4: (lv_link_0_0= RULE_ARITHMETIC_OPERATOR )
            {
            // InternalSparrow.g:4979:4: (lv_link_0_0= RULE_ARITHMETIC_OPERATOR )
            // InternalSparrow.g:4980:5: lv_link_0_0= RULE_ARITHMETIC_OPERATOR
            {
            lv_link_0_0=(Token)match(input,RULE_ARITHMETIC_OPERATOR,FOLLOW_71); 

            					newLeafNode(lv_link_0_0, grammarAccess.getOtherMixExpressionAccess().getLinkARITHMETIC_OPERATORTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOtherMixExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"link",
            						lv_link_0_0,
            						"org.xtext.example.mydsl.Sparrow.ARITHMETIC_OPERATOR");
            				

            }


            }

            // InternalSparrow.g:4996:3: ( (lv_expression_1_0= ruleSingleExpression ) )
            // InternalSparrow.g:4997:4: (lv_expression_1_0= ruleSingleExpression )
            {
            // InternalSparrow.g:4997:4: (lv_expression_1_0= ruleSingleExpression )
            // InternalSparrow.g:4998:5: lv_expression_1_0= ruleSingleExpression
            {

            					newCompositeNode(grammarAccess.getOtherMixExpressionAccess().getExpressionSingleExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_expression_1_0=ruleSingleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOtherMixExpressionRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_1_0,
            						"org.xtext.example.mydsl.Sparrow.SingleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOtherMixExpression"


    // $ANTLR start "entryRuleSingleExpression"
    // InternalSparrow.g:5019:1: entryRuleSingleExpression returns [EObject current=null] : iv_ruleSingleExpression= ruleSingleExpression EOF ;
    public final EObject entryRuleSingleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingleExpression = null;


        try {
            // InternalSparrow.g:5019:57: (iv_ruleSingleExpression= ruleSingleExpression EOF )
            // InternalSparrow.g:5020:2: iv_ruleSingleExpression= ruleSingleExpression EOF
            {
             newCompositeNode(grammarAccess.getSingleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingleExpression=ruleSingleExpression();

            state._fsp--;

             current =iv_ruleSingleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingleExpression"


    // $ANTLR start "ruleSingleExpression"
    // InternalSparrow.g:5026:1: ruleSingleExpression returns [EObject current=null] : (this_RegularExpression_0= ruleRegularExpression | this_ThingExpression_1= ruleThingExpression | this_OtherExpression_2= ruleOtherExpression | this_PersonExpression_3= rulePersonExpression | this_RuleTimeExpression_4= ruleRuleTimeExpression | this_FloatExpression_5= ruleFloatExpression | this_StringExpression_6= ruleStringExpression | this_PeriodExpression_7= rulePeriodExpression | this_GetPeriodExpression_8= ruleGetPeriodExpression ) ;
    public final EObject ruleSingleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_RegularExpression_0 = null;

        EObject this_ThingExpression_1 = null;

        EObject this_OtherExpression_2 = null;

        EObject this_PersonExpression_3 = null;

        EObject this_RuleTimeExpression_4 = null;

        EObject this_FloatExpression_5 = null;

        EObject this_StringExpression_6 = null;

        EObject this_PeriodExpression_7 = null;

        EObject this_GetPeriodExpression_8 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5032:2: ( (this_RegularExpression_0= ruleRegularExpression | this_ThingExpression_1= ruleThingExpression | this_OtherExpression_2= ruleOtherExpression | this_PersonExpression_3= rulePersonExpression | this_RuleTimeExpression_4= ruleRuleTimeExpression | this_FloatExpression_5= ruleFloatExpression | this_StringExpression_6= ruleStringExpression | this_PeriodExpression_7= rulePeriodExpression | this_GetPeriodExpression_8= ruleGetPeriodExpression ) )
            // InternalSparrow.g:5033:2: (this_RegularExpression_0= ruleRegularExpression | this_ThingExpression_1= ruleThingExpression | this_OtherExpression_2= ruleOtherExpression | this_PersonExpression_3= rulePersonExpression | this_RuleTimeExpression_4= ruleRuleTimeExpression | this_FloatExpression_5= ruleFloatExpression | this_StringExpression_6= ruleStringExpression | this_PeriodExpression_7= rulePeriodExpression | this_GetPeriodExpression_8= ruleGetPeriodExpression )
            {
            // InternalSparrow.g:5033:2: (this_RegularExpression_0= ruleRegularExpression | this_ThingExpression_1= ruleThingExpression | this_OtherExpression_2= ruleOtherExpression | this_PersonExpression_3= rulePersonExpression | this_RuleTimeExpression_4= ruleRuleTimeExpression | this_FloatExpression_5= ruleFloatExpression | this_StringExpression_6= ruleStringExpression | this_PeriodExpression_7= rulePeriodExpression | this_GetPeriodExpression_8= ruleGetPeriodExpression )
            int alt86=9;
            alt86 = dfa86.predict(input);
            switch (alt86) {
                case 1 :
                    // InternalSparrow.g:5034:3: this_RegularExpression_0= ruleRegularExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getRegularExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_RegularExpression_0=ruleRegularExpression();

                    state._fsp--;


                    			current = this_RegularExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:5043:3: this_ThingExpression_1= ruleThingExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getThingExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThingExpression_1=ruleThingExpression();

                    state._fsp--;


                    			current = this_ThingExpression_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:5052:3: this_OtherExpression_2= ruleOtherExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getOtherExpressionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_OtherExpression_2=ruleOtherExpression();

                    state._fsp--;


                    			current = this_OtherExpression_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:5061:3: this_PersonExpression_3= rulePersonExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getPersonExpressionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_PersonExpression_3=rulePersonExpression();

                    state._fsp--;


                    			current = this_PersonExpression_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:5070:3: this_RuleTimeExpression_4= ruleRuleTimeExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getRuleTimeExpressionParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_RuleTimeExpression_4=ruleRuleTimeExpression();

                    state._fsp--;


                    			current = this_RuleTimeExpression_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSparrow.g:5079:3: this_FloatExpression_5= ruleFloatExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getFloatExpressionParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_FloatExpression_5=ruleFloatExpression();

                    state._fsp--;


                    			current = this_FloatExpression_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSparrow.g:5088:3: this_StringExpression_6= ruleStringExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getStringExpressionParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_StringExpression_6=ruleStringExpression();

                    state._fsp--;


                    			current = this_StringExpression_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSparrow.g:5097:3: this_PeriodExpression_7= rulePeriodExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getPeriodExpressionParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_PeriodExpression_7=rulePeriodExpression();

                    state._fsp--;


                    			current = this_PeriodExpression_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 9 :
                    // InternalSparrow.g:5106:3: this_GetPeriodExpression_8= ruleGetPeriodExpression
                    {

                    			newCompositeNode(grammarAccess.getSingleExpressionAccess().getGetPeriodExpressionParserRuleCall_8());
                    		
                    pushFollow(FOLLOW_2);
                    this_GetPeriodExpression_8=ruleGetPeriodExpression();

                    state._fsp--;


                    			current = this_GetPeriodExpression_8;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingleExpression"


    // $ANTLR start "entryRulePeriodExpression"
    // InternalSparrow.g:5118:1: entryRulePeriodExpression returns [EObject current=null] : iv_rulePeriodExpression= rulePeriodExpression EOF ;
    public final EObject entryRulePeriodExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePeriodExpression = null;


        try {
            // InternalSparrow.g:5118:57: (iv_rulePeriodExpression= rulePeriodExpression EOF )
            // InternalSparrow.g:5119:2: iv_rulePeriodExpression= rulePeriodExpression EOF
            {
             newCompositeNode(grammarAccess.getPeriodExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePeriodExpression=rulePeriodExpression();

            state._fsp--;

             current =iv_rulePeriodExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePeriodExpression"


    // $ANTLR start "rulePeriodExpression"
    // InternalSparrow.g:5125:1: rulePeriodExpression returns [EObject current=null] : ( ( (lv_value_0_0= RULE_INT ) ) ( (lv_type_1_0= ruleEachTime ) ) ) ;
    public final EObject rulePeriodExpression() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5131:2: ( ( ( (lv_value_0_0= RULE_INT ) ) ( (lv_type_1_0= ruleEachTime ) ) ) )
            // InternalSparrow.g:5132:2: ( ( (lv_value_0_0= RULE_INT ) ) ( (lv_type_1_0= ruleEachTime ) ) )
            {
            // InternalSparrow.g:5132:2: ( ( (lv_value_0_0= RULE_INT ) ) ( (lv_type_1_0= ruleEachTime ) ) )
            // InternalSparrow.g:5133:3: ( (lv_value_0_0= RULE_INT ) ) ( (lv_type_1_0= ruleEachTime ) )
            {
            // InternalSparrow.g:5133:3: ( (lv_value_0_0= RULE_INT ) )
            // InternalSparrow.g:5134:4: (lv_value_0_0= RULE_INT )
            {
            // InternalSparrow.g:5134:4: (lv_value_0_0= RULE_INT )
            // InternalSparrow.g:5135:5: lv_value_0_0= RULE_INT
            {
            lv_value_0_0=(Token)match(input,RULE_INT,FOLLOW_67); 

            					newLeafNode(lv_value_0_0, grammarAccess.getPeriodExpressionAccess().getValueINTTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_0_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSparrow.g:5151:3: ( (lv_type_1_0= ruleEachTime ) )
            // InternalSparrow.g:5152:4: (lv_type_1_0= ruleEachTime )
            {
            // InternalSparrow.g:5152:4: (lv_type_1_0= ruleEachTime )
            // InternalSparrow.g:5153:5: lv_type_1_0= ruleEachTime
            {

            					newCompositeNode(grammarAccess.getPeriodExpressionAccess().getTypeEachTimeParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_1_0=ruleEachTime();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPeriodExpressionRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.Sparrow.EachTime");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePeriodExpression"


    // $ANTLR start "entryRuleGetPeriodExpression"
    // InternalSparrow.g:5174:1: entryRuleGetPeriodExpression returns [EObject current=null] : iv_ruleGetPeriodExpression= ruleGetPeriodExpression EOF ;
    public final EObject entryRuleGetPeriodExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGetPeriodExpression = null;


        try {
            // InternalSparrow.g:5174:60: (iv_ruleGetPeriodExpression= ruleGetPeriodExpression EOF )
            // InternalSparrow.g:5175:2: iv_ruleGetPeriodExpression= ruleGetPeriodExpression EOF
            {
             newCompositeNode(grammarAccess.getGetPeriodExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGetPeriodExpression=ruleGetPeriodExpression();

            state._fsp--;

             current =iv_ruleGetPeriodExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGetPeriodExpression"


    // $ANTLR start "ruleGetPeriodExpression"
    // InternalSparrow.g:5181:1: ruleGetPeriodExpression returns [EObject current=null] : ( ( (lv_value_0_0= RULE_ID ) ) ( (lv_type_1_0= ruleEachTime ) ) ) ;
    public final EObject ruleGetPeriodExpression() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5187:2: ( ( ( (lv_value_0_0= RULE_ID ) ) ( (lv_type_1_0= ruleEachTime ) ) ) )
            // InternalSparrow.g:5188:2: ( ( (lv_value_0_0= RULE_ID ) ) ( (lv_type_1_0= ruleEachTime ) ) )
            {
            // InternalSparrow.g:5188:2: ( ( (lv_value_0_0= RULE_ID ) ) ( (lv_type_1_0= ruleEachTime ) ) )
            // InternalSparrow.g:5189:3: ( (lv_value_0_0= RULE_ID ) ) ( (lv_type_1_0= ruleEachTime ) )
            {
            // InternalSparrow.g:5189:3: ( (lv_value_0_0= RULE_ID ) )
            // InternalSparrow.g:5190:4: (lv_value_0_0= RULE_ID )
            {
            // InternalSparrow.g:5190:4: (lv_value_0_0= RULE_ID )
            // InternalSparrow.g:5191:5: lv_value_0_0= RULE_ID
            {
            lv_value_0_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_value_0_0, grammarAccess.getGetPeriodExpressionAccess().getValueIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGetPeriodExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSparrow.g:5207:3: ( (lv_type_1_0= ruleEachTime ) )
            // InternalSparrow.g:5208:4: (lv_type_1_0= ruleEachTime )
            {
            // InternalSparrow.g:5208:4: (lv_type_1_0= ruleEachTime )
            // InternalSparrow.g:5209:5: lv_type_1_0= ruleEachTime
            {

            					newCompositeNode(grammarAccess.getGetPeriodExpressionAccess().getTypeEachTimeParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_1_0=ruleEachTime();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGetPeriodExpressionRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.Sparrow.EachTime");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGetPeriodExpression"


    // $ANTLR start "entryRuleRuleTimeExpression"
    // InternalSparrow.g:5230:1: entryRuleRuleTimeExpression returns [EObject current=null] : iv_ruleRuleTimeExpression= ruleRuleTimeExpression EOF ;
    public final EObject entryRuleRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRuleTimeExpression = null;


        try {
            // InternalSparrow.g:5230:59: (iv_ruleRuleTimeExpression= ruleRuleTimeExpression EOF )
            // InternalSparrow.g:5231:2: iv_ruleRuleTimeExpression= ruleRuleTimeExpression EOF
            {
             newCompositeNode(grammarAccess.getRuleTimeExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRuleTimeExpression=ruleRuleTimeExpression();

            state._fsp--;

             current =iv_ruleRuleTimeExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRuleTimeExpression"


    // $ANTLR start "ruleRuleTimeExpression"
    // InternalSparrow.g:5237:1: ruleRuleTimeExpression returns [EObject current=null] : (otherlv_0= 'getRuleTime(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) ;
    public final EObject ruleRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSparrow.g:5243:2: ( (otherlv_0= 'getRuleTime(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' ) )
            // InternalSparrow.g:5244:2: (otherlv_0= 'getRuleTime(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            {
            // InternalSparrow.g:5244:2: (otherlv_0= 'getRuleTime(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')' )
            // InternalSparrow.g:5245:3: otherlv_0= 'getRuleTime(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,98,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getRuleTimeExpressionAccess().getGetRuleTimeKeyword_0());
            		
            // InternalSparrow.g:5249:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:5250:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:5250:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:5251:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRuleTimeExpressionRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_64); 

            					newLeafNode(otherlv_1, grammarAccess.getRuleTimeExpressionAccess().getValueRuleExpressionCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getRuleTimeExpressionAccess().getRightParenthesisKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRuleTimeExpression"


    // $ANTLR start "entryRuleOtherExpression"
    // InternalSparrow.g:5270:1: entryRuleOtherExpression returns [EObject current=null] : iv_ruleOtherExpression= ruleOtherExpression EOF ;
    public final EObject entryRuleOtherExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOtherExpression = null;


        try {
            // InternalSparrow.g:5270:56: (iv_ruleOtherExpression= ruleOtherExpression EOF )
            // InternalSparrow.g:5271:2: iv_ruleOtherExpression= ruleOtherExpression EOF
            {
             newCompositeNode(grammarAccess.getOtherExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOtherExpression=ruleOtherExpression();

            state._fsp--;

             current =iv_ruleOtherExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOtherExpression"


    // $ANTLR start "ruleOtherExpression"
    // InternalSparrow.g:5277:1: ruleOtherExpression returns [EObject current=null] : ( (lv_value_0_0= RULE_ID ) ) ;
    public final EObject ruleOtherExpression() throws RecognitionException {
        EObject current = null;

        Token lv_value_0_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:5283:2: ( ( (lv_value_0_0= RULE_ID ) ) )
            // InternalSparrow.g:5284:2: ( (lv_value_0_0= RULE_ID ) )
            {
            // InternalSparrow.g:5284:2: ( (lv_value_0_0= RULE_ID ) )
            // InternalSparrow.g:5285:3: (lv_value_0_0= RULE_ID )
            {
            // InternalSparrow.g:5285:3: (lv_value_0_0= RULE_ID )
            // InternalSparrow.g:5286:4: lv_value_0_0= RULE_ID
            {
            lv_value_0_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            				newLeafNode(lv_value_0_0, grammarAccess.getOtherExpressionAccess().getValueIDTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getOtherExpressionRule());
            				}
            				setWithLastConsumed(
            					current,
            					"value",
            					lv_value_0_0,
            					"org.eclipse.xtext.common.Terminals.ID");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOtherExpression"


    // $ANTLR start "entryRuleStringExpression"
    // InternalSparrow.g:5305:1: entryRuleStringExpression returns [EObject current=null] : iv_ruleStringExpression= ruleStringExpression EOF ;
    public final EObject entryRuleStringExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStringExpression = null;


        try {
            // InternalSparrow.g:5305:57: (iv_ruleStringExpression= ruleStringExpression EOF )
            // InternalSparrow.g:5306:2: iv_ruleStringExpression= ruleStringExpression EOF
            {
             newCompositeNode(grammarAccess.getStringExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStringExpression=ruleStringExpression();

            state._fsp--;

             current =iv_ruleStringExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStringExpression"


    // $ANTLR start "ruleStringExpression"
    // InternalSparrow.g:5312:1: ruleStringExpression returns [EObject current=null] : (otherlv_0= '\"' ( (lv_value_1_0= RULE_ID ) ) otherlv_2= '\"' ) ;
    public final EObject ruleStringExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_value_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSparrow.g:5318:2: ( (otherlv_0= '\"' ( (lv_value_1_0= RULE_ID ) ) otherlv_2= '\"' ) )
            // InternalSparrow.g:5319:2: (otherlv_0= '\"' ( (lv_value_1_0= RULE_ID ) ) otherlv_2= '\"' )
            {
            // InternalSparrow.g:5319:2: (otherlv_0= '\"' ( (lv_value_1_0= RULE_ID ) ) otherlv_2= '\"' )
            // InternalSparrow.g:5320:3: otherlv_0= '\"' ( (lv_value_1_0= RULE_ID ) ) otherlv_2= '\"'
            {
            otherlv_0=(Token)match(input,99,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getStringExpressionAccess().getQuotationMarkKeyword_0());
            		
            // InternalSparrow.g:5324:3: ( (lv_value_1_0= RULE_ID ) )
            // InternalSparrow.g:5325:4: (lv_value_1_0= RULE_ID )
            {
            // InternalSparrow.g:5325:4: (lv_value_1_0= RULE_ID )
            // InternalSparrow.g:5326:5: lv_value_1_0= RULE_ID
            {
            lv_value_1_0=(Token)match(input,RULE_ID,FOLLOW_79); 

            					newLeafNode(lv_value_1_0, grammarAccess.getStringExpressionAccess().getValueIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStringExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,99,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getStringExpressionAccess().getQuotationMarkKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStringExpression"


    // $ANTLR start "entryRuleFloatExpression"
    // InternalSparrow.g:5350:1: entryRuleFloatExpression returns [EObject current=null] : iv_ruleFloatExpression= ruleFloatExpression EOF ;
    public final EObject entryRuleFloatExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFloatExpression = null;


        try {
            // InternalSparrow.g:5350:56: (iv_ruleFloatExpression= ruleFloatExpression EOF )
            // InternalSparrow.g:5351:2: iv_ruleFloatExpression= ruleFloatExpression EOF
            {
             newCompositeNode(grammarAccess.getFloatExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFloatExpression=ruleFloatExpression();

            state._fsp--;

             current =iv_ruleFloatExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFloatExpression"


    // $ANTLR start "ruleFloatExpression"
    // InternalSparrow.g:5357:1: ruleFloatExpression returns [EObject current=null] : (otherlv_0= 'f' ( (lv_value_1_0= RULE_ID ) ) ) ;
    public final EObject ruleFloatExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_value_1_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:5363:2: ( (otherlv_0= 'f' ( (lv_value_1_0= RULE_ID ) ) ) )
            // InternalSparrow.g:5364:2: (otherlv_0= 'f' ( (lv_value_1_0= RULE_ID ) ) )
            {
            // InternalSparrow.g:5364:2: (otherlv_0= 'f' ( (lv_value_1_0= RULE_ID ) ) )
            // InternalSparrow.g:5365:3: otherlv_0= 'f' ( (lv_value_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,100,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getFloatExpressionAccess().getFKeyword_0());
            		
            // InternalSparrow.g:5369:3: ( (lv_value_1_0= RULE_ID ) )
            // InternalSparrow.g:5370:4: (lv_value_1_0= RULE_ID )
            {
            // InternalSparrow.g:5370:4: (lv_value_1_0= RULE_ID )
            // InternalSparrow.g:5371:5: lv_value_1_0= RULE_ID
            {
            lv_value_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_value_1_0, grammarAccess.getFloatExpressionAccess().getValueIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFloatExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFloatExpression"


    // $ANTLR start "entryRulePersonExpression"
    // InternalSparrow.g:5391:1: entryRulePersonExpression returns [EObject current=null] : iv_rulePersonExpression= rulePersonExpression EOF ;
    public final EObject entryRulePersonExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonExpression = null;


        try {
            // InternalSparrow.g:5391:57: (iv_rulePersonExpression= rulePersonExpression EOF )
            // InternalSparrow.g:5392:2: iv_rulePersonExpression= rulePersonExpression EOF
            {
             newCompositeNode(grammarAccess.getPersonExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePersonExpression=rulePersonExpression();

            state._fsp--;

             current =iv_rulePersonExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonExpression"


    // $ANTLR start "rulePersonExpression"
    // InternalSparrow.g:5398:1: rulePersonExpression returns [EObject current=null] : (otherlv_0= 'p' ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject rulePersonExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalSparrow.g:5404:2: ( (otherlv_0= 'p' ( (otherlv_1= RULE_ID ) ) ) )
            // InternalSparrow.g:5405:2: (otherlv_0= 'p' ( (otherlv_1= RULE_ID ) ) )
            {
            // InternalSparrow.g:5405:2: (otherlv_0= 'p' ( (otherlv_1= RULE_ID ) ) )
            // InternalSparrow.g:5406:3: otherlv_0= 'p' ( (otherlv_1= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,101,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getPersonExpressionAccess().getPKeyword_0());
            		
            // InternalSparrow.g:5410:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:5411:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:5411:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:5412:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPersonExpressionRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_1, grammarAccess.getPersonExpressionAccess().getValueInitExpressionsCrossReference_1_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonExpression"


    // $ANTLR start "entryRuleRegularExpression"
    // InternalSparrow.g:5427:1: entryRuleRegularExpression returns [EObject current=null] : iv_ruleRegularExpression= ruleRegularExpression EOF ;
    public final EObject entryRuleRegularExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRegularExpression = null;


        try {
            // InternalSparrow.g:5427:58: (iv_ruleRegularExpression= ruleRegularExpression EOF )
            // InternalSparrow.g:5428:2: iv_ruleRegularExpression= ruleRegularExpression EOF
            {
             newCompositeNode(grammarAccess.getRegularExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRegularExpression=ruleRegularExpression();

            state._fsp--;

             current =iv_ruleRegularExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRegularExpression"


    // $ANTLR start "ruleRegularExpression"
    // InternalSparrow.g:5434:1: ruleRegularExpression returns [EObject current=null] : (this_AllNumber_0= ruleAllNumber | this_ThisDecimal_1= ruleThisDecimal | this_ThisBoolean_2= ruleThisBoolean | this_Now_3= ruleNow | this_ThisDate_4= ruleThisDate ) ;
    public final EObject ruleRegularExpression() throws RecognitionException {
        EObject current = null;

        EObject this_AllNumber_0 = null;

        EObject this_ThisDecimal_1 = null;

        EObject this_ThisBoolean_2 = null;

        EObject this_Now_3 = null;

        EObject this_ThisDate_4 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5440:2: ( (this_AllNumber_0= ruleAllNumber | this_ThisDecimal_1= ruleThisDecimal | this_ThisBoolean_2= ruleThisBoolean | this_Now_3= ruleNow | this_ThisDate_4= ruleThisDate ) )
            // InternalSparrow.g:5441:2: (this_AllNumber_0= ruleAllNumber | this_ThisDecimal_1= ruleThisDecimal | this_ThisBoolean_2= ruleThisBoolean | this_Now_3= ruleNow | this_ThisDate_4= ruleThisDate )
            {
            // InternalSparrow.g:5441:2: (this_AllNumber_0= ruleAllNumber | this_ThisDecimal_1= ruleThisDecimal | this_ThisBoolean_2= ruleThisBoolean | this_Now_3= ruleNow | this_ThisDate_4= ruleThisDate )
            int alt87=5;
            switch ( input.LA(1) ) {
            case RULE_INT:
                {
                int LA87_1 = input.LA(2);

                if ( (LA87_1==65) ) {
                    alt87=5;
                }
                else if ( (LA87_1==EOF||LA87_1==RULE_ARITHMETIC_OPERATOR||LA87_1==22||LA87_1==40||LA87_1==91) ) {
                    alt87=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 87, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_DECIMAL:
                {
                alt87=2;
                }
                break;
            case 116:
            case 117:
                {
                alt87=3;
                }
                break;
            case 63:
                {
                alt87=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 87, 0, input);

                throw nvae;
            }

            switch (alt87) {
                case 1 :
                    // InternalSparrow.g:5442:3: this_AllNumber_0= ruleAllNumber
                    {

                    			newCompositeNode(grammarAccess.getRegularExpressionAccess().getAllNumberParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_AllNumber_0=ruleAllNumber();

                    state._fsp--;


                    			current = this_AllNumber_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:5451:3: this_ThisDecimal_1= ruleThisDecimal
                    {

                    			newCompositeNode(grammarAccess.getRegularExpressionAccess().getThisDecimalParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisDecimal_1=ruleThisDecimal();

                    state._fsp--;


                    			current = this_ThisDecimal_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:5460:3: this_ThisBoolean_2= ruleThisBoolean
                    {

                    			newCompositeNode(grammarAccess.getRegularExpressionAccess().getThisBooleanParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisBoolean_2=ruleThisBoolean();

                    state._fsp--;


                    			current = this_ThisBoolean_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:5469:3: this_Now_3= ruleNow
                    {

                    			newCompositeNode(grammarAccess.getRegularExpressionAccess().getNowParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Now_3=ruleNow();

                    state._fsp--;


                    			current = this_Now_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:5478:3: this_ThisDate_4= ruleThisDate
                    {

                    			newCompositeNode(grammarAccess.getRegularExpressionAccess().getThisDateParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_ThisDate_4=ruleThisDate();

                    state._fsp--;


                    			current = this_ThisDate_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRegularExpression"


    // $ANTLR start "entryRuleThingExpression"
    // InternalSparrow.g:5490:1: entryRuleThingExpression returns [EObject current=null] : iv_ruleThingExpression= ruleThingExpression EOF ;
    public final EObject entryRuleThingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThingExpression = null;


        try {
            // InternalSparrow.g:5490:56: (iv_ruleThingExpression= ruleThingExpression EOF )
            // InternalSparrow.g:5491:2: iv_ruleThingExpression= ruleThingExpression EOF
            {
             newCompositeNode(grammarAccess.getThingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThingExpression=ruleThingExpression();

            state._fsp--;

             current =iv_ruleThingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThingExpression"


    // $ANTLR start "ruleThingExpression"
    // InternalSparrow.g:5497:1: ruleThingExpression returns [EObject current=null] : (this_ObjectExpress_0= ruleObjectExpress | this_SubjectExpress_1= ruleSubjectExpress ) ;
    public final EObject ruleThingExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ObjectExpress_0 = null;

        EObject this_SubjectExpress_1 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5503:2: ( (this_ObjectExpress_0= ruleObjectExpress | this_SubjectExpress_1= ruleSubjectExpress ) )
            // InternalSparrow.g:5504:2: (this_ObjectExpress_0= ruleObjectExpress | this_SubjectExpress_1= ruleSubjectExpress )
            {
            // InternalSparrow.g:5504:2: (this_ObjectExpress_0= ruleObjectExpress | this_SubjectExpress_1= ruleSubjectExpress )
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==41) ) {
                alt88=1;
            }
            else if ( (LA88_0==37) ) {
                alt88=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }
            switch (alt88) {
                case 1 :
                    // InternalSparrow.g:5505:3: this_ObjectExpress_0= ruleObjectExpress
                    {

                    			newCompositeNode(grammarAccess.getThingExpressionAccess().getObjectExpressParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ObjectExpress_0=ruleObjectExpress();

                    state._fsp--;


                    			current = this_ObjectExpress_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:5514:3: this_SubjectExpress_1= ruleSubjectExpress
                    {

                    			newCompositeNode(grammarAccess.getThingExpressionAccess().getSubjectExpressParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SubjectExpress_1=ruleSubjectExpress();

                    state._fsp--;


                    			current = this_SubjectExpress_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThingExpression"


    // $ANTLR start "entryRuleSubjectExpress"
    // InternalSparrow.g:5526:1: entryRuleSubjectExpress returns [EObject current=null] : iv_ruleSubjectExpress= ruleSubjectExpress EOF ;
    public final EObject entryRuleSubjectExpress() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubjectExpress = null;


        try {
            // InternalSparrow.g:5526:55: (iv_ruleSubjectExpress= ruleSubjectExpress EOF )
            // InternalSparrow.g:5527:2: iv_ruleSubjectExpress= ruleSubjectExpress EOF
            {
             newCompositeNode(grammarAccess.getSubjectExpressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubjectExpress=ruleSubjectExpress();

            state._fsp--;

             current =iv_ruleSubjectExpress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubjectExpress"


    // $ANTLR start "ruleSubjectExpress"
    // InternalSparrow.g:5533:1: ruleSubjectExpress returns [EObject current=null] : (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) ) ;
    public final EObject ruleSubjectExpress() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_attribute_3_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:5539:2: ( (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) ) )
            // InternalSparrow.g:5540:2: (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) )
            {
            // InternalSparrow.g:5540:2: (otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) )
            // InternalSparrow.g:5541:3: otherlv_0= 's' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,37,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getSubjectExpressAccess().getSKeyword_0());
            		
            // InternalSparrow.g:5545:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:5546:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:5546:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:5547:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSubjectExpressRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_80); 

            					newLeafNode(otherlv_1, grammarAccess.getSubjectExpressAccess().getSubjectInitExpressionsCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,102,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getSubjectExpressAccess().getFullStopKeyword_2());
            		
            // InternalSparrow.g:5562:3: ( (lv_attribute_3_0= RULE_ID ) )
            // InternalSparrow.g:5563:4: (lv_attribute_3_0= RULE_ID )
            {
            // InternalSparrow.g:5563:4: (lv_attribute_3_0= RULE_ID )
            // InternalSparrow.g:5564:5: lv_attribute_3_0= RULE_ID
            {
            lv_attribute_3_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_attribute_3_0, grammarAccess.getSubjectExpressAccess().getAttributeIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSubjectExpressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"attribute",
            						lv_attribute_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubjectExpress"


    // $ANTLR start "entryRuleObjectExpress"
    // InternalSparrow.g:5584:1: entryRuleObjectExpress returns [EObject current=null] : iv_ruleObjectExpress= ruleObjectExpress EOF ;
    public final EObject entryRuleObjectExpress() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObjectExpress = null;


        try {
            // InternalSparrow.g:5584:54: (iv_ruleObjectExpress= ruleObjectExpress EOF )
            // InternalSparrow.g:5585:2: iv_ruleObjectExpress= ruleObjectExpress EOF
            {
             newCompositeNode(grammarAccess.getObjectExpressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObjectExpress=ruleObjectExpress();

            state._fsp--;

             current =iv_ruleObjectExpress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObjectExpress"


    // $ANTLR start "ruleObjectExpress"
    // InternalSparrow.g:5591:1: ruleObjectExpress returns [EObject current=null] : (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) ) ;
    public final EObject ruleObjectExpress() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_attribute_3_0=null;


        	enterRule();

        try {
            // InternalSparrow.g:5597:2: ( (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) ) )
            // InternalSparrow.g:5598:2: (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) )
            {
            // InternalSparrow.g:5598:2: (otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) ) )
            // InternalSparrow.g:5599:3: otherlv_0= 'o' ( (otherlv_1= RULE_ID ) ) otherlv_2= '.' ( (lv_attribute_3_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,41,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getObjectExpressAccess().getOKeyword_0());
            		
            // InternalSparrow.g:5603:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:5604:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:5604:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:5605:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getObjectExpressRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_80); 

            					newLeafNode(otherlv_1, grammarAccess.getObjectExpressAccess().getObjectInitExpressionoCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,102,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getObjectExpressAccess().getFullStopKeyword_2());
            		
            // InternalSparrow.g:5620:3: ( (lv_attribute_3_0= RULE_ID ) )
            // InternalSparrow.g:5621:4: (lv_attribute_3_0= RULE_ID )
            {
            // InternalSparrow.g:5621:4: (lv_attribute_3_0= RULE_ID )
            // InternalSparrow.g:5622:5: lv_attribute_3_0= RULE_ID
            {
            lv_attribute_3_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_attribute_3_0, grammarAccess.getObjectExpressAccess().getAttributeIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getObjectExpressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"attribute",
            						lv_attribute_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectExpress"


    // $ANTLR start "entryRuletrueOperation"
    // InternalSparrow.g:5642:1: entryRuletrueOperation returns [EObject current=null] : iv_ruletrueOperation= ruletrueOperation EOF ;
    public final EObject entryRuletrueOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruletrueOperation = null;


        try {
            // InternalSparrow.g:5642:54: (iv_ruletrueOperation= ruletrueOperation EOF )
            // InternalSparrow.g:5643:2: iv_ruletrueOperation= ruletrueOperation EOF
            {
             newCompositeNode(grammarAccess.getTrueOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruletrueOperation=ruletrueOperation();

            state._fsp--;

             current =iv_ruletrueOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuletrueOperation"


    // $ANTLR start "ruletrueOperation"
    // InternalSparrow.g:5649:1: ruletrueOperation returns [EObject current=null] : (this_transferExpression_0= ruletransferExpression | this_changeExpression_1= rulechangeExpression ) ;
    public final EObject ruletrueOperation() throws RecognitionException {
        EObject current = null;

        EObject this_transferExpression_0 = null;

        EObject this_changeExpression_1 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5655:2: ( (this_transferExpression_0= ruletransferExpression | this_changeExpression_1= rulechangeExpression ) )
            // InternalSparrow.g:5656:2: (this_transferExpression_0= ruletransferExpression | this_changeExpression_1= rulechangeExpression )
            {
            // InternalSparrow.g:5656:2: (this_transferExpression_0= ruletransferExpression | this_changeExpression_1= rulechangeExpression )
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==105) ) {
                alt89=1;
            }
            else if ( ((LA89_0>=106 && LA89_0<=107)||LA89_0==114) ) {
                alt89=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 89, 0, input);

                throw nvae;
            }
            switch (alt89) {
                case 1 :
                    // InternalSparrow.g:5657:3: this_transferExpression_0= ruletransferExpression
                    {

                    			newCompositeNode(grammarAccess.getTrueOperationAccess().getTransferExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_transferExpression_0=ruletransferExpression();

                    state._fsp--;


                    			current = this_transferExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:5666:3: this_changeExpression_1= rulechangeExpression
                    {

                    			newCompositeNode(grammarAccess.getTrueOperationAccess().getChangeExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_changeExpression_1=rulechangeExpression();

                    state._fsp--;


                    			current = this_changeExpression_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruletrueOperation"


    // $ANTLR start "entryRulemessageExpression"
    // InternalSparrow.g:5678:1: entryRulemessageExpression returns [EObject current=null] : iv_rulemessageExpression= rulemessageExpression EOF ;
    public final EObject entryRulemessageExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulemessageExpression = null;


        try {
            // InternalSparrow.g:5678:58: (iv_rulemessageExpression= rulemessageExpression EOF )
            // InternalSparrow.g:5679:2: iv_rulemessageExpression= rulemessageExpression EOF
            {
             newCompositeNode(grammarAccess.getMessageExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulemessageExpression=rulemessageExpression();

            state._fsp--;

             current =iv_rulemessageExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulemessageExpression"


    // $ANTLR start "rulemessageExpression"
    // InternalSparrow.g:5685:1: rulemessageExpression returns [EObject current=null] : (otherlv_0= 'SetMessage(' ( (lv_everymassage_1_0= ruleeveryMessage ) ) (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )* otherlv_4= ')' ) ;
    public final EObject rulemessageExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_everymassage_1_0 = null;

        EObject lv_everymassage_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5691:2: ( (otherlv_0= 'SetMessage(' ( (lv_everymassage_1_0= ruleeveryMessage ) ) (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )* otherlv_4= ')' ) )
            // InternalSparrow.g:5692:2: (otherlv_0= 'SetMessage(' ( (lv_everymassage_1_0= ruleeveryMessage ) ) (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )* otherlv_4= ')' )
            {
            // InternalSparrow.g:5692:2: (otherlv_0= 'SetMessage(' ( (lv_everymassage_1_0= ruleeveryMessage ) ) (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )* otherlv_4= ')' )
            // InternalSparrow.g:5693:3: otherlv_0= 'SetMessage(' ( (lv_everymassage_1_0= ruleeveryMessage ) ) (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )* otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,103,FOLLOW_81); 

            			newLeafNode(otherlv_0, grammarAccess.getMessageExpressionAccess().getSetMessageKeyword_0());
            		
            // InternalSparrow.g:5697:3: ( (lv_everymassage_1_0= ruleeveryMessage ) )
            // InternalSparrow.g:5698:4: (lv_everymassage_1_0= ruleeveryMessage )
            {
            // InternalSparrow.g:5698:4: (lv_everymassage_1_0= ruleeveryMessage )
            // InternalSparrow.g:5699:5: lv_everymassage_1_0= ruleeveryMessage
            {

            					newCompositeNode(grammarAccess.getMessageExpressionAccess().getEverymassageEveryMessageParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_24);
            lv_everymassage_1_0=ruleeveryMessage();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMessageExpressionRule());
            					}
            					add(
            						current,
            						"everymassage",
            						lv_everymassage_1_0,
            						"org.xtext.example.mydsl.Sparrow.everyMessage");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:5716:3: (otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) ) )*
            loop90:
            do {
                int alt90=2;
                int LA90_0 = input.LA(1);

                if ( (LA90_0==22) ) {
                    alt90=1;
                }


                switch (alt90) {
            	case 1 :
            	    // InternalSparrow.g:5717:4: otherlv_2= ',' ( (lv_everymassage_3_0= ruleeveryMessage ) )
            	    {
            	    otherlv_2=(Token)match(input,22,FOLLOW_81); 

            	    				newLeafNode(otherlv_2, grammarAccess.getMessageExpressionAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalSparrow.g:5721:4: ( (lv_everymassage_3_0= ruleeveryMessage ) )
            	    // InternalSparrow.g:5722:5: (lv_everymassage_3_0= ruleeveryMessage )
            	    {
            	    // InternalSparrow.g:5722:5: (lv_everymassage_3_0= ruleeveryMessage )
            	    // InternalSparrow.g:5723:6: lv_everymassage_3_0= ruleeveryMessage
            	    {

            	    						newCompositeNode(grammarAccess.getMessageExpressionAccess().getEverymassageEveryMessageParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_24);
            	    lv_everymassage_3_0=ruleeveryMessage();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getMessageExpressionRule());
            	    						}
            	    						add(
            	    							current,
            	    							"everymassage",
            	    							lv_everymassage_3_0,
            	    							"org.xtext.example.mydsl.Sparrow.everyMessage");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop90;
                }
            } while (true);

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getMessageExpressionAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulemessageExpression"


    // $ANTLR start "entryRuleeveryMessage"
    // InternalSparrow.g:5749:1: entryRuleeveryMessage returns [EObject current=null] : iv_ruleeveryMessage= ruleeveryMessage EOF ;
    public final EObject entryRuleeveryMessage() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleeveryMessage = null;


        try {
            // InternalSparrow.g:5749:53: (iv_ruleeveryMessage= ruleeveryMessage EOF )
            // InternalSparrow.g:5750:2: iv_ruleeveryMessage= ruleeveryMessage EOF
            {
             newCompositeNode(grammarAccess.getEveryMessageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleeveryMessage=ruleeveryMessage();

            state._fsp--;

             current =iv_ruleeveryMessage; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleeveryMessage"


    // $ANTLR start "ruleeveryMessage"
    // InternalSparrow.g:5756:1: ruleeveryMessage returns [EObject current=null] : ( ( (lv_symbol_0_0= 'new' ) )? ( (lv_type_1_0= ruletype ) ) ( (lv_message_2_0= RULE_ID ) ) ) ;
    public final EObject ruleeveryMessage() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_message_2_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5762:2: ( ( ( (lv_symbol_0_0= 'new' ) )? ( (lv_type_1_0= ruletype ) ) ( (lv_message_2_0= RULE_ID ) ) ) )
            // InternalSparrow.g:5763:2: ( ( (lv_symbol_0_0= 'new' ) )? ( (lv_type_1_0= ruletype ) ) ( (lv_message_2_0= RULE_ID ) ) )
            {
            // InternalSparrow.g:5763:2: ( ( (lv_symbol_0_0= 'new' ) )? ( (lv_type_1_0= ruletype ) ) ( (lv_message_2_0= RULE_ID ) ) )
            // InternalSparrow.g:5764:3: ( (lv_symbol_0_0= 'new' ) )? ( (lv_type_1_0= ruletype ) ) ( (lv_message_2_0= RULE_ID ) )
            {
            // InternalSparrow.g:5764:3: ( (lv_symbol_0_0= 'new' ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( (LA91_0==104) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSparrow.g:5765:4: (lv_symbol_0_0= 'new' )
                    {
                    // InternalSparrow.g:5765:4: (lv_symbol_0_0= 'new' )
                    // InternalSparrow.g:5766:5: lv_symbol_0_0= 'new'
                    {
                    lv_symbol_0_0=(Token)match(input,104,FOLLOW_27); 

                    					newLeafNode(lv_symbol_0_0, grammarAccess.getEveryMessageAccess().getSymbolNewKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getEveryMessageRule());
                    					}
                    					setWithLastConsumed(current, "symbol", lv_symbol_0_0, "new");
                    				

                    }


                    }
                    break;

            }

            // InternalSparrow.g:5778:3: ( (lv_type_1_0= ruletype ) )
            // InternalSparrow.g:5779:4: (lv_type_1_0= ruletype )
            {
            // InternalSparrow.g:5779:4: (lv_type_1_0= ruletype )
            // InternalSparrow.g:5780:5: lv_type_1_0= ruletype
            {

            					newCompositeNode(grammarAccess.getEveryMessageAccess().getTypeTypeParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_3);
            lv_type_1_0=ruletype();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEveryMessageRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.Sparrow.type");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSparrow.g:5797:3: ( (lv_message_2_0= RULE_ID ) )
            // InternalSparrow.g:5798:4: (lv_message_2_0= RULE_ID )
            {
            // InternalSparrow.g:5798:4: (lv_message_2_0= RULE_ID )
            // InternalSparrow.g:5799:5: lv_message_2_0= RULE_ID
            {
            lv_message_2_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_message_2_0, grammarAccess.getEveryMessageAccess().getMessageIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEveryMessageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"message",
            						lv_message_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleeveryMessage"


    // $ANTLR start "entryRuletransferExpression"
    // InternalSparrow.g:5819:1: entryRuletransferExpression returns [EObject current=null] : iv_ruletransferExpression= ruletransferExpression EOF ;
    public final EObject entryRuletransferExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruletransferExpression = null;


        try {
            // InternalSparrow.g:5819:59: (iv_ruletransferExpression= ruletransferExpression EOF )
            // InternalSparrow.g:5820:2: iv_ruletransferExpression= ruletransferExpression EOF
            {
             newCompositeNode(grammarAccess.getTransferExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruletransferExpression=ruletransferExpression();

            state._fsp--;

             current =iv_ruletransferExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuletransferExpression"


    // $ANTLR start "ruletransferExpression"
    // InternalSparrow.g:5826:1: ruletransferExpression returns [EObject current=null] : (otherlv_0= 'transfer(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_value_3_0= ruleMixExpression ) ) otherlv_4= ')' ) ;
    public final EObject ruletransferExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_value_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5832:2: ( (otherlv_0= 'transfer(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_value_3_0= ruleMixExpression ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:5833:2: (otherlv_0= 'transfer(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_value_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:5833:2: (otherlv_0= 'transfer(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_value_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            // InternalSparrow.g:5834:3: otherlv_0= 'transfer(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_value_3_0= ruleMixExpression ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,105,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getTransferExpressionAccess().getTransferKeyword_0());
            		
            // InternalSparrow.g:5838:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:5839:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:5839:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:5840:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransferExpressionRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_32); 

            					newLeafNode(otherlv_1, grammarAccess.getTransferExpressionAccess().getPersonInitExpressionsCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_71); 

            			newLeafNode(otherlv_2, grammarAccess.getTransferExpressionAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:5855:3: ( (lv_value_3_0= ruleMixExpression ) )
            // InternalSparrow.g:5856:4: (lv_value_3_0= ruleMixExpression )
            {
            // InternalSparrow.g:5856:4: (lv_value_3_0= ruleMixExpression )
            // InternalSparrow.g:5857:5: lv_value_3_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getTransferExpressionAccess().getValueMixExpressionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_value_3_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTransferExpressionRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_3_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getTransferExpressionAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruletransferExpression"


    // $ANTLR start "entryRulechangeExpression"
    // InternalSparrow.g:5882:1: entryRulechangeExpression returns [EObject current=null] : iv_rulechangeExpression= rulechangeExpression EOF ;
    public final EObject entryRulechangeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulechangeExpression = null;


        try {
            // InternalSparrow.g:5882:57: (iv_rulechangeExpression= rulechangeExpression EOF )
            // InternalSparrow.g:5883:2: iv_rulechangeExpression= rulechangeExpression EOF
            {
             newCompositeNode(grammarAccess.getChangeExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulechangeExpression=rulechangeExpression();

            state._fsp--;

             current =iv_rulechangeExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulechangeExpression"


    // $ANTLR start "rulechangeExpression"
    // InternalSparrow.g:5889:1: rulechangeExpression returns [EObject current=null] : (this_changeContract_0= rulechangeContract | this_changeRule_1= rulechangeRule | this_otherchange_2= ruleotherchange | this_changeString_3= rulechangeString | this_changeOther_4= rulechangeOther ) ;
    public final EObject rulechangeExpression() throws RecognitionException {
        EObject current = null;

        EObject this_changeContract_0 = null;

        EObject this_changeRule_1 = null;

        EObject this_otherchange_2 = null;

        EObject this_changeString_3 = null;

        EObject this_changeOther_4 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5895:2: ( (this_changeContract_0= rulechangeContract | this_changeRule_1= rulechangeRule | this_otherchange_2= ruleotherchange | this_changeString_3= rulechangeString | this_changeOther_4= rulechangeOther ) )
            // InternalSparrow.g:5896:2: (this_changeContract_0= rulechangeContract | this_changeRule_1= rulechangeRule | this_otherchange_2= ruleotherchange | this_changeString_3= rulechangeString | this_changeOther_4= rulechangeOther )
            {
            // InternalSparrow.g:5896:2: (this_changeContract_0= rulechangeContract | this_changeRule_1= rulechangeRule | this_otherchange_2= ruleotherchange | this_changeString_3= rulechangeString | this_changeOther_4= rulechangeOther )
            int alt92=5;
            alt92 = dfa92.predict(input);
            switch (alt92) {
                case 1 :
                    // InternalSparrow.g:5897:3: this_changeContract_0= rulechangeContract
                    {

                    			newCompositeNode(grammarAccess.getChangeExpressionAccess().getChangeContractParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_changeContract_0=rulechangeContract();

                    state._fsp--;


                    			current = this_changeContract_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:5906:3: this_changeRule_1= rulechangeRule
                    {

                    			newCompositeNode(grammarAccess.getChangeExpressionAccess().getChangeRuleParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_changeRule_1=rulechangeRule();

                    state._fsp--;


                    			current = this_changeRule_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:5915:3: this_otherchange_2= ruleotherchange
                    {

                    			newCompositeNode(grammarAccess.getChangeExpressionAccess().getOtherchangeParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_otherchange_2=ruleotherchange();

                    state._fsp--;


                    			current = this_otherchange_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:5924:3: this_changeString_3= rulechangeString
                    {

                    			newCompositeNode(grammarAccess.getChangeExpressionAccess().getChangeStringParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_changeString_3=rulechangeString();

                    state._fsp--;


                    			current = this_changeString_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:5933:3: this_changeOther_4= rulechangeOther
                    {

                    			newCompositeNode(grammarAccess.getChangeExpressionAccess().getChangeOtherParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_changeOther_4=rulechangeOther();

                    state._fsp--;


                    			current = this_changeOther_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulechangeExpression"


    // $ANTLR start "entryRulechangeString"
    // InternalSparrow.g:5945:1: entryRulechangeString returns [EObject current=null] : iv_rulechangeString= rulechangeString EOF ;
    public final EObject entryRulechangeString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulechangeString = null;


        try {
            // InternalSparrow.g:5945:53: (iv_rulechangeString= rulechangeString EOF )
            // InternalSparrow.g:5946:2: iv_rulechangeString= rulechangeString EOF
            {
             newCompositeNode(grammarAccess.getChangeStringRule()); 
            pushFollow(FOLLOW_1);
            iv_rulechangeString=rulechangeString();

            state._fsp--;

             current =iv_rulechangeString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulechangeString"


    // $ANTLR start "rulechangeString"
    // InternalSparrow.g:5952:1: rulechangeString returns [EObject current=null] : (otherlv_0= 'assignString(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' ) ;
    public final EObject rulechangeString() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_changeThing_1_0 = null;

        EObject lv_changeResult_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:5958:2: ( (otherlv_0= 'assignString(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:5959:2: (otherlv_0= 'assignString(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:5959:2: (otherlv_0= 'assignString(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            // InternalSparrow.g:5960:3: otherlv_0= 'assignString(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,106,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getChangeStringAccess().getAssignStringKeyword_0());
            		
            // InternalSparrow.g:5964:3: ( (lv_changeThing_1_0= ruleMixExpression ) )
            // InternalSparrow.g:5965:4: (lv_changeThing_1_0= ruleMixExpression )
            {
            // InternalSparrow.g:5965:4: (lv_changeThing_1_0= ruleMixExpression )
            // InternalSparrow.g:5966:5: lv_changeThing_1_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getChangeStringAccess().getChangeThingMixExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_32);
            lv_changeThing_1_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeStringRule());
            					}
            					set(
            						current,
            						"changeThing",
            						lv_changeThing_1_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_71); 

            			newLeafNode(otherlv_2, grammarAccess.getChangeStringAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:5987:3: ( (lv_changeResult_3_0= ruleMixExpression ) )
            // InternalSparrow.g:5988:4: (lv_changeResult_3_0= ruleMixExpression )
            {
            // InternalSparrow.g:5988:4: (lv_changeResult_3_0= ruleMixExpression )
            // InternalSparrow.g:5989:5: lv_changeResult_3_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getChangeStringAccess().getChangeResultMixExpressionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_changeResult_3_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeStringRule());
            					}
            					set(
            						current,
            						"changeResult",
            						lv_changeResult_3_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getChangeStringAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulechangeString"


    // $ANTLR start "entryRuleotherchange"
    // InternalSparrow.g:6014:1: entryRuleotherchange returns [EObject current=null] : iv_ruleotherchange= ruleotherchange EOF ;
    public final EObject entryRuleotherchange() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleotherchange = null;


        try {
            // InternalSparrow.g:6014:52: (iv_ruleotherchange= ruleotherchange EOF )
            // InternalSparrow.g:6015:2: iv_ruleotherchange= ruleotherchange EOF
            {
             newCompositeNode(grammarAccess.getOtherchangeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleotherchange=ruleotherchange();

            state._fsp--;

             current =iv_ruleotherchange; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleotherchange"


    // $ANTLR start "ruleotherchange"
    // InternalSparrow.g:6021:1: ruleotherchange returns [EObject current=null] : (otherlv_0= 'assign(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' ) ;
    public final EObject ruleotherchange() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_changeThing_1_0 = null;

        EObject lv_changeResult_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:6027:2: ( (otherlv_0= 'assign(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:6028:2: (otherlv_0= 'assign(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:6028:2: (otherlv_0= 'assign(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')' )
            // InternalSparrow.g:6029:3: otherlv_0= 'assign(' ( (lv_changeThing_1_0= ruleMixExpression ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleMixExpression ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,107,FOLLOW_71); 

            			newLeafNode(otherlv_0, grammarAccess.getOtherchangeAccess().getAssignKeyword_0());
            		
            // InternalSparrow.g:6033:3: ( (lv_changeThing_1_0= ruleMixExpression ) )
            // InternalSparrow.g:6034:4: (lv_changeThing_1_0= ruleMixExpression )
            {
            // InternalSparrow.g:6034:4: (lv_changeThing_1_0= ruleMixExpression )
            // InternalSparrow.g:6035:5: lv_changeThing_1_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getOtherchangeAccess().getChangeThingMixExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_32);
            lv_changeThing_1_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOtherchangeRule());
            					}
            					set(
            						current,
            						"changeThing",
            						lv_changeThing_1_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_71); 

            			newLeafNode(otherlv_2, grammarAccess.getOtherchangeAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:6056:3: ( (lv_changeResult_3_0= ruleMixExpression ) )
            // InternalSparrow.g:6057:4: (lv_changeResult_3_0= ruleMixExpression )
            {
            // InternalSparrow.g:6057:4: (lv_changeResult_3_0= ruleMixExpression )
            // InternalSparrow.g:6058:5: lv_changeResult_3_0= ruleMixExpression
            {

            					newCompositeNode(grammarAccess.getOtherchangeAccess().getChangeResultMixExpressionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_changeResult_3_0=ruleMixExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOtherchangeRule());
            					}
            					set(
            						current,
            						"changeResult",
            						lv_changeResult_3_0,
            						"org.xtext.example.mydsl.Sparrow.MixExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getOtherchangeAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleotherchange"


    // $ANTLR start "entryRulechangeContract"
    // InternalSparrow.g:6083:1: entryRulechangeContract returns [EObject current=null] : iv_rulechangeContract= rulechangeContract EOF ;
    public final EObject entryRulechangeContract() throws RecognitionException {
        EObject current = null;

        EObject iv_rulechangeContract = null;


        try {
            // InternalSparrow.g:6083:55: (iv_rulechangeContract= rulechangeContract EOF )
            // InternalSparrow.g:6084:2: iv_rulechangeContract= rulechangeContract EOF
            {
             newCompositeNode(grammarAccess.getChangeContractRule()); 
            pushFollow(FOLLOW_1);
            iv_rulechangeContract=rulechangeContract();

            state._fsp--;

             current =iv_rulechangeContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulechangeContract"


    // $ANTLR start "rulechangeContract"
    // InternalSparrow.g:6090:1: rulechangeContract returns [EObject current=null] : (otherlv_0= 'assign(' otherlv_1= 'ContractState' otherlv_2= ',' ( (lv_changeResult_3_0= ruleContractState ) ) otherlv_4= ')' ) ;
    public final EObject rulechangeContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_changeResult_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:6096:2: ( (otherlv_0= 'assign(' otherlv_1= 'ContractState' otherlv_2= ',' ( (lv_changeResult_3_0= ruleContractState ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:6097:2: (otherlv_0= 'assign(' otherlv_1= 'ContractState' otherlv_2= ',' ( (lv_changeResult_3_0= ruleContractState ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:6097:2: (otherlv_0= 'assign(' otherlv_1= 'ContractState' otherlv_2= ',' ( (lv_changeResult_3_0= ruleContractState ) ) otherlv_4= ')' )
            // InternalSparrow.g:6098:3: otherlv_0= 'assign(' otherlv_1= 'ContractState' otherlv_2= ',' ( (lv_changeResult_3_0= ruleContractState ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,107,FOLLOW_82); 

            			newLeafNode(otherlv_0, grammarAccess.getChangeContractAccess().getAssignKeyword_0());
            		
            otherlv_1=(Token)match(input,108,FOLLOW_32); 

            			newLeafNode(otherlv_1, grammarAccess.getChangeContractAccess().getContractStateKeyword_1());
            		
            otherlv_2=(Token)match(input,22,FOLLOW_83); 

            			newLeafNode(otherlv_2, grammarAccess.getChangeContractAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:6110:3: ( (lv_changeResult_3_0= ruleContractState ) )
            // InternalSparrow.g:6111:4: (lv_changeResult_3_0= ruleContractState )
            {
            // InternalSparrow.g:6111:4: (lv_changeResult_3_0= ruleContractState )
            // InternalSparrow.g:6112:5: lv_changeResult_3_0= ruleContractState
            {

            					newCompositeNode(grammarAccess.getChangeContractAccess().getChangeResultContractStateParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_changeResult_3_0=ruleContractState();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeContractRule());
            					}
            					set(
            						current,
            						"changeResult",
            						lv_changeResult_3_0,
            						"org.xtext.example.mydsl.Sparrow.ContractState");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getChangeContractAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulechangeContract"


    // $ANTLR start "entryRuleContractState"
    // InternalSparrow.g:6137:1: entryRuleContractState returns [String current=null] : iv_ruleContractState= ruleContractState EOF ;
    public final String entryRuleContractState() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleContractState = null;


        try {
            // InternalSparrow.g:6137:53: (iv_ruleContractState= ruleContractState EOF )
            // InternalSparrow.g:6138:2: iv_ruleContractState= ruleContractState EOF
            {
             newCompositeNode(grammarAccess.getContractStateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContractState=ruleContractState();

            state._fsp--;

             current =iv_ruleContractState.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContractState"


    // $ANTLR start "ruleContractState"
    // InternalSparrow.g:6144:1: ruleContractState returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'start' | kw= 'pause' | kw= 'restart' | kw= 'terminate' | kw= 'finish' ) ;
    public final AntlrDatatypeRuleToken ruleContractState() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:6150:2: ( (kw= 'start' | kw= 'pause' | kw= 'restart' | kw= 'terminate' | kw= 'finish' ) )
            // InternalSparrow.g:6151:2: (kw= 'start' | kw= 'pause' | kw= 'restart' | kw= 'terminate' | kw= 'finish' )
            {
            // InternalSparrow.g:6151:2: (kw= 'start' | kw= 'pause' | kw= 'restart' | kw= 'terminate' | kw= 'finish' )
            int alt93=5;
            switch ( input.LA(1) ) {
            case 109:
                {
                alt93=1;
                }
                break;
            case 110:
                {
                alt93=2;
                }
                break;
            case 111:
                {
                alt93=3;
                }
                break;
            case 112:
                {
                alt93=4;
                }
                break;
            case 113:
                {
                alt93=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 93, 0, input);

                throw nvae;
            }

            switch (alt93) {
                case 1 :
                    // InternalSparrow.g:6152:3: kw= 'start'
                    {
                    kw=(Token)match(input,109,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getContractStateAccess().getStartKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:6158:3: kw= 'pause'
                    {
                    kw=(Token)match(input,110,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getContractStateAccess().getPauseKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSparrow.g:6164:3: kw= 'restart'
                    {
                    kw=(Token)match(input,111,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getContractStateAccess().getRestartKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSparrow.g:6170:3: kw= 'terminate'
                    {
                    kw=(Token)match(input,112,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getContractStateAccess().getTerminateKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSparrow.g:6176:3: kw= 'finish'
                    {
                    kw=(Token)match(input,113,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getContractStateAccess().getFinishKeyword_4());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContractState"


    // $ANTLR start "entryRulechangeRule"
    // InternalSparrow.g:6185:1: entryRulechangeRule returns [EObject current=null] : iv_rulechangeRule= rulechangeRule EOF ;
    public final EObject entryRulechangeRule() throws RecognitionException {
        EObject current = null;

        EObject iv_rulechangeRule = null;


        try {
            // InternalSparrow.g:6185:51: (iv_rulechangeRule= rulechangeRule EOF )
            // InternalSparrow.g:6186:2: iv_rulechangeRule= rulechangeRule EOF
            {
             newCompositeNode(grammarAccess.getChangeRuleRule()); 
            pushFollow(FOLLOW_1);
            iv_rulechangeRule=rulechangeRule();

            state._fsp--;

             current =iv_rulechangeRule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulechangeRule"


    // $ANTLR start "rulechangeRule"
    // InternalSparrow.g:6192:1: rulechangeRule returns [EObject current=null] : (otherlv_0= 'assign(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleBOOLEAN ) ) otherlv_4= ')' ) ;
    public final EObject rulechangeRule() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_changeResult_3_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:6198:2: ( (otherlv_0= 'assign(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleBOOLEAN ) ) otherlv_4= ')' ) )
            // InternalSparrow.g:6199:2: (otherlv_0= 'assign(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleBOOLEAN ) ) otherlv_4= ')' )
            {
            // InternalSparrow.g:6199:2: (otherlv_0= 'assign(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleBOOLEAN ) ) otherlv_4= ')' )
            // InternalSparrow.g:6200:3: otherlv_0= 'assign(' ( (otherlv_1= RULE_ID ) ) otherlv_2= ',' ( (lv_changeResult_3_0= ruleBOOLEAN ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,107,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getChangeRuleAccess().getAssignKeyword_0());
            		
            // InternalSparrow.g:6204:3: ( (otherlv_1= RULE_ID ) )
            // InternalSparrow.g:6205:4: (otherlv_1= RULE_ID )
            {
            // InternalSparrow.g:6205:4: (otherlv_1= RULE_ID )
            // InternalSparrow.g:6206:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getChangeRuleRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_32); 

            					newLeafNode(otherlv_1, grammarAccess.getChangeRuleAccess().getChangeThingRuleExpressionCrossReference_1_0());
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_84); 

            			newLeafNode(otherlv_2, grammarAccess.getChangeRuleAccess().getCommaKeyword_2());
            		
            // InternalSparrow.g:6221:3: ( (lv_changeResult_3_0= ruleBOOLEAN ) )
            // InternalSparrow.g:6222:4: (lv_changeResult_3_0= ruleBOOLEAN )
            {
            // InternalSparrow.g:6222:4: (lv_changeResult_3_0= ruleBOOLEAN )
            // InternalSparrow.g:6223:5: lv_changeResult_3_0= ruleBOOLEAN
            {

            					newCompositeNode(grammarAccess.getChangeRuleAccess().getChangeResultBOOLEANParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_64);
            lv_changeResult_3_0=ruleBOOLEAN();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeRuleRule());
            					}
            					set(
            						current,
            						"changeResult",
            						lv_changeResult_3_0,
            						"org.xtext.example.mydsl.Sparrow.BOOLEAN");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getChangeRuleAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulechangeRule"


    // $ANTLR start "entryRulechangeOther"
    // InternalSparrow.g:6248:1: entryRulechangeOther returns [EObject current=null] : iv_rulechangeOther= rulechangeOther EOF ;
    public final EObject entryRulechangeOther() throws RecognitionException {
        EObject current = null;

        EObject iv_rulechangeOther = null;


        try {
            // InternalSparrow.g:6248:52: (iv_rulechangeOther= rulechangeOther EOF )
            // InternalSparrow.g:6249:2: iv_rulechangeOther= rulechangeOther EOF
            {
             newCompositeNode(grammarAccess.getChangeOtherRule()); 
            pushFollow(FOLLOW_1);
            iv_rulechangeOther=rulechangeOther();

            state._fsp--;

             current =iv_rulechangeOther; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulechangeOther"


    // $ANTLR start "rulechangeOther"
    // InternalSparrow.g:6255:1: rulechangeOther returns [EObject current=null] : (otherlv_0= 'change(' otherlv_1= 'CM' ( (lv_changeThing_2_0= ruleSingleExpression ) ) otherlv_3= ',' ( (lv_changeResult_4_0= ruleBOOLEAN ) ) otherlv_5= ')' ) ;
    public final EObject rulechangeOther() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_changeThing_2_0 = null;

        AntlrDatatypeRuleToken lv_changeResult_4_0 = null;



        	enterRule();

        try {
            // InternalSparrow.g:6261:2: ( (otherlv_0= 'change(' otherlv_1= 'CM' ( (lv_changeThing_2_0= ruleSingleExpression ) ) otherlv_3= ',' ( (lv_changeResult_4_0= ruleBOOLEAN ) ) otherlv_5= ')' ) )
            // InternalSparrow.g:6262:2: (otherlv_0= 'change(' otherlv_1= 'CM' ( (lv_changeThing_2_0= ruleSingleExpression ) ) otherlv_3= ',' ( (lv_changeResult_4_0= ruleBOOLEAN ) ) otherlv_5= ')' )
            {
            // InternalSparrow.g:6262:2: (otherlv_0= 'change(' otherlv_1= 'CM' ( (lv_changeThing_2_0= ruleSingleExpression ) ) otherlv_3= ',' ( (lv_changeResult_4_0= ruleBOOLEAN ) ) otherlv_5= ')' )
            // InternalSparrow.g:6263:3: otherlv_0= 'change(' otherlv_1= 'CM' ( (lv_changeThing_2_0= ruleSingleExpression ) ) otherlv_3= ',' ( (lv_changeResult_4_0= ruleBOOLEAN ) ) otherlv_5= ')'
            {
            otherlv_0=(Token)match(input,114,FOLLOW_85); 

            			newLeafNode(otherlv_0, grammarAccess.getChangeOtherAccess().getChangeKeyword_0());
            		
            otherlv_1=(Token)match(input,115,FOLLOW_71); 

            			newLeafNode(otherlv_1, grammarAccess.getChangeOtherAccess().getCMKeyword_1());
            		
            // InternalSparrow.g:6271:3: ( (lv_changeThing_2_0= ruleSingleExpression ) )
            // InternalSparrow.g:6272:4: (lv_changeThing_2_0= ruleSingleExpression )
            {
            // InternalSparrow.g:6272:4: (lv_changeThing_2_0= ruleSingleExpression )
            // InternalSparrow.g:6273:5: lv_changeThing_2_0= ruleSingleExpression
            {

            					newCompositeNode(grammarAccess.getChangeOtherAccess().getChangeThingSingleExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_32);
            lv_changeThing_2_0=ruleSingleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeOtherRule());
            					}
            					set(
            						current,
            						"changeThing",
            						lv_changeThing_2_0,
            						"org.xtext.example.mydsl.Sparrow.SingleExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,22,FOLLOW_84); 

            			newLeafNode(otherlv_3, grammarAccess.getChangeOtherAccess().getCommaKeyword_3());
            		
            // InternalSparrow.g:6294:3: ( (lv_changeResult_4_0= ruleBOOLEAN ) )
            // InternalSparrow.g:6295:4: (lv_changeResult_4_0= ruleBOOLEAN )
            {
            // InternalSparrow.g:6295:4: (lv_changeResult_4_0= ruleBOOLEAN )
            // InternalSparrow.g:6296:5: lv_changeResult_4_0= ruleBOOLEAN
            {

            					newCompositeNode(grammarAccess.getChangeOtherAccess().getChangeResultBOOLEANParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_64);
            lv_changeResult_4_0=ruleBOOLEAN();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChangeOtherRule());
            					}
            					set(
            						current,
            						"changeResult",
            						lv_changeResult_4_0,
            						"org.xtext.example.mydsl.Sparrow.BOOLEAN");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getChangeOtherAccess().getRightParenthesisKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulechangeOther"


    // $ANTLR start "entryRuleBOOLEAN"
    // InternalSparrow.g:6321:1: entryRuleBOOLEAN returns [String current=null] : iv_ruleBOOLEAN= ruleBOOLEAN EOF ;
    public final String entryRuleBOOLEAN() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleBOOLEAN = null;


        try {
            // InternalSparrow.g:6321:47: (iv_ruleBOOLEAN= ruleBOOLEAN EOF )
            // InternalSparrow.g:6322:2: iv_ruleBOOLEAN= ruleBOOLEAN EOF
            {
             newCompositeNode(grammarAccess.getBOOLEANRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBOOLEAN=ruleBOOLEAN();

            state._fsp--;

             current =iv_ruleBOOLEAN.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBOOLEAN"


    // $ANTLR start "ruleBOOLEAN"
    // InternalSparrow.g:6328:1: ruleBOOLEAN returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'true' | kw= 'false' ) ;
    public final AntlrDatatypeRuleToken ruleBOOLEAN() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSparrow.g:6334:2: ( (kw= 'true' | kw= 'false' ) )
            // InternalSparrow.g:6335:2: (kw= 'true' | kw= 'false' )
            {
            // InternalSparrow.g:6335:2: (kw= 'true' | kw= 'false' )
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==116) ) {
                alt94=1;
            }
            else if ( (LA94_0==117) ) {
                alt94=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 94, 0, input);

                throw nvae;
            }
            switch (alt94) {
                case 1 :
                    // InternalSparrow.g:6336:3: kw= 'true'
                    {
                    kw=(Token)match(input,116,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getBOOLEANAccess().getTrueKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSparrow.g:6342:3: kw= 'false'
                    {
                    kw=(Token)match(input,117,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getBOOLEANAccess().getFalseKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBOOLEAN"

    // Delegated rules


    protected DFA28 dfa28 = new DFA28(this);
    protected DFA86 dfa86 = new DFA86(this);
    protected DFA92 dfa92 = new DFA92(this);
    static final String dfa_1s = "\14\uffff";
    static final String dfa_2s = "\1\uffff\1\13\12\uffff";
    static final String dfa_3s = "\1\4\1\23\12\uffff";
    static final String dfa_4s = "\1\165\1\101\12\uffff";
    static final String dfa_5s = "\2\uffff\1\2\1\4\1\5\1\6\1\7\1\10\1\12\1\11\1\3\1\1";
    static final String dfa_6s = "\14\uffff}>";
    static final String[] dfa_7s = {
            "\1\2\1\1\1\7\1\5\1\4\66\uffff\1\10\1\6\63\uffff\2\3",
            "\1\13\2\uffff\1\13\21\uffff\1\13\22\uffff\4\11\2\uffff\1\12",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA28 extends DFA {

        public DFA28(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 28;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "1407:2: (this_AllNumber_0= ruleAllNumber | this_Right_1= ruleRight | this_ThisDate_2= ruleThisDate | this_ThisBoolean_3= ruleThisBoolean | this_url_4= ruleurl | this_ThisDecimal_5= ruleThisDecimal | this_Address_6= ruleAddress | this_ThisString_7= ruleThisString | this_Duration_8= ruleDuration | this_Now_9= ruleNow )";
        }
    }
    static final String dfa_8s = "\1\uffff\1\2\2\uffff\1\12\7\uffff";
    static final String dfa_9s = "\1\4\1\12\2\uffff\1\12\7\uffff";
    static final String dfa_10s = "\1\165\1\134\2\uffff\1\134\7\uffff";
    static final String dfa_11s = "\2\uffff\1\1\1\2\1\uffff\1\4\1\5\1\6\1\7\1\10\1\3\1\11";
    static final String[] dfa_12s = {
            "\1\4\1\1\1\uffff\1\2\35\uffff\1\3\3\uffff\1\3\25\uffff\1\2\42\uffff\1\6\1\10\1\7\1\5\16\uffff\2\2",
            "\1\2\13\uffff\1\2\21\uffff\1\2\22\uffff\3\11\3\uffff\1\2\31\uffff\1\2\1\11",
            "",
            "",
            "\1\12\13\uffff\1\12\21\uffff\1\12\22\uffff\3\13\35\uffff\1\12\1\13",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };
    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA86 extends DFA {

        public DFA86(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 86;
            this.eot = dfa_1;
            this.eof = dfa_8;
            this.min = dfa_9;
            this.max = dfa_10;
            this.accept = dfa_11;
            this.special = dfa_6;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "5033:2: (this_RegularExpression_0= ruleRegularExpression | this_ThingExpression_1= ruleThingExpression | this_OtherExpression_2= ruleOtherExpression | this_PersonExpression_3= rulePersonExpression | this_RuleTimeExpression_4= ruleRuleTimeExpression | this_FloatExpression_5= ruleFloatExpression | this_StringExpression_6= ruleStringExpression | this_PeriodExpression_7= rulePeriodExpression | this_GetPeriodExpression_8= ruleGetPeriodExpression )";
        }
    }
    static final String dfa_13s = "\13\uffff";
    static final String dfa_14s = "\1\152\1\4\3\uffff\1\12\1\uffff\1\4\2\12\1\uffff";
    static final String dfa_15s = "\1\162\1\165\3\uffff\1\134\1\uffff\1\165\2\50\1\uffff";
    static final String dfa_16s = "\2\uffff\1\4\1\5\1\1\1\uffff\1\3\3\uffff\1\2";
    static final String dfa_17s = "\13\uffff}>";
    static final String[] dfa_18s = {
            "\1\2\1\1\6\uffff\1\3",
            "\1\5\1\6\1\uffff\1\6\35\uffff\1\6\3\uffff\1\6\25\uffff\1\6\42\uffff\4\6\6\uffff\1\4\7\uffff\2\6",
            "",
            "",
            "",
            "\1\6\13\uffff\1\7\44\uffff\3\6\36\uffff\1\6",
            "",
            "\2\6\1\uffff\1\6\35\uffff\1\6\3\uffff\1\6\25\uffff\1\6\42\uffff\4\6\16\uffff\1\10\1\11",
            "\1\6\35\uffff\1\12",
            "\1\6\35\uffff\1\12",
            ""
    };

    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final char[] dfa_14 = DFA.unpackEncodedStringToUnsignedChars(dfa_14s);
    static final char[] dfa_15 = DFA.unpackEncodedStringToUnsignedChars(dfa_15s);
    static final short[] dfa_16 = DFA.unpackEncodedString(dfa_16s);
    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[][] dfa_18 = unpackEncodedStringArray(dfa_18s);

    class DFA92 extends DFA {

        public DFA92(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 92;
            this.eot = dfa_13;
            this.eof = dfa_13;
            this.min = dfa_14;
            this.max = dfa_15;
            this.accept = dfa_16;
            this.special = dfa_17;
            this.transition = dfa_18;
        }
        public String getDescription() {
            return "5896:2: (this_changeContract_0= rulechangeContract | this_changeRule_1= rulechangeRule | this_otherchange_2= ruleotherchange | this_changeString_3= rulechangeString | this_changeOther_4= rulechangeOther )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000FC1000180000L,0x000000000000030CL});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000841000180000L,0x000000000000030CL});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000841000180000L,0x0000000000000308L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000800000180000L,0x0000000000000308L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000180000L,0x0000000000000308L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000180000L,0x0000000000000300L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000180000L,0x0000000000000200L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000FFF000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000C00000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000022000080000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000020000080000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x80000000000001F0L,0x0030000000000001L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000010000400000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000480000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x07FF000000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x7800000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000400000L,0x0000000000000020L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000012L,0x00000003E74040C0L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000002L,0x00000000000000C0L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000010L,0x00000003E7404000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000010L,0x00040E0000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000010L,0x0000000000041C00L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000080010L,0x0000000000041C00L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000010L,0x0000000000040000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000800000L,0x0000000000000020L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000400000L,0x00000000000000C0L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000012L,0x00040E0001618040L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000012L,0x00040E0001610040L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000002L,0x0000000001610040L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000002L,0x0000000000210000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000002L,0x0000000001600040L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000002L,0x0000000000200000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000010L,0x00040E000163A040L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000010L,0x00040E0001638040L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000002L,0x0000000000020000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000010L,0x00040E800161A040L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000000010L,0x00040E000161A040L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000010L,0x00040E0001618040L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000000010L,0x00040E80017BA040L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000010L,0x00040E00017BA040L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000000010L,0x00040E000173A040L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000010L,0x00040E0001738040L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000002L,0x0000000000120000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000010L,0x00040E800163A040L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000002L,0x0000000001410040L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x3800000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x00000003E7404000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x80000220000001F0L,0x0030003C00000001L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x80000220004001F0L,0x0030003C08000001L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000400000L,0x0000000008000000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x80000320000005F0L,0x0030003C08000001L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000010000000400L,0x0000000008000000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000010000000400L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000000000L,0x0000004000000000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x07FF000000000000L,0x0000010000000000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000000L,0x0003E00000000000L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000000000L,0x0030000000000000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x0008000000000000L});

}